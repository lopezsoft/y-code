[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\wamp64\www\y-code\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>