<?php echo e($slot); ?>

<?php /**PATH D:\wamp64\www\y-code\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>