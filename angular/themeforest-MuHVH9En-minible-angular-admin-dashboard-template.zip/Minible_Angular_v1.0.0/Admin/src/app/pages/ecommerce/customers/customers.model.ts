export interface Customer {
    id: string;
    username: string;
    photo: string;
    email: string;
    status: string;
    date: string;
    index: number;
}
