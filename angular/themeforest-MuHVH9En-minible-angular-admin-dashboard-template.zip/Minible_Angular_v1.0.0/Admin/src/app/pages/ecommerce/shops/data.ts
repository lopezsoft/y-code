const shopsData = [
    {
        title: 'Morrie Mages',
        account: 'Clifton Taylor',
        poducts: 94,
        balance: '$9,852',
        color: 'primary'
    },
    {
        title: 'Brendle\'s',
        account: 'Karl Early',
        poducts: 62,
        balance: '$7,952',
        color: 'warning'
    },
    {
        title: 'Tech Hifi',
        account: 'Marion Glaze',
        poducts: 40,
        balance: '$6,265',
        color: 'success'
    },
    {
        title: 'Lafayette',
        account: 'Brent Johnson',
        poducts: 51,
        balance: '$7,235',
        color: 'danger'
    },
    {
        title: 'Micro Design',
        account: 'Kimberly Martinez',
        poducts: 34,
        balance: '$4,223',
        color: 'info'
    },
    {
        title: 'Sportmart',
        account: 'Sarah Stewart',
        poducts: 43,
        balance: '$5,632',
        color: 'dark'
    },
    {
        title: 'Tech Hifi',
        account: 'Lauren Doyle',
        poducts: 40,
        balance: '$5,268',
        color: 'success'
    },
    {
        title: 'Brendle\'s',
        account: 'Elaina Torres',
        poducts: 31,
        balance: '$3,965',
        color: 'primary'
    },
    {
        title: 'Standard Sales',
        account: 'Willie Farber',
        poducts: 60,
        balance: '$7,425',
        color: 'warning'
    },
];

export { shopsData };
