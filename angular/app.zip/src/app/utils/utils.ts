
// Url del API
// const
//     APIURL      = "https://y-code.lopezsoft.net.co/api/v1";
// const
//     APPURL      = "https://y-code.lopezsoft.net.co";
const
  APIURL      = "http://y-code/api/v1";
const
  APPURL      = "http://y-code";
const
  APITOKEN    = "";

    export {APIURL};
    export {APITOKEN};
    export {APPURL};

