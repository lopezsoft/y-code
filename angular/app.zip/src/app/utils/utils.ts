
// Url del API
const
    // APIURL      = "https://matias-api.com.co/api/ubl2.1/",
    // APPURL      = "https://matias-api.com.co/",
    APIURL      = "http://y-code/api/ubl2.1/",
    APPURL      = "http://y-code/",
    APITOKEN    = "";

    export {APIURL};
    export {APITOKEN};
    export {APPURL};

