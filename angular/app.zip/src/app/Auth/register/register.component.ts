import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

// Services
import { MessagesService } from 'src/app/utils/messages.service';
import { ApiServerService } from 'src/app/utils/api-server.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
})
export class RegisterComponent implements OnInit {

  registerForm  : FormGroup;
  sendForm      : boolean;
  constructor(private fb: FormBuilder, private api: ApiServerService, private msg: MessagesService, private router: Router) {
    this.registerForm = this.fb.group({
      name            : ['',[Validators.required, Validators.minLength(12)]],
      password        : ['',[Validators.required, Validators.minLength(5)]],
      password_confirmation    : ['',[Validators.required, Validators.minLength(5)]],
      email           : ['',[Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]]
    });
  }
  ngOnInit(): void {
    let
      ele = document.getElementById('nb-global-spinner');
    // Ocultando la animación
    if (ele) {
      ele.classList.remove('spinner');
    }

    if(this.api.isAuthenticated()) {
      this.router.navigate(['/']);
    }

  }

  get invalidUserName(){
    return this.registerForm.get('name').invalid && this.registerForm.get('name').touched;
  }
  get invalidPassword(){
    return this.registerForm.get('password').invalid && this.registerForm.get('password').touched;
  }
  get invalidConfirmPassword(){
    return this.registerForm.get('password_confirmation').invalid && this.registerForm.get('password_confirmation').touched;
  }
  get invalidEmail(){
    return this.registerForm.get('email').invalid && this.registerForm.get('email').touched;
  }

  get sendFormVal(){
    return this.sendForm;
  }

  onValidPassword(){
    const passw1 = this.registerForm.get('password').value;
    const passw2 = this.registerForm.get('password_confirmation').value;
    return (passw2 === passw1) ? true : false;
  }

  onValidateForm(){
    Object.values(this.registerForm.controls).forEach(ele => {
      ele.markAllAsTouched();
    });
  }

  onSave() {
    let me  = this.registerForm,
        ts  = this;
    if(me.invalid){
      ts.onValidateForm();
      ts.msg.toastMessage('Campos en blanco','Por favor llene los campos del formulario.',4);
    }else{
      if(ts.onValidPassword()){
        ts.sendForm = true;
        ts.api.post('/auth/signup', me.value)
          .subscribe(resp => {
            ts.onResetForm();
            ts.msg.toastMessage('Registro exitoso.',resp['message'],0);
            ts.sendForm = false;
            ts.onValidateForm();
            window.location.reload();
          }, (err: any) => {
            ts.msg.toastMessage('Error',err['error']['message'],4);
            ts.sendForm = false;
            ts.onValidateForm();
            window.location.reload();
          });
      }else{
        ts.msg.toastMessage('Error en contraseñas.','Las contraseñas son diferentes.',4);
      }
    }
  }

  onResetForm(){
    this.registerForm.reset();
  }

}
