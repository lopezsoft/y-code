import { Component, OnInit, HostBinding } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

// Services
import { ApiServerService } from 'src/app/utils/api-server.service';
import { MessagesService } from 'src/app/utils/messages.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent implements OnInit {
  @HostBinding('class')
  classes = 'example-items-rows';

  loginForm: FormGroup;
  sendForm: boolean;
  constructor(private fb: FormBuilder, private api: ApiServerService, private msg: MessagesService, private router: Router ) {
    this.loginForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]],
      remember_me: [false]
    });
  }

  ngOnInit(): void {
    let
      ele = document.getElementById('nb-global-spinner');
    // Ocultando la animación
    if (ele) {
      ele.classList.remove('spinner');
    }

    if(this.api.isAuthenticated()) {
      this.router.navigate(['/']);
    }

  }

  get invalidPassword() {
    return this.loginForm.get('password').invalid && this.loginForm.get('password').touched;
  }

  get invalidEmail() {
    return this.loginForm.get('email').invalid && this.loginForm.get('email').touched;
  }

  get sendFormVal() {
    return this.sendForm;
  }

  onValidateForm() {
    Object.values(this.loginForm.controls).forEach(ele => {
      ele.markAllAsTouched();
    });
  }

  onSave() {
    let me = this.loginForm,
        ts = this;
    if (me.invalid) {
      ts.onValidateForm();
      ts.msg.toastMessage('Campos en blanco','Por favor llene los campos del formulario.',4);
    } else {
      ts.sendForm = true;
      ts.api.post('/auth/login', me.value)
        .subscribe(resp => {
          ts.msg.toastMessage('Iniciando sesión',resp['message'],0);
          localStorage.setItem('y-code-jwt', JSON.stringify(resp));
          ts.onResetForm();
          window.location.reload();
        }, (err: any) => {
          ts.msg.toastMessage('Error',err['error']['message'],4);
          ts.sendForm = false;
          window.location.reload();
          ts.onValidateForm();
        });
    }
  }

  onResetForm() {
    this.loginForm.reset();
  }

}
