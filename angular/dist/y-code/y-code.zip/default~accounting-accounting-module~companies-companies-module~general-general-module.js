(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~accounting-accounting-module~companies-companies-module~general-general-module"],{

/***/ "./node_modules/@ng-select/ng-select/__ivy_ngcc__/fesm2015/ng-select-ng-select.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@ng-select/ng-select/__ivy_ngcc__/fesm2015/ng-select-ng-select.js ***!
  \****************************************************************************************/
/*! exports provided: NgSelectComponent, NgSelectConfig, NgSelectModule, SELECTION_MODEL_FACTORY, ɵb, ɵc, ɵd, ɵe, ɵf, ɵg, ɵh, ɵi, ɵj, ɵk, ɵl, ɵm, ɵn, ɵo, ɵp, ɵq, ɵr, ɵs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgSelectComponent", function() { return NgSelectComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgSelectConfig", function() { return NgSelectConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgSelectModule", function() { return NgSelectModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SELECTION_MODEL_FACTORY", function() { return SELECTION_MODEL_FACTORY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵb", function() { return DefaultSelectionModelFactory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵc", function() { return DefaultSelectionModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵd", function() { return NgDropdownPanelService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵe", function() { return NgItemLabelDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵf", function() { return NgOptionTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵg", function() { return NgOptgroupTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵh", function() { return NgLabelTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵi", function() { return NgMultiLabelTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵj", function() { return NgHeaderTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵk", function() { return NgFooterTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵl", function() { return NgNotFoundTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵm", function() { return NgTypeToSearchTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵn", function() { return NgLoadingTextTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵo", function() { return NgTagTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵp", function() { return NgLoadingSpinnerTemplateDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵq", function() { return NgDropdownPanelComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵr", function() { return NgOptionComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵs", function() { return ConsoleService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");






/**
 * @fileoverview added by tsickle
 * Generated from: lib/value-utils.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */



const _c0 = ["content"];
const _c1 = ["scroll"];
const _c2 = ["padding"];
const _c3 = function (a0) { return { searchTerm: a0 }; };
function NgDropdownPanelComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.headerTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c3, ctx_r0.filterValue));
} }
function NgDropdownPanelComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r4.footerTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c3, ctx_r4.filterValue));
} }
const _c4 = ["*"];
const _c5 = ["searchInput"];
function NgSelectComponent_ng_container_4_div_1_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NgSelectComponent_ng_container_4_div_1_ng_template_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13); const item_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r11.unselect(item_r7); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "span", 16);
} if (rf & 2) {
    const item_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngItemLabel", item_r7.label)("escape", ctx_r9.escapeHTML);
} }
function NgSelectComponent_ng_container_4_div_1_ng_template_3_Template(rf, ctx) { }
const _c6 = function (a0, a1, a2) { return { item: a0, clear: a1, label: a2 }; };
function NgSelectComponent_ng_container_4_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_container_4_div_1_ng_template_1_Template, 3, 2, "ng-template", null, 13, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_container_4_div_1_ng_template_3_Template, 0, 0, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-value-disabled", item_r7.disabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r6.labelTemplate || _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](4, _c6, item_r7.value, ctx_r6.clearItem, item_r7.label));
} }
function NgSelectComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_container_4_div_1_Template, 4, 8, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.selectedItems)("ngForTrackBy", ctx_r0.trackByOption);
} }
function NgSelectComponent_5_ng_template_0_Template(rf, ctx) { }
const _c7 = function (a0, a1) { return { items: a0, clear: a1 }; };
function NgSelectComponent_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, NgSelectComponent_5_ng_template_0_Template, 0, 0, "ng-template", 14);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.multiLabelTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c7, ctx_r1.selectedValues, ctx_r1.clearItem));
} }
function NgSelectComponent_ng_container_9_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 19);
} }
function NgSelectComponent_ng_container_9_ng_template_3_Template(rf, ctx) { }
function NgSelectComponent_ng_container_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_container_9_ng_template_1_Template, 1, 0, "ng-template", null, 17, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_container_9_ng_template_3_Template, 0, 0, "ng-template", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r3.loadingSpinnerTemplate || _r16);
} }
function NgSelectComponent_span_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("title", ctx_r4.clearAllText);
} }
function NgSelectComponent_ng_dropdown_panel_13_div_2_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 27);
} if (rf & 2) {
    const item_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngItemLabel", item_r24.label)("escape", ctx_r26.escapeHTML);
} }
function NgSelectComponent_ng_dropdown_panel_13_div_2_ng_template_3_Template(rf, ctx) { }
const _c8 = function (a0, a1, a2, a3) { return { item: a0, item$: a1, index: a2, searchTerm: a3 }; };
function NgSelectComponent_ng_dropdown_panel_13_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NgSelectComponent_ng_dropdown_panel_13_div_2_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30); const item_r24 = ctx.$implicit; const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r29.toggleItem(item_r24); })("mouseover", function NgSelectComponent_ng_dropdown_panel_13_div_2_Template_div_mouseover_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30); const item_r24 = ctx.$implicit; const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r31.onItemHover(item_r24); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_dropdown_panel_13_div_2_ng_template_1_Template, 1, 2, "ng-template", null, 26, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_div_2_ng_template_3_Template, 0, 0, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r24 = ctx.$implicit;
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-option-disabled", item_r24.disabled)("ng-option-selected", item_r24.selected)("ng-optgroup", item_r24.children)("ng-option", !item_r24.children)("ng-option-child", !!item_r24.parent)("ng-option-marked", item_r24 === ctx_r19.itemsList.markedItem);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("role", item_r24.children ? "group" : "option")("aria-selected", item_r24.selected)("id", item_r24 == null ? null : item_r24.htmlId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", item_r24.children ? ctx_r19.optgroupTemplate || _r25 : ctx_r19.optionTemplate || _r25)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](17, _c8, item_r24.value, item_r24, item_r24.index, ctx_r19.searchTerm));
} }
function NgSelectComponent_ng_dropdown_panel_13_div_3_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r33.addTagText);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("\"", ctx_r33.searchTerm, "\"");
} }
function NgSelectComponent_ng_dropdown_panel_13_div_3_ng_template_3_Template(rf, ctx) { }
function NgSelectComponent_ng_dropdown_panel_13_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mouseover", function NgSelectComponent_ng_dropdown_panel_13_div_3_Template_div_mouseover_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r36); const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r35.itemsList.unmarkItem(); })("click", function NgSelectComponent_ng_dropdown_panel_13_div_3_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r36); const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r37.selectTag(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_dropdown_panel_13_div_3_ng_template_1_Template, 4, 2, "ng-template", null, 29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_div_3_ng_template_3_Template, 0, 0, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-option-marked", !ctx_r20.itemsList.markedItem);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r20.tagTemplate || _r32)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c3, ctx_r20.searchTerm));
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_4_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r39.notFoundText);
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_4_ng_template_3_Template(rf, ctx) { }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_dropdown_panel_13_ng_container_4_ng_template_1_Template, 2, 1, "ng-template", null, 31, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_ng_container_4_ng_template_3_Template, 0, 0, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r21.notFoundTemplate || _r38)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c3, ctx_r21.searchTerm));
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_5_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r42.typeToSearchText);
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_5_ng_template_3_Template(rf, ctx) { }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_dropdown_panel_13_ng_container_5_ng_template_1_Template, 2, 1, "ng-template", null, 33, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_ng_container_5_ng_template_3_Template, 0, 0, "ng-template", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r22.typeToSearchTemplate || _r41);
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_6_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r45.loadingText);
} }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_6_ng_template_3_Template(rf, ctx) { }
function NgSelectComponent_ng_dropdown_panel_13_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NgSelectComponent_ng_dropdown_panel_13_ng_container_6_ng_template_1_Template, 2, 1, "ng-template", null, 34, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_ng_container_6_ng_template_3_Template, 0, 0, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r23.loadingTextTemplate || _r44)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c3, ctx_r23.searchTerm));
} }
function NgSelectComponent_ng_dropdown_panel_13_Template(rf, ctx) { if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ng-dropdown-panel", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("update", function NgSelectComponent_ng_dropdown_panel_13_Template_ng_dropdown_panel_update_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r47.viewPortItems = $event; })("scroll", function NgSelectComponent_ng_dropdown_panel_13_Template_ng_dropdown_panel_scroll_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r49.scroll.emit($event); })("scrollToEnd", function NgSelectComponent_ng_dropdown_panel_13_Template_ng_dropdown_panel_scrollToEnd_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r50.scrollToEnd.emit($event); })("outsideClick", function NgSelectComponent_ng_dropdown_panel_13_Template_ng_dropdown_panel_outsideClick_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r51.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, NgSelectComponent_ng_dropdown_panel_13_div_2_Template, 4, 22, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, NgSelectComponent_ng_dropdown_panel_13_div_3_Template, 4, 6, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, NgSelectComponent_ng_dropdown_panel_13_ng_container_4_Template, 4, 4, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, NgSelectComponent_ng_dropdown_panel_13_ng_container_5_Template, 4, 1, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, NgSelectComponent_ng_dropdown_panel_13_ng_container_6_Template, 4, 4, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-select-multiple", ctx_r5.multiple);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("virtualScroll", ctx_r5.virtualScroll)("bufferAmount", ctx_r5.bufferAmount)("appendTo", ctx_r5.appendTo)("position", ctx_r5.dropdownPosition)("headerTemplate", ctx_r5.headerTemplate)("footerTemplate", ctx_r5.footerTemplate)("filterValue", ctx_r5.searchTerm)("items", ctx_r5.itemsList.filteredItems)("markedItem", ctx_r5.itemsList.markedItem)("ngClass", ctx_r5.appendTo ? ctx_r5.classes : null)("id", ctx_r5.dropdownId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r5.viewPortItems)("ngForTrackBy", ctx_r5.trackByOption);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.showAddTag);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.showNoItemsFound());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.showTypeToSearch());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.loading && ctx_r5.itemsList.filteredItems.length === 0);
} }
const unescapedHTMLExp = /[&<>"']/g;
/** @type {?} */
const hasUnescapedHTMLExp = RegExp(unescapedHTMLExp.source);
/** @type {?} */
const htmlEscapes = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    '\'': '&#39;'
};
/**
 * @param {?} string
 * @return {?}
 */
function escapeHTML(string) {
    return (string && hasUnescapedHTMLExp.test(string)) ?
        string.replace(unescapedHTMLExp, (/**
         * @param {?} chr
         * @return {?}
         */
        chr => htmlEscapes[chr])) :
        string;
}
/**
 * @param {?} value
 * @return {?}
 */
function isDefined(value) {
    return value !== undefined && value !== null;
}
/**
 * @param {?} value
 * @return {?}
 */
function isObject(value) {
    return typeof value === 'object' && isDefined(value);
}
/**
 * @param {?} value
 * @return {?}
 */
function isPromise(value) {
    return value instanceof Promise;
}
/**
 * @param {?} value
 * @return {?}
 */
function isFunction(value) {
    return value instanceof Function;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-templates.directive.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgItemLabelDirective {
    /**
     * @param {?} element
     */
    constructor(element) {
        this.element = element;
        this.escape = true;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        this.element.nativeElement.innerHTML = this.escape ?
            escapeHTML(this.ngItemLabel) :
            this.ngItemLabel;
    }
}
NgItemLabelDirective.ɵfac = function NgItemLabelDirective_Factory(t) { return new (t || NgItemLabelDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])); };
NgItemLabelDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgItemLabelDirective, selectors: [["", "ngItemLabel", ""]], inputs: { escape: "escape", ngItemLabel: "ngItemLabel" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]] });
/** @nocollapse */
NgItemLabelDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }
];
NgItemLabelDirective.propDecorators = {
    ngItemLabel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    escape: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgItemLabelDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ngItemLabel]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }]; }, { escape: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ngItemLabel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();
if (false) {}
class NgOptionTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgOptionTemplateDirective.ɵfac = function NgOptionTemplateDirective_Factory(t) { return new (t || NgOptionTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgOptionTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgOptionTemplateDirective, selectors: [["", "ng-option-tmp", ""]] });
/** @nocollapse */
NgOptionTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgOptionTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-option-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgOptgroupTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgOptgroupTemplateDirective.ɵfac = function NgOptgroupTemplateDirective_Factory(t) { return new (t || NgOptgroupTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgOptgroupTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgOptgroupTemplateDirective, selectors: [["", "ng-optgroup-tmp", ""]] });
/** @nocollapse */
NgOptgroupTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgOptgroupTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-optgroup-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgLabelTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgLabelTemplateDirective.ɵfac = function NgLabelTemplateDirective_Factory(t) { return new (t || NgLabelTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgLabelTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgLabelTemplateDirective, selectors: [["", "ng-label-tmp", ""]] });
/** @nocollapse */
NgLabelTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgLabelTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-label-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgMultiLabelTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgMultiLabelTemplateDirective.ɵfac = function NgMultiLabelTemplateDirective_Factory(t) { return new (t || NgMultiLabelTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgMultiLabelTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgMultiLabelTemplateDirective, selectors: [["", "ng-multi-label-tmp", ""]] });
/** @nocollapse */
NgMultiLabelTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgMultiLabelTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-multi-label-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgHeaderTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgHeaderTemplateDirective.ɵfac = function NgHeaderTemplateDirective_Factory(t) { return new (t || NgHeaderTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgHeaderTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgHeaderTemplateDirective, selectors: [["", "ng-header-tmp", ""]] });
/** @nocollapse */
NgHeaderTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgHeaderTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-header-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgFooterTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgFooterTemplateDirective.ɵfac = function NgFooterTemplateDirective_Factory(t) { return new (t || NgFooterTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgFooterTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgFooterTemplateDirective, selectors: [["", "ng-footer-tmp", ""]] });
/** @nocollapse */
NgFooterTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgFooterTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-footer-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgNotFoundTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgNotFoundTemplateDirective.ɵfac = function NgNotFoundTemplateDirective_Factory(t) { return new (t || NgNotFoundTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgNotFoundTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgNotFoundTemplateDirective, selectors: [["", "ng-notfound-tmp", ""]] });
/** @nocollapse */
NgNotFoundTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgNotFoundTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-notfound-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgTypeToSearchTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgTypeToSearchTemplateDirective.ɵfac = function NgTypeToSearchTemplateDirective_Factory(t) { return new (t || NgTypeToSearchTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgTypeToSearchTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgTypeToSearchTemplateDirective, selectors: [["", "ng-typetosearch-tmp", ""]] });
/** @nocollapse */
NgTypeToSearchTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgTypeToSearchTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-typetosearch-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgLoadingTextTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgLoadingTextTemplateDirective.ɵfac = function NgLoadingTextTemplateDirective_Factory(t) { return new (t || NgLoadingTextTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgLoadingTextTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgLoadingTextTemplateDirective, selectors: [["", "ng-loadingtext-tmp", ""]] });
/** @nocollapse */
NgLoadingTextTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgLoadingTextTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-loadingtext-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgTagTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgTagTemplateDirective.ɵfac = function NgTagTemplateDirective_Factory(t) { return new (t || NgTagTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgTagTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgTagTemplateDirective, selectors: [["", "ng-tag-tmp", ""]] });
/** @nocollapse */
NgTagTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgTagTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-tag-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}
class NgLoadingSpinnerTemplateDirective {
    /**
     * @param {?} template
     */
    constructor(template) {
        this.template = template;
    }
}
NgLoadingSpinnerTemplateDirective.ɵfac = function NgLoadingSpinnerTemplateDirective_Factory(t) { return new (t || NgLoadingSpinnerTemplateDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])); };
NgLoadingSpinnerTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: NgLoadingSpinnerTemplateDirective, selectors: [["", "ng-loadingspinner-tmp", ""]] });
/** @nocollapse */
NgLoadingSpinnerTemplateDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }
];
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgLoadingSpinnerTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{ selector: '[ng-loadingspinner-tmp]' }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]; }, null); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/console.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ConsoleService {
    /**
     * @param {?} message
     * @return {?}
     */
    warn(message) {
        console.warn(message);
    }
}
ConsoleService.ɵfac = function ConsoleService_Factory(t) { return new (t || ConsoleService)(); };
/** @nocollapse */ ConsoleService.ɵprov = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({ factory: function ConsoleService_Factory() { return new ConsoleService(); }, token: ConsoleService, providedIn: "root" });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ConsoleService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{ providedIn: 'root' }]
    }], null, null); })();

/**
 * @fileoverview added by tsickle
 * Generated from: lib/id.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @return {?}
 */
function newId() {
    // First character is an 'a', it's good practice to tag id to begin with a letter
    return 'axxxxxxxxxxx'.replace(/[x]/g, (/**
     * @param {?} _
     * @return {?}
     */
    function (_) {
        // tslint:disable-next-line:no-bitwise
        /** @type {?} */
        const val = Math.random() * 16 | 0;
        return val.toString(16);
    }));
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/search-helper.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const diacritics = {
    '\u24B6': 'A',
    '\uFF21': 'A',
    '\u00C0': 'A',
    '\u00C1': 'A',
    '\u00C2': 'A',
    '\u1EA6': 'A',
    '\u1EA4': 'A',
    '\u1EAA': 'A',
    '\u1EA8': 'A',
    '\u00C3': 'A',
    '\u0100': 'A',
    '\u0102': 'A',
    '\u1EB0': 'A',
    '\u1EAE': 'A',
    '\u1EB4': 'A',
    '\u1EB2': 'A',
    '\u0226': 'A',
    '\u01E0': 'A',
    '\u00C4': 'A',
    '\u01DE': 'A',
    '\u1EA2': 'A',
    '\u00C5': 'A',
    '\u01FA': 'A',
    '\u01CD': 'A',
    '\u0200': 'A',
    '\u0202': 'A',
    '\u1EA0': 'A',
    '\u1EAC': 'A',
    '\u1EB6': 'A',
    '\u1E00': 'A',
    '\u0104': 'A',
    '\u023A': 'A',
    '\u2C6F': 'A',
    '\uA732': 'AA',
    '\u00C6': 'AE',
    '\u01FC': 'AE',
    '\u01E2': 'AE',
    '\uA734': 'AO',
    '\uA736': 'AU',
    '\uA738': 'AV',
    '\uA73A': 'AV',
    '\uA73C': 'AY',
    '\u24B7': 'B',
    '\uFF22': 'B',
    '\u1E02': 'B',
    '\u1E04': 'B',
    '\u1E06': 'B',
    '\u0243': 'B',
    '\u0182': 'B',
    '\u0181': 'B',
    '\u24B8': 'C',
    '\uFF23': 'C',
    '\u0106': 'C',
    '\u0108': 'C',
    '\u010A': 'C',
    '\u010C': 'C',
    '\u00C7': 'C',
    '\u1E08': 'C',
    '\u0187': 'C',
    '\u023B': 'C',
    '\uA73E': 'C',
    '\u24B9': 'D',
    '\uFF24': 'D',
    '\u1E0A': 'D',
    '\u010E': 'D',
    '\u1E0C': 'D',
    '\u1E10': 'D',
    '\u1E12': 'D',
    '\u1E0E': 'D',
    '\u0110': 'D',
    '\u018B': 'D',
    '\u018A': 'D',
    '\u0189': 'D',
    '\uA779': 'D',
    '\u01F1': 'DZ',
    '\u01C4': 'DZ',
    '\u01F2': 'Dz',
    '\u01C5': 'Dz',
    '\u24BA': 'E',
    '\uFF25': 'E',
    '\u00C8': 'E',
    '\u00C9': 'E',
    '\u00CA': 'E',
    '\u1EC0': 'E',
    '\u1EBE': 'E',
    '\u1EC4': 'E',
    '\u1EC2': 'E',
    '\u1EBC': 'E',
    '\u0112': 'E',
    '\u1E14': 'E',
    '\u1E16': 'E',
    '\u0114': 'E',
    '\u0116': 'E',
    '\u00CB': 'E',
    '\u1EBA': 'E',
    '\u011A': 'E',
    '\u0204': 'E',
    '\u0206': 'E',
    '\u1EB8': 'E',
    '\u1EC6': 'E',
    '\u0228': 'E',
    '\u1E1C': 'E',
    '\u0118': 'E',
    '\u1E18': 'E',
    '\u1E1A': 'E',
    '\u0190': 'E',
    '\u018E': 'E',
    '\u24BB': 'F',
    '\uFF26': 'F',
    '\u1E1E': 'F',
    '\u0191': 'F',
    '\uA77B': 'F',
    '\u24BC': 'G',
    '\uFF27': 'G',
    '\u01F4': 'G',
    '\u011C': 'G',
    '\u1E20': 'G',
    '\u011E': 'G',
    '\u0120': 'G',
    '\u01E6': 'G',
    '\u0122': 'G',
    '\u01E4': 'G',
    '\u0193': 'G',
    '\uA7A0': 'G',
    '\uA77D': 'G',
    '\uA77E': 'G',
    '\u24BD': 'H',
    '\uFF28': 'H',
    '\u0124': 'H',
    '\u1E22': 'H',
    '\u1E26': 'H',
    '\u021E': 'H',
    '\u1E24': 'H',
    '\u1E28': 'H',
    '\u1E2A': 'H',
    '\u0126': 'H',
    '\u2C67': 'H',
    '\u2C75': 'H',
    '\uA78D': 'H',
    '\u24BE': 'I',
    '\uFF29': 'I',
    '\u00CC': 'I',
    '\u00CD': 'I',
    '\u00CE': 'I',
    '\u0128': 'I',
    '\u012A': 'I',
    '\u012C': 'I',
    '\u0130': 'I',
    '\u00CF': 'I',
    '\u1E2E': 'I',
    '\u1EC8': 'I',
    '\u01CF': 'I',
    '\u0208': 'I',
    '\u020A': 'I',
    '\u1ECA': 'I',
    '\u012E': 'I',
    '\u1E2C': 'I',
    '\u0197': 'I',
    '\u24BF': 'J',
    '\uFF2A': 'J',
    '\u0134': 'J',
    '\u0248': 'J',
    '\u24C0': 'K',
    '\uFF2B': 'K',
    '\u1E30': 'K',
    '\u01E8': 'K',
    '\u1E32': 'K',
    '\u0136': 'K',
    '\u1E34': 'K',
    '\u0198': 'K',
    '\u2C69': 'K',
    '\uA740': 'K',
    '\uA742': 'K',
    '\uA744': 'K',
    '\uA7A2': 'K',
    '\u24C1': 'L',
    '\uFF2C': 'L',
    '\u013F': 'L',
    '\u0139': 'L',
    '\u013D': 'L',
    '\u1E36': 'L',
    '\u1E38': 'L',
    '\u013B': 'L',
    '\u1E3C': 'L',
    '\u1E3A': 'L',
    '\u0141': 'L',
    '\u023D': 'L',
    '\u2C62': 'L',
    '\u2C60': 'L',
    '\uA748': 'L',
    '\uA746': 'L',
    '\uA780': 'L',
    '\u01C7': 'LJ',
    '\u01C8': 'Lj',
    '\u24C2': 'M',
    '\uFF2D': 'M',
    '\u1E3E': 'M',
    '\u1E40': 'M',
    '\u1E42': 'M',
    '\u2C6E': 'M',
    '\u019C': 'M',
    '\u24C3': 'N',
    '\uFF2E': 'N',
    '\u01F8': 'N',
    '\u0143': 'N',
    '\u00D1': 'N',
    '\u1E44': 'N',
    '\u0147': 'N',
    '\u1E46': 'N',
    '\u0145': 'N',
    '\u1E4A': 'N',
    '\u1E48': 'N',
    '\u0220': 'N',
    '\u019D': 'N',
    '\uA790': 'N',
    '\uA7A4': 'N',
    '\u01CA': 'NJ',
    '\u01CB': 'Nj',
    '\u24C4': 'O',
    '\uFF2F': 'O',
    '\u00D2': 'O',
    '\u00D3': 'O',
    '\u00D4': 'O',
    '\u1ED2': 'O',
    '\u1ED0': 'O',
    '\u1ED6': 'O',
    '\u1ED4': 'O',
    '\u00D5': 'O',
    '\u1E4C': 'O',
    '\u022C': 'O',
    '\u1E4E': 'O',
    '\u014C': 'O',
    '\u1E50': 'O',
    '\u1E52': 'O',
    '\u014E': 'O',
    '\u022E': 'O',
    '\u0230': 'O',
    '\u00D6': 'O',
    '\u022A': 'O',
    '\u1ECE': 'O',
    '\u0150': 'O',
    '\u01D1': 'O',
    '\u020C': 'O',
    '\u020E': 'O',
    '\u01A0': 'O',
    '\u1EDC': 'O',
    '\u1EDA': 'O',
    '\u1EE0': 'O',
    '\u1EDE': 'O',
    '\u1EE2': 'O',
    '\u1ECC': 'O',
    '\u1ED8': 'O',
    '\u01EA': 'O',
    '\u01EC': 'O',
    '\u00D8': 'O',
    '\u01FE': 'O',
    '\u0186': 'O',
    '\u019F': 'O',
    '\uA74A': 'O',
    '\uA74C': 'O',
    '\u01A2': 'OI',
    '\uA74E': 'OO',
    '\u0222': 'OU',
    '\u24C5': 'P',
    '\uFF30': 'P',
    '\u1E54': 'P',
    '\u1E56': 'P',
    '\u01A4': 'P',
    '\u2C63': 'P',
    '\uA750': 'P',
    '\uA752': 'P',
    '\uA754': 'P',
    '\u24C6': 'Q',
    '\uFF31': 'Q',
    '\uA756': 'Q',
    '\uA758': 'Q',
    '\u024A': 'Q',
    '\u24C7': 'R',
    '\uFF32': 'R',
    '\u0154': 'R',
    '\u1E58': 'R',
    '\u0158': 'R',
    '\u0210': 'R',
    '\u0212': 'R',
    '\u1E5A': 'R',
    '\u1E5C': 'R',
    '\u0156': 'R',
    '\u1E5E': 'R',
    '\u024C': 'R',
    '\u2C64': 'R',
    '\uA75A': 'R',
    '\uA7A6': 'R',
    '\uA782': 'R',
    '\u24C8': 'S',
    '\uFF33': 'S',
    '\u1E9E': 'S',
    '\u015A': 'S',
    '\u1E64': 'S',
    '\u015C': 'S',
    '\u1E60': 'S',
    '\u0160': 'S',
    '\u1E66': 'S',
    '\u1E62': 'S',
    '\u1E68': 'S',
    '\u0218': 'S',
    '\u015E': 'S',
    '\u2C7E': 'S',
    '\uA7A8': 'S',
    '\uA784': 'S',
    '\u24C9': 'T',
    '\uFF34': 'T',
    '\u1E6A': 'T',
    '\u0164': 'T',
    '\u1E6C': 'T',
    '\u021A': 'T',
    '\u0162': 'T',
    '\u1E70': 'T',
    '\u1E6E': 'T',
    '\u0166': 'T',
    '\u01AC': 'T',
    '\u01AE': 'T',
    '\u023E': 'T',
    '\uA786': 'T',
    '\uA728': 'TZ',
    '\u24CA': 'U',
    '\uFF35': 'U',
    '\u00D9': 'U',
    '\u00DA': 'U',
    '\u00DB': 'U',
    '\u0168': 'U',
    '\u1E78': 'U',
    '\u016A': 'U',
    '\u1E7A': 'U',
    '\u016C': 'U',
    '\u00DC': 'U',
    '\u01DB': 'U',
    '\u01D7': 'U',
    '\u01D5': 'U',
    '\u01D9': 'U',
    '\u1EE6': 'U',
    '\u016E': 'U',
    '\u0170': 'U',
    '\u01D3': 'U',
    '\u0214': 'U',
    '\u0216': 'U',
    '\u01AF': 'U',
    '\u1EEA': 'U',
    '\u1EE8': 'U',
    '\u1EEE': 'U',
    '\u1EEC': 'U',
    '\u1EF0': 'U',
    '\u1EE4': 'U',
    '\u1E72': 'U',
    '\u0172': 'U',
    '\u1E76': 'U',
    '\u1E74': 'U',
    '\u0244': 'U',
    '\u24CB': 'V',
    '\uFF36': 'V',
    '\u1E7C': 'V',
    '\u1E7E': 'V',
    '\u01B2': 'V',
    '\uA75E': 'V',
    '\u0245': 'V',
    '\uA760': 'VY',
    '\u24CC': 'W',
    '\uFF37': 'W',
    '\u1E80': 'W',
    '\u1E82': 'W',
    '\u0174': 'W',
    '\u1E86': 'W',
    '\u1E84': 'W',
    '\u1E88': 'W',
    '\u2C72': 'W',
    '\u24CD': 'X',
    '\uFF38': 'X',
    '\u1E8A': 'X',
    '\u1E8C': 'X',
    '\u24CE': 'Y',
    '\uFF39': 'Y',
    '\u1EF2': 'Y',
    '\u00DD': 'Y',
    '\u0176': 'Y',
    '\u1EF8': 'Y',
    '\u0232': 'Y',
    '\u1E8E': 'Y',
    '\u0178': 'Y',
    '\u1EF6': 'Y',
    '\u1EF4': 'Y',
    '\u01B3': 'Y',
    '\u024E': 'Y',
    '\u1EFE': 'Y',
    '\u24CF': 'Z',
    '\uFF3A': 'Z',
    '\u0179': 'Z',
    '\u1E90': 'Z',
    '\u017B': 'Z',
    '\u017D': 'Z',
    '\u1E92': 'Z',
    '\u1E94': 'Z',
    '\u01B5': 'Z',
    '\u0224': 'Z',
    '\u2C7F': 'Z',
    '\u2C6B': 'Z',
    '\uA762': 'Z',
    '\u24D0': 'a',
    '\uFF41': 'a',
    '\u1E9A': 'a',
    '\u00E0': 'a',
    '\u00E1': 'a',
    '\u00E2': 'a',
    '\u1EA7': 'a',
    '\u1EA5': 'a',
    '\u1EAB': 'a',
    '\u1EA9': 'a',
    '\u00E3': 'a',
    '\u0101': 'a',
    '\u0103': 'a',
    '\u1EB1': 'a',
    '\u1EAF': 'a',
    '\u1EB5': 'a',
    '\u1EB3': 'a',
    '\u0227': 'a',
    '\u01E1': 'a',
    '\u00E4': 'a',
    '\u01DF': 'a',
    '\u1EA3': 'a',
    '\u00E5': 'a',
    '\u01FB': 'a',
    '\u01CE': 'a',
    '\u0201': 'a',
    '\u0203': 'a',
    '\u1EA1': 'a',
    '\u1EAD': 'a',
    '\u1EB7': 'a',
    '\u1E01': 'a',
    '\u0105': 'a',
    '\u2C65': 'a',
    '\u0250': 'a',
    '\uA733': 'aa',
    '\u00E6': 'ae',
    '\u01FD': 'ae',
    '\u01E3': 'ae',
    '\uA735': 'ao',
    '\uA737': 'au',
    '\uA739': 'av',
    '\uA73B': 'av',
    '\uA73D': 'ay',
    '\u24D1': 'b',
    '\uFF42': 'b',
    '\u1E03': 'b',
    '\u1E05': 'b',
    '\u1E07': 'b',
    '\u0180': 'b',
    '\u0183': 'b',
    '\u0253': 'b',
    '\u24D2': 'c',
    '\uFF43': 'c',
    '\u0107': 'c',
    '\u0109': 'c',
    '\u010B': 'c',
    '\u010D': 'c',
    '\u00E7': 'c',
    '\u1E09': 'c',
    '\u0188': 'c',
    '\u023C': 'c',
    '\uA73F': 'c',
    '\u2184': 'c',
    '\u24D3': 'd',
    '\uFF44': 'd',
    '\u1E0B': 'd',
    '\u010F': 'd',
    '\u1E0D': 'd',
    '\u1E11': 'd',
    '\u1E13': 'd',
    '\u1E0F': 'd',
    '\u0111': 'd',
    '\u018C': 'd',
    '\u0256': 'd',
    '\u0257': 'd',
    '\uA77A': 'd',
    '\u01F3': 'dz',
    '\u01C6': 'dz',
    '\u24D4': 'e',
    '\uFF45': 'e',
    '\u00E8': 'e',
    '\u00E9': 'e',
    '\u00EA': 'e',
    '\u1EC1': 'e',
    '\u1EBF': 'e',
    '\u1EC5': 'e',
    '\u1EC3': 'e',
    '\u1EBD': 'e',
    '\u0113': 'e',
    '\u1E15': 'e',
    '\u1E17': 'e',
    '\u0115': 'e',
    '\u0117': 'e',
    '\u00EB': 'e',
    '\u1EBB': 'e',
    '\u011B': 'e',
    '\u0205': 'e',
    '\u0207': 'e',
    '\u1EB9': 'e',
    '\u1EC7': 'e',
    '\u0229': 'e',
    '\u1E1D': 'e',
    '\u0119': 'e',
    '\u1E19': 'e',
    '\u1E1B': 'e',
    '\u0247': 'e',
    '\u025B': 'e',
    '\u01DD': 'e',
    '\u24D5': 'f',
    '\uFF46': 'f',
    '\u1E1F': 'f',
    '\u0192': 'f',
    '\uA77C': 'f',
    '\u24D6': 'g',
    '\uFF47': 'g',
    '\u01F5': 'g',
    '\u011D': 'g',
    '\u1E21': 'g',
    '\u011F': 'g',
    '\u0121': 'g',
    '\u01E7': 'g',
    '\u0123': 'g',
    '\u01E5': 'g',
    '\u0260': 'g',
    '\uA7A1': 'g',
    '\u1D79': 'g',
    '\uA77F': 'g',
    '\u24D7': 'h',
    '\uFF48': 'h',
    '\u0125': 'h',
    '\u1E23': 'h',
    '\u1E27': 'h',
    '\u021F': 'h',
    '\u1E25': 'h',
    '\u1E29': 'h',
    '\u1E2B': 'h',
    '\u1E96': 'h',
    '\u0127': 'h',
    '\u2C68': 'h',
    '\u2C76': 'h',
    '\u0265': 'h',
    '\u0195': 'hv',
    '\u24D8': 'i',
    '\uFF49': 'i',
    '\u00EC': 'i',
    '\u00ED': 'i',
    '\u00EE': 'i',
    '\u0129': 'i',
    '\u012B': 'i',
    '\u012D': 'i',
    '\u00EF': 'i',
    '\u1E2F': 'i',
    '\u1EC9': 'i',
    '\u01D0': 'i',
    '\u0209': 'i',
    '\u020B': 'i',
    '\u1ECB': 'i',
    '\u012F': 'i',
    '\u1E2D': 'i',
    '\u0268': 'i',
    '\u0131': 'i',
    '\u24D9': 'j',
    '\uFF4A': 'j',
    '\u0135': 'j',
    '\u01F0': 'j',
    '\u0249': 'j',
    '\u24DA': 'k',
    '\uFF4B': 'k',
    '\u1E31': 'k',
    '\u01E9': 'k',
    '\u1E33': 'k',
    '\u0137': 'k',
    '\u1E35': 'k',
    '\u0199': 'k',
    '\u2C6A': 'k',
    '\uA741': 'k',
    '\uA743': 'k',
    '\uA745': 'k',
    '\uA7A3': 'k',
    '\u24DB': 'l',
    '\uFF4C': 'l',
    '\u0140': 'l',
    '\u013A': 'l',
    '\u013E': 'l',
    '\u1E37': 'l',
    '\u1E39': 'l',
    '\u013C': 'l',
    '\u1E3D': 'l',
    '\u1E3B': 'l',
    '\u017F': 'l',
    '\u0142': 'l',
    '\u019A': 'l',
    '\u026B': 'l',
    '\u2C61': 'l',
    '\uA749': 'l',
    '\uA781': 'l',
    '\uA747': 'l',
    '\u01C9': 'lj',
    '\u24DC': 'm',
    '\uFF4D': 'm',
    '\u1E3F': 'm',
    '\u1E41': 'm',
    '\u1E43': 'm',
    '\u0271': 'm',
    '\u026F': 'm',
    '\u24DD': 'n',
    '\uFF4E': 'n',
    '\u01F9': 'n',
    '\u0144': 'n',
    '\u00F1': 'n',
    '\u1E45': 'n',
    '\u0148': 'n',
    '\u1E47': 'n',
    '\u0146': 'n',
    '\u1E4B': 'n',
    '\u1E49': 'n',
    '\u019E': 'n',
    '\u0272': 'n',
    '\u0149': 'n',
    '\uA791': 'n',
    '\uA7A5': 'n',
    '\u01CC': 'nj',
    '\u24DE': 'o',
    '\uFF4F': 'o',
    '\u00F2': 'o',
    '\u00F3': 'o',
    '\u00F4': 'o',
    '\u1ED3': 'o',
    '\u1ED1': 'o',
    '\u1ED7': 'o',
    '\u1ED5': 'o',
    '\u00F5': 'o',
    '\u1E4D': 'o',
    '\u022D': 'o',
    '\u1E4F': 'o',
    '\u014D': 'o',
    '\u1E51': 'o',
    '\u1E53': 'o',
    '\u014F': 'o',
    '\u022F': 'o',
    '\u0231': 'o',
    '\u00F6': 'o',
    '\u022B': 'o',
    '\u1ECF': 'o',
    '\u0151': 'o',
    '\u01D2': 'o',
    '\u020D': 'o',
    '\u020F': 'o',
    '\u01A1': 'o',
    '\u1EDD': 'o',
    '\u1EDB': 'o',
    '\u1EE1': 'o',
    '\u1EDF': 'o',
    '\u1EE3': 'o',
    '\u1ECD': 'o',
    '\u1ED9': 'o',
    '\u01EB': 'o',
    '\u01ED': 'o',
    '\u00F8': 'o',
    '\u01FF': 'o',
    '\u0254': 'o',
    '\uA74B': 'o',
    '\uA74D': 'o',
    '\u0275': 'o',
    '\u01A3': 'oi',
    '\u0223': 'ou',
    '\uA74F': 'oo',
    '\u24DF': 'p',
    '\uFF50': 'p',
    '\u1E55': 'p',
    '\u1E57': 'p',
    '\u01A5': 'p',
    '\u1D7D': 'p',
    '\uA751': 'p',
    '\uA753': 'p',
    '\uA755': 'p',
    '\u24E0': 'q',
    '\uFF51': 'q',
    '\u024B': 'q',
    '\uA757': 'q',
    '\uA759': 'q',
    '\u24E1': 'r',
    '\uFF52': 'r',
    '\u0155': 'r',
    '\u1E59': 'r',
    '\u0159': 'r',
    '\u0211': 'r',
    '\u0213': 'r',
    '\u1E5B': 'r',
    '\u1E5D': 'r',
    '\u0157': 'r',
    '\u1E5F': 'r',
    '\u024D': 'r',
    '\u027D': 'r',
    '\uA75B': 'r',
    '\uA7A7': 'r',
    '\uA783': 'r',
    '\u24E2': 's',
    '\uFF53': 's',
    '\u00DF': 's',
    '\u015B': 's',
    '\u1E65': 's',
    '\u015D': 's',
    '\u1E61': 's',
    '\u0161': 's',
    '\u1E67': 's',
    '\u1E63': 's',
    '\u1E69': 's',
    '\u0219': 's',
    '\u015F': 's',
    '\u023F': 's',
    '\uA7A9': 's',
    '\uA785': 's',
    '\u1E9B': 's',
    '\u24E3': 't',
    '\uFF54': 't',
    '\u1E6B': 't',
    '\u1E97': 't',
    '\u0165': 't',
    '\u1E6D': 't',
    '\u021B': 't',
    '\u0163': 't',
    '\u1E71': 't',
    '\u1E6F': 't',
    '\u0167': 't',
    '\u01AD': 't',
    '\u0288': 't',
    '\u2C66': 't',
    '\uA787': 't',
    '\uA729': 'tz',
    '\u24E4': 'u',
    '\uFF55': 'u',
    '\u00F9': 'u',
    '\u00FA': 'u',
    '\u00FB': 'u',
    '\u0169': 'u',
    '\u1E79': 'u',
    '\u016B': 'u',
    '\u1E7B': 'u',
    '\u016D': 'u',
    '\u00FC': 'u',
    '\u01DC': 'u',
    '\u01D8': 'u',
    '\u01D6': 'u',
    '\u01DA': 'u',
    '\u1EE7': 'u',
    '\u016F': 'u',
    '\u0171': 'u',
    '\u01D4': 'u',
    '\u0215': 'u',
    '\u0217': 'u',
    '\u01B0': 'u',
    '\u1EEB': 'u',
    '\u1EE9': 'u',
    '\u1EEF': 'u',
    '\u1EED': 'u',
    '\u1EF1': 'u',
    '\u1EE5': 'u',
    '\u1E73': 'u',
    '\u0173': 'u',
    '\u1E77': 'u',
    '\u1E75': 'u',
    '\u0289': 'u',
    '\u24E5': 'v',
    '\uFF56': 'v',
    '\u1E7D': 'v',
    '\u1E7F': 'v',
    '\u028B': 'v',
    '\uA75F': 'v',
    '\u028C': 'v',
    '\uA761': 'vy',
    '\u24E6': 'w',
    '\uFF57': 'w',
    '\u1E81': 'w',
    '\u1E83': 'w',
    '\u0175': 'w',
    '\u1E87': 'w',
    '\u1E85': 'w',
    '\u1E98': 'w',
    '\u1E89': 'w',
    '\u2C73': 'w',
    '\u24E7': 'x',
    '\uFF58': 'x',
    '\u1E8B': 'x',
    '\u1E8D': 'x',
    '\u24E8': 'y',
    '\uFF59': 'y',
    '\u1EF3': 'y',
    '\u00FD': 'y',
    '\u0177': 'y',
    '\u1EF9': 'y',
    '\u0233': 'y',
    '\u1E8F': 'y',
    '\u00FF': 'y',
    '\u1EF7': 'y',
    '\u1E99': 'y',
    '\u1EF5': 'y',
    '\u01B4': 'y',
    '\u024F': 'y',
    '\u1EFF': 'y',
    '\u24E9': 'z',
    '\uFF5A': 'z',
    '\u017A': 'z',
    '\u1E91': 'z',
    '\u017C': 'z',
    '\u017E': 'z',
    '\u1E93': 'z',
    '\u1E95': 'z',
    '\u01B6': 'z',
    '\u0225': 'z',
    '\u0240': 'z',
    '\u2C6C': 'z',
    '\uA763': 'z',
    '\u0386': '\u0391',
    '\u0388': '\u0395',
    '\u0389': '\u0397',
    '\u038A': '\u0399',
    '\u03AA': '\u0399',
    '\u038C': '\u039F',
    '\u038E': '\u03A5',
    '\u03AB': '\u03A5',
    '\u038F': '\u03A9',
    '\u03AC': '\u03B1',
    '\u03AD': '\u03B5',
    '\u03AE': '\u03B7',
    '\u03AF': '\u03B9',
    '\u03CA': '\u03B9',
    '\u0390': '\u03B9',
    '\u03CC': '\u03BF',
    '\u03CD': '\u03C5',
    '\u03CB': '\u03C5',
    '\u03B0': '\u03C5',
    '\u03C9': '\u03C9',
    '\u03C2': '\u03C3'
};
/**
 * @param {?} text
 * @return {?}
 */
function stripSpecialChars(text) {
    /** @type {?} */
    const match = (/**
     * @param {?} a
     * @return {?}
     */
    (a) => {
        return diacritics[a] || a;
    });
    return text.replace(/[^\u0000-\u007E]/g, match);
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/items-list.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ItemsList {
    /**
     * @param {?} _ngSelect
     * @param {?} _selectionModel
     */
    constructor(_ngSelect, _selectionModel) {
        this._ngSelect = _ngSelect;
        this._selectionModel = _selectionModel;
        this._items = [];
        this._filteredItems = [];
        this._markedIndex = -1;
    }
    /**
     * @return {?}
     */
    get items() {
        return this._items;
    }
    /**
     * @return {?}
     */
    get filteredItems() {
        return this._filteredItems;
    }
    /**
     * @return {?}
     */
    get markedIndex() {
        return this._markedIndex;
    }
    /**
     * @return {?}
     */
    get selectedItems() {
        return this._selectionModel.value;
    }
    /**
     * @return {?}
     */
    get markedItem() {
        return this._filteredItems[this._markedIndex];
    }
    /**
     * @return {?}
     */
    get noItemsToSelect() {
        return this._ngSelect.hideSelected && this._items.length === this.selectedItems.length;
    }
    /**
     * @return {?}
     */
    get maxItemsSelected() {
        return this._ngSelect.multiple && this._ngSelect.maxSelectedItems <= this.selectedItems.length;
    }
    /**
     * @return {?}
     */
    get lastSelectedItem() {
        /** @type {?} */
        let i = this.selectedItems.length - 1;
        for (; i >= 0; i--) {
            /** @type {?} */
            let item = this.selectedItems[i];
            if (!item.disabled) {
                return item;
            }
        }
        return null;
    }
    /**
     * @param {?} items
     * @return {?}
     */
    setItems(items) {
        this._items = items.map((/**
         * @param {?} item
         * @param {?} index
         * @return {?}
         */
        (item, index) => this.mapItem(item, index)));
        if (this._ngSelect.groupBy) {
            this._groups = this._groupBy(this._items, this._ngSelect.groupBy);
            this._items = this._flatten(this._groups);
        }
        else {
            this._groups = new Map();
            this._groups.set(undefined, this._items);
        }
        this._filteredItems = [...this._items];
    }
    /**
     * @param {?} item
     * @return {?}
     */
    select(item) {
        if (item.selected || this.maxItemsSelected) {
            return;
        }
        /** @type {?} */
        const multiple = this._ngSelect.multiple;
        if (!multiple) {
            this.clearSelected();
        }
        this._selectionModel.select(item, multiple, this._ngSelect.selectableGroupAsModel);
        if (this._ngSelect.hideSelected) {
            this._hideSelected(item);
        }
    }
    /**
     * @param {?} item
     * @return {?}
     */
    unselect(item) {
        if (!item.selected) {
            return;
        }
        this._selectionModel.unselect(item, this._ngSelect.multiple);
        if (this._ngSelect.hideSelected && isDefined(item.index) && this._ngSelect.multiple) {
            this._showSelected(item);
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    findItem(value) {
        /** @type {?} */
        let findBy;
        if (this._ngSelect.compareWith) {
            findBy = (/**
             * @param {?} item
             * @return {?}
             */
            item => this._ngSelect.compareWith(item.value, value));
        }
        else if (this._ngSelect.bindValue) {
            findBy = (/**
             * @param {?} item
             * @return {?}
             */
            item => !item.children && this.resolveNested(item.value, this._ngSelect.bindValue) === value);
        }
        else {
            findBy = (/**
             * @param {?} item
             * @return {?}
             */
            item => item.value === value ||
                !item.children && item.label && item.label === this.resolveNested(value, this._ngSelect.bindLabel));
        }
        return this._items.find((/**
         * @param {?} item
         * @return {?}
         */
        item => findBy(item)));
    }
    /**
     * @param {?} item
     * @return {?}
     */
    addItem(item) {
        /** @type {?} */
        const option = this.mapItem(item, this._items.length);
        this._items.push(option);
        this._filteredItems.push(option);
        return option;
    }
    /**
     * @param {?=} keepDisabled
     * @return {?}
     */
    clearSelected(keepDisabled = false) {
        this._selectionModel.clear(keepDisabled);
        this._items.forEach((/**
         * @param {?} item
         * @return {?}
         */
        item => {
            item.selected = keepDisabled && item.selected && item.disabled;
            item.marked = false;
        }));
        if (this._ngSelect.hideSelected) {
            this.resetFilteredItems();
        }
    }
    /**
     * @param {?} term
     * @return {?}
     */
    findByLabel(term) {
        term = stripSpecialChars(term).toLocaleLowerCase();
        return this.filteredItems.find((/**
         * @param {?} item
         * @return {?}
         */
        item => {
            /** @type {?} */
            const label = stripSpecialChars(item.label).toLocaleLowerCase();
            return label.substr(0, term.length) === term;
        }));
    }
    /**
     * @param {?} term
     * @return {?}
     */
    filter(term) {
        if (!term) {
            this.resetFilteredItems();
            return;
        }
        this._filteredItems = [];
        term = this._ngSelect.searchFn ? term : stripSpecialChars(term).toLocaleLowerCase();
        /** @type {?} */
        const match = this._ngSelect.searchFn || this._defaultSearchFn;
        /** @type {?} */
        const hideSelected = this._ngSelect.hideSelected;
        for (const key of Array.from(this._groups.keys())) {
            /** @type {?} */
            const matchedItems = [];
            for (const item of this._groups.get(key)) {
                if (hideSelected && (item.parent && item.parent.selected || item.selected)) {
                    continue;
                }
                /** @type {?} */
                const searchItem = this._ngSelect.searchFn ? item.value : item;
                if (match(term, searchItem)) {
                    matchedItems.push(item);
                }
            }
            if (matchedItems.length > 0) {
                const [last] = matchedItems.slice(-1);
                if (last.parent) {
                    /** @type {?} */
                    const head = this._items.find((/**
                     * @param {?} x
                     * @return {?}
                     */
                    x => x === last.parent));
                    this._filteredItems.push(head);
                }
                this._filteredItems.push(...matchedItems);
            }
        }
    }
    /**
     * @return {?}
     */
    resetFilteredItems() {
        if (this._filteredItems.length === this._items.length) {
            return;
        }
        if (this._ngSelect.hideSelected && this.selectedItems.length > 0) {
            this._filteredItems = this._items.filter((/**
             * @param {?} x
             * @return {?}
             */
            x => !x.selected));
        }
        else {
            this._filteredItems = this._items;
        }
    }
    /**
     * @return {?}
     */
    unmarkItem() {
        this._markedIndex = -1;
    }
    /**
     * @return {?}
     */
    markNextItem() {
        this._stepToItem(+1);
    }
    /**
     * @return {?}
     */
    markPreviousItem() {
        this._stepToItem(-1);
    }
    /**
     * @param {?} item
     * @return {?}
     */
    markItem(item) {
        this._markedIndex = this._filteredItems.indexOf(item);
    }
    /**
     * @param {?=} markDefault
     * @return {?}
     */
    markSelectedOrDefault(markDefault) {
        if (this._filteredItems.length === 0) {
            return;
        }
        /** @type {?} */
        const lastMarkedIndex = this._getLastMarkedIndex();
        if (lastMarkedIndex > -1) {
            this._markedIndex = lastMarkedIndex;
        }
        else {
            this._markedIndex = markDefault ? this.filteredItems.findIndex((/**
             * @param {?} x
             * @return {?}
             */
            x => !x.disabled)) : -1;
        }
    }
    /**
     * @param {?} option
     * @param {?} key
     * @return {?}
     */
    resolveNested(option, key) {
        if (!isObject(option)) {
            return option;
        }
        if (key.indexOf('.') === -1) {
            return option[key];
        }
        else {
            /** @type {?} */
            let keys = key.split('.');
            /** @type {?} */
            let value = option;
            for (let i = 0, len = keys.length; i < len; ++i) {
                if (value == null) {
                    return null;
                }
                value = value[keys[i]];
            }
            return value;
        }
    }
    /**
     * @param {?} item
     * @param {?} index
     * @return {?}
     */
    mapItem(item, index) {
        /** @type {?} */
        const label = isDefined(item.$ngOptionLabel) ? item.$ngOptionLabel : this.resolveNested(item, this._ngSelect.bindLabel);
        /** @type {?} */
        const value = isDefined(item.$ngOptionValue) ? item.$ngOptionValue : item;
        return {
            index: index,
            label: isDefined(label) ? label.toString() : '',
            value: value,
            disabled: item.disabled,
            htmlId: `${this._ngSelect.dropdownId}-${index}`,
        };
    }
    /**
     * @return {?}
     */
    mapSelectedItems() {
        /** @type {?} */
        const multiple = this._ngSelect.multiple;
        for (const selected of this.selectedItems) {
            /** @type {?} */
            const value = this._ngSelect.bindValue ? this.resolveNested(selected.value, this._ngSelect.bindValue) : selected.value;
            /** @type {?} */
            const item = isDefined(value) ? this.findItem(value) : null;
            this._selectionModel.unselect(selected, multiple);
            this._selectionModel.select(item || selected, multiple, this._ngSelect.selectableGroupAsModel);
        }
        if (this._ngSelect.hideSelected) {
            this._filteredItems = this.filteredItems.filter((/**
             * @param {?} x
             * @return {?}
             */
            x => this.selectedItems.indexOf(x) === -1));
        }
    }
    /**
     * @private
     * @param {?} item
     * @return {?}
     */
    _showSelected(item) {
        this._filteredItems.push(item);
        if (item.parent) {
            /** @type {?} */
            const parent = item.parent;
            /** @type {?} */
            const parentExists = this._filteredItems.find((/**
             * @param {?} x
             * @return {?}
             */
            x => x === parent));
            if (!parentExists) {
                this._filteredItems.push(parent);
            }
        }
        else if (item.children) {
            for (const child of item.children) {
                child.selected = false;
                this._filteredItems.push(child);
            }
        }
        this._filteredItems = [...this._filteredItems.sort((/**
             * @param {?} a
             * @param {?} b
             * @return {?}
             */
            (a, b) => (a.index - b.index)))];
    }
    /**
     * @private
     * @param {?} item
     * @return {?}
     */
    _hideSelected(item) {
        this._filteredItems = this._filteredItems.filter((/**
         * @param {?} x
         * @return {?}
         */
        x => x !== item));
        if (item.parent) {
            /** @type {?} */
            const children = item.parent.children;
            if (children.every((/**
             * @param {?} x
             * @return {?}
             */
            x => x.selected))) {
                this._filteredItems = this._filteredItems.filter((/**
                 * @param {?} x
                 * @return {?}
                 */
                x => x !== item.parent));
            }
        }
        else if (item.children) {
            this._filteredItems = this.filteredItems.filter((/**
             * @param {?} x
             * @return {?}
             */
            x => x.parent !== item));
        }
    }
    /**
     * @private
     * @param {?} search
     * @param {?} opt
     * @return {?}
     */
    _defaultSearchFn(search, opt) {
        /** @type {?} */
        const label = stripSpecialChars(opt.label).toLocaleLowerCase();
        return label.indexOf(search) > -1;
    }
    /**
     * @private
     * @param {?} steps
     * @return {?}
     */
    _getNextItemIndex(steps) {
        if (steps > 0) {
            return (this._markedIndex === this._filteredItems.length - 1) ? 0 : (this._markedIndex + 1);
        }
        return (this._markedIndex <= 0) ? (this._filteredItems.length - 1) : (this._markedIndex - 1);
    }
    /**
     * @private
     * @param {?} steps
     * @return {?}
     */
    _stepToItem(steps) {
        if (this._filteredItems.length === 0 || this._filteredItems.every((/**
         * @param {?} x
         * @return {?}
         */
        x => x.disabled))) {
            return;
        }
        this._markedIndex = this._getNextItemIndex(steps);
        if (this.markedItem.disabled) {
            this._stepToItem(steps);
        }
    }
    /**
     * @private
     * @return {?}
     */
    _getLastMarkedIndex() {
        if (this._ngSelect.hideSelected) {
            return -1;
        }
        if (this._markedIndex > -1 && this.markedItem === undefined) {
            return -1;
        }
        /** @type {?} */
        const selectedIndex = this._filteredItems.indexOf(this.lastSelectedItem);
        if (this.lastSelectedItem && selectedIndex < 0) {
            return -1;
        }
        return Math.max(this.markedIndex, selectedIndex);
    }
    /**
     * @private
     * @param {?} items
     * @param {?} prop
     * @return {?}
     */
    _groupBy(items, prop) {
        /** @type {?} */
        const groups = new Map();
        if (items.length === 0) {
            return groups;
        }
        // Check if items are already grouped by given key.
        if (Array.isArray(items[0].value[(/** @type {?} */ (prop))])) {
            for (const item of items) {
                /** @type {?} */
                const children = (item.value[(/** @type {?} */ (prop))] || []).map((/**
                 * @param {?} x
                 * @param {?} index
                 * @return {?}
                 */
                (x, index) => this.mapItem(x, index)));
                groups.set(item, children);
            }
            return groups;
        }
        /** @type {?} */
        const isFnKey = isFunction(this._ngSelect.groupBy);
        /** @type {?} */
        const keyFn = (/**
         * @param {?} item
         * @return {?}
         */
        (item) => {
            /** @type {?} */
            let key = isFnKey ? ((/** @type {?} */ (prop)))(item.value) : item.value[(/** @type {?} */ (prop))];
            return isDefined(key) ? key : undefined;
        });
        // Group items by key.
        for (const item of items) {
            /** @type {?} */
            let key = keyFn(item);
            /** @type {?} */
            const group = groups.get(key);
            if (group) {
                group.push(item);
            }
            else {
                groups.set(key, [item]);
            }
        }
        return groups;
    }
    /**
     * @private
     * @param {?} groups
     * @return {?}
     */
    _flatten(groups) {
        /** @type {?} */
        const isGroupByFn = isFunction(this._ngSelect.groupBy);
        /** @type {?} */
        const items = [];
        for (const key of Array.from(groups.keys())) {
            /** @type {?} */
            let i = items.length;
            if (key === undefined) {
                /** @type {?} */
                const withoutGroup = groups.get(undefined) || [];
                items.push(...withoutGroup.map((/**
                 * @param {?} x
                 * @return {?}
                 */
                x => (Object.assign(Object.assign({}, x), { index: i++ })))));
                continue;
            }
            /** @type {?} */
            const isObjectKey = isObject(key);
            /** @type {?} */
            const parent = {
                label: isObjectKey ? '' : String(key),
                children: undefined,
                parent: null,
                index: i++,
                disabled: !this._ngSelect.selectableGroup,
                htmlId: newId(),
            };
            /** @type {?} */
            const groupKey = isGroupByFn ? this._ngSelect.bindLabel : (/** @type {?} */ (this._ngSelect.groupBy));
            /** @type {?} */
            const groupValue = this._ngSelect.groupValue || ((/**
             * @return {?}
             */
            () => {
                if (isObjectKey) {
                    return ((/** @type {?} */ (key))).value;
                }
                return { [groupKey]: key };
            }));
            /** @type {?} */
            const children = groups.get(key).map((/**
             * @param {?} x
             * @return {?}
             */
            x => {
                x.parent = parent;
                x.children = undefined;
                x.index = i++;
                return x;
            }));
            parent.children = children;
            parent.value = groupValue(key, children.map((/**
             * @param {?} x
             * @return {?}
             */
            x => x.value)));
            items.push(parent);
            items.push(...children);
        }
        return items;
    }
}
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-select.types.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function NgOption() { }
if (false) {}
/** @enum {number} */
const KeyCode = {
    Tab: 9,
    Enter: 13,
    Esc: 27,
    Space: 32,
    ArrowUp: 38,
    ArrowDown: 40,
    Backspace: 8,
};
KeyCode[KeyCode.Tab] = 'Tab';
KeyCode[KeyCode.Enter] = 'Enter';
KeyCode[KeyCode.Esc] = 'Esc';
KeyCode[KeyCode.Space] = 'Space';
KeyCode[KeyCode.ArrowUp] = 'ArrowUp';
KeyCode[KeyCode.ArrowDown] = 'ArrowDown';
KeyCode[KeyCode.Backspace] = 'Backspace';

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-dropdown-panel.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function ItemsRangeResult() { }
if (false) {}
/**
 * @record
 */
function PanelDimensions() { }
if (false) {}
class NgDropdownPanelService {
    constructor() {
        this._dimensions = {
            itemHeight: 0,
            panelHeight: 0,
            itemsPerViewport: 0
        };
    }
    /**
     * @return {?}
     */
    get dimensions() {
        return this._dimensions;
    }
    /**
     * @param {?} scrollPos
     * @param {?} itemsLength
     * @param {?} buffer
     * @return {?}
     */
    calculateItems(scrollPos, itemsLength, buffer) {
        /** @type {?} */
        const d = this._dimensions;
        /** @type {?} */
        const scrollHeight = d.itemHeight * itemsLength;
        /** @type {?} */
        const scrollTop = Math.max(0, scrollPos);
        /** @type {?} */
        const indexByScrollTop = scrollTop / scrollHeight * itemsLength;
        /** @type {?} */
        let end = Math.min(itemsLength, Math.ceil(indexByScrollTop) + (d.itemsPerViewport + 1));
        /** @type {?} */
        const maxStartEnd = end;
        /** @type {?} */
        const maxStart = Math.max(0, maxStartEnd - d.itemsPerViewport);
        /** @type {?} */
        let start = Math.min(maxStart, Math.floor(indexByScrollTop));
        /** @type {?} */
        let topPadding = d.itemHeight * Math.ceil(start) - (d.itemHeight * Math.min(start, buffer));
        topPadding = !isNaN(topPadding) ? topPadding : 0;
        start = !isNaN(start) ? start : -1;
        end = !isNaN(end) ? end : -1;
        start -= buffer;
        start = Math.max(0, start);
        end += buffer;
        end = Math.min(itemsLength, end);
        return {
            topPadding,
            scrollHeight,
            start,
            end
        };
    }
    /**
     * @param {?} itemHeight
     * @param {?} panelHeight
     * @return {?}
     */
    setDimensions(itemHeight, panelHeight) {
        /** @type {?} */
        const itemsPerViewport = Math.max(1, Math.floor(panelHeight / itemHeight));
        this._dimensions = {
            itemHeight,
            panelHeight,
            itemsPerViewport
        };
    }
    /**
     * @param {?} itemTop
     * @param {?} itemHeight
     * @param {?} lastScroll
     * @return {?}
     */
    getScrollTo(itemTop, itemHeight, lastScroll) {
        const { panelHeight } = this.dimensions;
        /** @type {?} */
        const itemBottom = itemTop + itemHeight;
        /** @type {?} */
        const top = lastScroll;
        /** @type {?} */
        const bottom = top + panelHeight;
        if (panelHeight >= itemBottom && lastScroll === itemTop) {
            return null;
        }
        if (itemBottom > bottom) {
            return top + itemBottom - bottom;
        }
        else if (itemTop <= top) {
            return itemTop;
        }
        return null;
    }
}
NgDropdownPanelService.ɵfac = function NgDropdownPanelService_Factory(t) { return new (t || NgDropdownPanelService)(); };
NgDropdownPanelService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NgDropdownPanelService, factory: NgDropdownPanelService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgDropdownPanelService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return []; }, null); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-dropdown-panel.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const TOP_CSS_CLASS = 'ng-select-top';
/** @type {?} */
const BOTTOM_CSS_CLASS = 'ng-select-bottom';
/** @type {?} */
const SCROLL_SCHEDULER = typeof requestAnimationFrame !== 'undefined' ? rxjs__WEBPACK_IMPORTED_MODULE_3__["animationFrameScheduler"] : rxjs__WEBPACK_IMPORTED_MODULE_3__["asapScheduler"];
class NgDropdownPanelComponent {
    /**
     * @param {?} _renderer
     * @param {?} _zone
     * @param {?} _panelService
     * @param {?} _elementRef
     * @param {?} _document
     */
    constructor(_renderer, _zone, _panelService, _elementRef, _document) {
        this._renderer = _renderer;
        this._zone = _zone;
        this._panelService = _panelService;
        this._document = _document;
        this.items = [];
        this.position = 'auto';
        this.virtualScroll = false;
        this.filterValue = null;
        this.update = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.scroll = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.scrollToEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.outsideClick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this._destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this._scrollToEndFired = false;
        this._updateScrollHeight = false;
        this._lastScrollPosition = 0;
        this._dropdown = _elementRef.nativeElement;
    }
    /**
     * @return {?}
     */
    get currentPosition() {
        return this._currentPosition;
    }
    /**
     * @private
     * @return {?}
     */
    get itemsLength() {
        return this._itemsLength;
    }
    /**
     * @private
     * @param {?} value
     * @return {?}
     */
    set itemsLength(value) {
        if (value !== this._itemsLength) {
            this._itemsLength = value;
            this._onItemsLengthChanged();
        }
    }
    /**
     * @private
     * @return {?}
     */
    get _startOffset() {
        if (this.markedItem) {
            const { itemHeight, panelHeight } = this._panelService.dimensions;
            /** @type {?} */
            const offset = this.markedItem.index * itemHeight;
            return panelHeight > offset ? 0 : offset;
        }
        return 0;
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    handleMousedown($event) {
        /** @type {?} */
        const target = (/** @type {?} */ ($event.target));
        if (target.tagName === 'INPUT') {
            return;
        }
        $event.preventDefault();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this._select = this._dropdown.parentElement;
        this._virtualPadding = this.paddingElementRef.nativeElement;
        this._scrollablePanel = this.scrollElementRef.nativeElement;
        this._contentPanel = this.contentElementRef.nativeElement;
        this._handleScroll();
        this._handleOutsideClick();
        this._appendDropdown();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.items) {
            /** @type {?} */
            const change = changes.items;
            this._onItemsChange(change.currentValue, change.firstChange);
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
        this._destroy$.unsubscribe();
        if (this.appendTo) {
            this._renderer.removeChild(this._dropdown.parentNode, this._dropdown);
        }
    }
    /**
     * @param {?} option
     * @param {?=} startFromOption
     * @return {?}
     */
    scrollTo(option, startFromOption = false) {
        if (!option) {
            return;
        }
        /** @type {?} */
        const index = this.items.indexOf(option);
        if (index < 0 || index >= this.itemsLength) {
            return;
        }
        /** @type {?} */
        let scrollTo;
        if (this.virtualScroll) {
            /** @type {?} */
            const itemHeight = this._panelService.dimensions.itemHeight;
            scrollTo = this._panelService.getScrollTo(index * itemHeight, itemHeight, this._lastScrollPosition);
        }
        else {
            /** @type {?} */
            const item = this._dropdown.querySelector(`#${option.htmlId}`);
            /** @type {?} */
            const lastScroll = startFromOption ? item.offsetTop : this._lastScrollPosition;
            scrollTo = this._panelService.getScrollTo(item.offsetTop, item.clientHeight, lastScroll);
        }
        if (isDefined(scrollTo)) {
            this._scrollablePanel.scrollTop = scrollTo;
        }
    }
    /**
     * @return {?}
     */
    scrollToTag() {
        /** @type {?} */
        const panel = this._scrollablePanel;
        panel.scrollTop = panel.scrollHeight - panel.clientHeight;
    }
    /**
     * @return {?}
     */
    adjustPosition() {
        /** @type {?} */
        const parent = this._parent.getBoundingClientRect();
        /** @type {?} */
        const select = this._select.getBoundingClientRect();
        this._setOffset(parent, select);
    }
    /**
     * @private
     * @return {?}
     */
    _handleDropdownPosition() {
        this._currentPosition = this._calculateCurrentPosition(this._dropdown);
        if (this._currentPosition === 'top') {
            this._renderer.addClass(this._dropdown, TOP_CSS_CLASS);
            this._renderer.removeClass(this._dropdown, BOTTOM_CSS_CLASS);
            this._renderer.addClass(this._select, TOP_CSS_CLASS);
            this._renderer.removeClass(this._select, BOTTOM_CSS_CLASS);
        }
        else {
            this._renderer.addClass(this._dropdown, BOTTOM_CSS_CLASS);
            this._renderer.removeClass(this._dropdown, TOP_CSS_CLASS);
            this._renderer.addClass(this._select, BOTTOM_CSS_CLASS);
            this._renderer.removeClass(this._select, TOP_CSS_CLASS);
        }
        if (this.appendTo) {
            this._updatePosition();
        }
        this._dropdown.style.opacity = '1';
    }
    /**
     * @private
     * @return {?}
     */
    _handleScroll() {
        this._zone.runOutsideAngular((/**
         * @return {?}
         */
        () => {
            Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["fromEvent"])(this.scrollElementRef.nativeElement, 'scroll')
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this._destroy$), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["auditTime"])(0, SCROLL_SCHEDULER))
                .subscribe((/**
             * @param {?} e
             * @return {?}
             */
            (e) => this._onContentScrolled(e.target.scrollTop)));
        }));
    }
    /**
     * @private
     * @return {?}
     */
    _handleOutsideClick() {
        if (!this._document) {
            return;
        }
        this._zone.runOutsideAngular((/**
         * @return {?}
         */
        () => {
            Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["fromEvent"])(this._document, 'touchstart', { capture: true }), Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["fromEvent"])(this._document, 'mousedown', { capture: true })).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this._destroy$))
                .subscribe((/**
             * @param {?} $event
             * @return {?}
             */
            $event => this._checkToClose($event)));
        }));
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _checkToClose($event) {
        if (this._select.contains($event.target) || this._dropdown.contains($event.target)) {
            return;
        }
        /** @type {?} */
        const path = $event.path || ($event.composedPath && $event.composedPath());
        if ($event.target && $event.target.shadowRoot && path && path[0] && this._select.contains(path[0])) {
            return;
        }
        this._zone.run((/**
         * @return {?}
         */
        () => this.outsideClick.emit()));
    }
    /**
     * @private
     * @param {?} items
     * @param {?} firstChange
     * @return {?}
     */
    _onItemsChange(items, firstChange) {
        this.items = items || [];
        this._scrollToEndFired = false;
        this.itemsLength = items.length;
        if (this.virtualScroll) {
            this._updateItemsRange(firstChange);
        }
        else {
            this._setVirtualHeight();
            this._updateItems(firstChange);
        }
    }
    /**
     * @private
     * @param {?} firstChange
     * @return {?}
     */
    _updateItems(firstChange) {
        this.update.emit(this.items);
        if (firstChange === false) {
            return;
        }
        this._zone.runOutsideAngular((/**
         * @return {?}
         */
        () => {
            Promise.resolve().then((/**
             * @return {?}
             */
            () => {
                /** @type {?} */
                const panelHeight = this._scrollablePanel.clientHeight;
                this._panelService.setDimensions(0, panelHeight);
                this._handleDropdownPosition();
                this.scrollTo(this.markedItem, firstChange);
            }));
        }));
    }
    /**
     * @private
     * @param {?} firstChange
     * @return {?}
     */
    _updateItemsRange(firstChange) {
        this._zone.runOutsideAngular((/**
         * @return {?}
         */
        () => {
            this._measureDimensions().then((/**
             * @return {?}
             */
            () => {
                if (firstChange) {
                    this._renderItemsRange(this._startOffset);
                    this._handleDropdownPosition();
                }
                else {
                    this._renderItemsRange();
                }
            }));
        }));
    }
    /**
     * @private
     * @param {?} scrollTop
     * @return {?}
     */
    _onContentScrolled(scrollTop) {
        if (this.virtualScroll) {
            this._renderItemsRange(scrollTop);
        }
        this._lastScrollPosition = scrollTop;
        this._fireScrollToEnd(scrollTop);
    }
    /**
     * @private
     * @param {?} height
     * @return {?}
     */
    _updateVirtualHeight(height) {
        if (this._updateScrollHeight) {
            this._virtualPadding.style.height = `${height}px`;
            this._updateScrollHeight = false;
        }
    }
    /**
     * @private
     * @return {?}
     */
    _setVirtualHeight() {
        if (!this._virtualPadding) {
            return;
        }
        this._virtualPadding.style.height = `0px`;
    }
    /**
     * @private
     * @return {?}
     */
    _onItemsLengthChanged() {
        this._updateScrollHeight = true;
    }
    /**
     * @private
     * @param {?=} scrollTop
     * @return {?}
     */
    _renderItemsRange(scrollTop = null) {
        if (scrollTop && this._lastScrollPosition === scrollTop) {
            return;
        }
        scrollTop = scrollTop || this._scrollablePanel.scrollTop;
        /** @type {?} */
        const range = this._panelService.calculateItems(scrollTop, this.itemsLength, this.bufferAmount);
        this._updateVirtualHeight(range.scrollHeight);
        this._contentPanel.style.transform = `translateY(${range.topPadding}px)`;
        this._zone.run((/**
         * @return {?}
         */
        () => {
            this.update.emit(this.items.slice(range.start, range.end));
            this.scroll.emit({ start: range.start, end: range.end });
        }));
        if (isDefined(scrollTop) && this._lastScrollPosition === 0) {
            this._scrollablePanel.scrollTop = scrollTop;
            this._lastScrollPosition = scrollTop;
        }
    }
    /**
     * @private
     * @return {?}
     */
    _measureDimensions() {
        if (this._panelService.dimensions.itemHeight > 0 || this.itemsLength === 0) {
            return Promise.resolve(this._panelService.dimensions);
        }
        const [first] = this.items;
        this.update.emit([first]);
        return Promise.resolve().then((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const option = this._dropdown.querySelector(`#${first.htmlId}`);
            /** @type {?} */
            const optionHeight = option.clientHeight;
            this._virtualPadding.style.height = `${optionHeight * this.itemsLength}px`;
            /** @type {?} */
            const panelHeight = this._scrollablePanel.clientHeight;
            this._panelService.setDimensions(optionHeight, panelHeight);
            return this._panelService.dimensions;
        }));
    }
    /**
     * @private
     * @param {?} scrollTop
     * @return {?}
     */
    _fireScrollToEnd(scrollTop) {
        if (this._scrollToEndFired || scrollTop === 0) {
            return;
        }
        /** @type {?} */
        const padding = this.virtualScroll ?
            this._virtualPadding :
            this._contentPanel;
        if (scrollTop + this._dropdown.clientHeight >= padding.clientHeight) {
            this._zone.run((/**
             * @return {?}
             */
            () => this.scrollToEnd.emit()));
            this._scrollToEndFired = true;
        }
    }
    /**
     * @private
     * @param {?} dropdownEl
     * @return {?}
     */
    _calculateCurrentPosition(dropdownEl) {
        if (this.position !== 'auto') {
            return this.position;
        }
        /** @type {?} */
        const selectRect = this._select.getBoundingClientRect();
        /** @type {?} */
        const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        /** @type {?} */
        const offsetTop = selectRect.top + window.pageYOffset;
        /** @type {?} */
        const height = selectRect.height;
        /** @type {?} */
        const dropdownHeight = dropdownEl.getBoundingClientRect().height;
        if (offsetTop + height + dropdownHeight > scrollTop + document.documentElement.clientHeight) {
            return 'top';
        }
        else {
            return 'bottom';
        }
    }
    /**
     * @private
     * @return {?}
     */
    _appendDropdown() {
        if (!this.appendTo) {
            return;
        }
        this._parent = document.querySelector(this.appendTo);
        if (!this._parent) {
            throw new Error(`appendTo selector ${this.appendTo} did not found any parent element`);
        }
        this._parent.appendChild(this._dropdown);
    }
    /**
     * @private
     * @return {?}
     */
    _updatePosition() {
        /** @type {?} */
        const select = this._select.getBoundingClientRect();
        /** @type {?} */
        const parent = this._parent.getBoundingClientRect();
        /** @type {?} */
        const offsetLeft = select.left - parent.left;
        this._setOffset(parent, select);
        this._dropdown.style.left = offsetLeft + 'px';
        this._dropdown.style.width = select.width + 'px';
        this._dropdown.style.minWidth = select.width + 'px';
    }
    /**
     * @private
     * @param {?} parent
     * @param {?} select
     * @return {?}
     */
    _setOffset(parent, select) {
        /** @type {?} */
        const delta = select.height;
        if (this._currentPosition === 'top') {
            /** @type {?} */
            const offsetBottom = parent.bottom - select.bottom;
            this._dropdown.style.bottom = offsetBottom + delta + 'px';
            this._dropdown.style.top = 'auto';
        }
        else if (this._currentPosition === 'bottom') {
            /** @type {?} */
            const offsetTop = select.top - parent.top;
            this._dropdown.style.top = offsetTop + delta + 'px';
            this._dropdown.style.bottom = 'auto';
        }
    }
}
NgDropdownPanelComponent.ɵfac = function NgDropdownPanelComponent_Factory(t) { return new (t || NgDropdownPanelComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](NgDropdownPanelService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__["DOCUMENT"], 8)); };
NgDropdownPanelComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NgDropdownPanelComponent, selectors: [["ng-dropdown-panel"]], viewQuery: function NgDropdownPanelComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c0, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c1, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c2, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.contentElementRef = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.scrollElementRef = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paddingElementRef = _t.first);
    } }, hostBindings: function NgDropdownPanelComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mousedown", function NgDropdownPanelComponent_mousedown_HostBindingHandler($event) { return ctx.handleMousedown($event); });
    } }, inputs: { items: "items", position: "position", virtualScroll: "virtualScroll", filterValue: "filterValue", markedItem: "markedItem", appendTo: "appendTo", bufferAmount: "bufferAmount", headerTemplate: "headerTemplate", footerTemplate: "footerTemplate" }, outputs: { update: "update", scroll: "scroll", scrollToEnd: "scrollToEnd", outsideClick: "outsideClick" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], ngContentSelectors: _c4, decls: 9, vars: 6, consts: [["class", "ng-dropdown-header", 4, "ngIf"], [1, "ng-dropdown-panel-items", "scroll-host"], ["scroll", ""], ["padding", ""], ["content", ""], ["class", "ng-dropdown-footer", 4, "ngIf"], [1, "ng-dropdown-header"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "ng-dropdown-footer"]], template: function NgDropdownPanelComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, NgDropdownPanelComponent_div_0_Template, 2, 4, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "div", null, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", null, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, NgDropdownPanelComponent_div_8_Template, 2, 4, "div", 5);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.headerTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("total-padding", ctx.virtualScroll);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("scrollable-content", ctx.virtualScroll && ctx.items.length);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.footerTemplate);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgTemplateOutlet"]], encapsulation: 2, changeDetection: 0 });
/** @nocollapse */
NgDropdownPanelComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] },
    { type: NgDropdownPanelService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DOCUMENT"],] }] }
];
NgDropdownPanelComponent.propDecorators = {
    items: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    markedItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    position: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    appendTo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    bufferAmount: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    virtualScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    headerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    footerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    filterValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    update: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    scroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    scrollToEnd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    outsideClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    contentElementRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['content', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true },] }],
    scrollElementRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['scroll', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true },] }],
    paddingElementRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['padding', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true },] }],
    handleMousedown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['mousedown', ['$event'],] }]
};
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgDropdownPanelComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
                selector: 'ng-dropdown-panel',
                template: `
        <div *ngIf="headerTemplate" class="ng-dropdown-header">
            <ng-container [ngTemplateOutlet]="headerTemplate" [ngTemplateOutletContext]="{ searchTerm: filterValue }"></ng-container>
        </div>
        <div #scroll class="ng-dropdown-panel-items scroll-host">
            <div #padding [class.total-padding]="virtualScroll"></div>
            <div #content [class.scrollable-content]="virtualScroll && items.length">
                <ng-content></ng-content>
            </div>
        </div>
        <div *ngIf="footerTemplate" class="ng-dropdown-footer">
            <ng-container [ngTemplateOutlet]="footerTemplate" [ngTemplateOutletContext]="{ searchTerm: filterValue }"></ng-container>
        </div>
    `
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] }, { type: NgDropdownPanelService }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DOCUMENT"]]
            }] }]; }, { items: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], position: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], virtualScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], filterValue: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], update: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], scroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], scrollToEnd: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], outsideClick: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], 
    /**
     * @param {?} $event
     * @return {?}
     */
    handleMousedown: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['mousedown', ['$event']]
        }], markedItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], appendTo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], bufferAmount: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], headerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], footerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], contentElementRef: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['content', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true }]
        }], scrollElementRef: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['scroll', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true }]
        }], paddingElementRef: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['padding', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], static: true }]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-option.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgOptionComponent {
    /**
     * @param {?} elementRef
     */
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.stateChange$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this._disabled = false;
    }
    /**
     * @return {?}
     */
    get disabled() { return this._disabled; }
    /**
     * @param {?} value
     * @return {?}
     */
    set disabled(value) { this._disabled = this._isDisabled(value); }
    /**
     * @return {?}
     */
    get label() {
        return (this.elementRef.nativeElement.textContent || '').trim();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.disabled) {
            this.stateChange$.next({
                value: this.value,
                disabled: this._disabled
            });
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewChecked() {
        if (this.label !== this._previousLabel) {
            this._previousLabel = this.label;
            this.stateChange$.next({
                value: this.value,
                disabled: this._disabled,
                label: this.elementRef.nativeElement.innerHTML
            });
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.stateChange$.complete();
    }
    /**
     * @private
     * @param {?} value
     * @return {?}
     */
    _isDisabled(value) {
        return value != null && `${value}` !== 'false';
    }
}
NgOptionComponent.ɵfac = function NgOptionComponent_Factory(t) { return new (t || NgOptionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])); };
NgOptionComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NgOptionComponent, selectors: [["ng-option"]], inputs: { disabled: "disabled", value: "value" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], ngContentSelectors: _c4, decls: 1, vars: 0, template: function NgOptionComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
    } }, encapsulation: 2, changeDetection: 0 });
/** @nocollapse */
NgOptionComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }
];
NgOptionComponent.propDecorators = {
    value: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    disabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgOptionComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ng-option',
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
                template: `<ng-content></ng-content>`
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }]; }, { disabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], value: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/config.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgSelectConfig {
    constructor() {
        this.notFoundText = 'No items found';
        this.typeToSearchText = 'Type to search';
        this.addTagText = 'Add item';
        this.loadingText = 'Loading...';
        this.clearAllText = 'Clear all';
        this.disableVirtualScroll = true;
        this.openOnEnter = true;
        this.appearance = 'underline';
    }
}
NgSelectConfig.ɵfac = function NgSelectConfig_Factory(t) { return new (t || NgSelectConfig)(); };
/** @nocollapse */ NgSelectConfig.ɵprov = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({ factory: function NgSelectConfig_Factory() { return new NgSelectConfig(); }, token: NgSelectConfig, providedIn: "root" });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgSelectConfig, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{ providedIn: 'root' }]
    }], function () { return []; }, null); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-select.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const SELECTION_MODEL_FACTORY = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('ng-select-selection-model');
class NgSelectComponent {
    /**
     * @param {?} classes
     * @param {?} autoFocus
     * @param {?} config
     * @param {?} newSelectionModel
     * @param {?} _elementRef
     * @param {?} _cd
     * @param {?} _console
     */
    constructor(classes, autoFocus, config, newSelectionModel, _elementRef, _cd, _console) {
        this.classes = classes;
        this.autoFocus = autoFocus;
        this._cd = _cd;
        this._console = _console;
        this.markFirst = true;
        this.dropdownPosition = 'auto';
        this.loading = false;
        this.closeOnSelect = true;
        this.hideSelected = false;
        this.selectOnTab = false;
        this.bufferAmount = 4;
        this.selectableGroup = false;
        this.selectableGroupAsModel = true;
        this.searchFn = null;
        this.trackByFn = null;
        this.clearOnBackspace = true;
        this.labelForId = null;
        this.inputAttrs = {};
        this.readonly = false;
        this.searchWhileComposing = true;
        this.minTermLength = 0;
        this.editableSearchTerm = false;
        this.keyDownFn = (/**
         * @param {?} _
         * @return {?}
         */
        (_) => true);
        this.multiple = false;
        this.addTag = false;
        this.searchable = true;
        this.clearable = true;
        this.isOpen = false;
        // output events
        this.blurEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.focusEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.changeEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.openEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.closeEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.searchEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.clearEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.addEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.removeEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.scroll = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.scrollToEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.viewPortItems = [];
        this.searchTerm = null;
        this.dropdownId = newId();
        this.escapeHTML = true;
        this.useDefaultClass = true;
        this._items = [];
        this._defaultLabel = 'label';
        this._pressedKeys = [];
        this._isComposing = false;
        this._destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this._keyPress$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this._onChange = (/**
         * @param {?} _
         * @return {?}
         */
        (_) => { });
        this._onTouched = (/**
         * @return {?}
         */
        () => { });
        this.clearItem = (/**
         * @param {?} item
         * @return {?}
         */
        (item) => {
            /** @type {?} */
            const option = this.selectedItems.find((/**
             * @param {?} x
             * @return {?}
             */
            x => x.value === item));
            this.unselect(option);
        });
        this.trackByOption = (/**
         * @param {?} _
         * @param {?} item
         * @return {?}
         */
        (_, item) => {
            if (this.trackByFn) {
                return this.trackByFn(item.value);
            }
            return item;
        });
        this._mergeGlobalConfig(config);
        this.itemsList = new ItemsList(this, newSelectionModel());
        this.element = _elementRef.nativeElement;
    }
    /**
     * @return {?}
     */
    get items() { return this._items; }
    ;
    /**
     * @param {?} value
     * @return {?}
     */
    set items(value) {
        this._itemsAreUsed = true;
        this._items = value;
    }
    ;
    /**
     * @return {?}
     */
    get compareWith() { return this._compareWith; }
    /**
     * @param {?} fn
     * @return {?}
     */
    set compareWith(fn) {
        if (!isFunction(fn)) {
            throw Error('`compareWith` must be a function.');
        }
        this._compareWith = fn;
    }
    /**
     * @return {?}
     */
    get clearSearchOnAdd() { return isDefined(this._clearSearchOnAdd) ? this._clearSearchOnAdd : this.closeOnSelect; }
    ;
    /**
     * @param {?} value
     * @return {?}
     */
    set clearSearchOnAdd(value) {
        this._clearSearchOnAdd = value;
    }
    ;
    /**
     * @return {?}
     */
    get disabled() { return this.readonly || this._disabled; }
    ;
    /**
     * @return {?}
     */
    get filtered() { return (!!this.searchTerm && this.searchable || this._isComposing); }
    ;
    /**
     * @private
     * @return {?}
     */
    get _editableSearchTerm() {
        return this.editableSearchTerm && !this.multiple;
    }
    /**
     * @return {?}
     */
    get selectedItems() {
        return this.itemsList.selectedItems;
    }
    /**
     * @return {?}
     */
    get selectedValues() {
        return this.selectedItems.map((/**
         * @param {?} x
         * @return {?}
         */
        x => x.value));
    }
    /**
     * @return {?}
     */
    get hasValue() {
        return this.selectedItems.length > 0;
    }
    /**
     * @return {?}
     */
    get currentPanelPosition() {
        if (this.dropdownPanel) {
            return this.dropdownPanel.currentPosition;
        }
        return undefined;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this._handleKeyPresses();
        this._setInputAttributes();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.multiple) {
            this.itemsList.clearSelected();
        }
        if (changes.items) {
            this._setItems(changes.items.currentValue || []);
        }
        if (changes.isOpen) {
            this._manualOpen = isDefined(changes.isOpen.currentValue);
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        if (!this._itemsAreUsed) {
            this.escapeHTML = false;
            this._setItemsFromNgOptions();
        }
        if (isDefined(this.autoFocus)) {
            this.focus();
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    handleKeyDown($event) {
        /** @type {?} */
        const keyCode = KeyCode[$event.which];
        if (keyCode) {
            if (this.keyDownFn($event) === false) {
                return;
            }
            this.handleKeyCode($event);
        }
        else if ($event.key && $event.key.length === 1) {
            this._keyPress$.next($event.key.toLocaleLowerCase());
        }
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    handleKeyCode($event) {
        switch ($event.which) {
            case KeyCode.ArrowDown:
                this._handleArrowDown($event);
                break;
            case KeyCode.ArrowUp:
                this._handleArrowUp($event);
                break;
            case KeyCode.Space:
                this._handleSpace($event);
                break;
            case KeyCode.Enter:
                this._handleEnter($event);
                break;
            case KeyCode.Tab:
                this._handleTab($event);
                break;
            case KeyCode.Esc:
                this.close();
                $event.preventDefault();
                break;
            case KeyCode.Backspace:
                this._handleBackspace();
                break;
        }
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    handleMousedown($event) {
        /** @type {?} */
        const target = (/** @type {?} */ ($event.target));
        if (target.tagName !== 'INPUT') {
            $event.preventDefault();
        }
        if (target.classList.contains('ng-clear-wrapper')) {
            this.handleClearClick();
            return;
        }
        if (target.classList.contains('ng-arrow-wrapper')) {
            this.handleArrowClick();
            return;
        }
        if (target.classList.contains('ng-value-icon')) {
            return;
        }
        if (!this.focused) {
            this.focus();
        }
        if (this.searchable) {
            this.open();
        }
        else {
            this.toggle();
        }
    }
    /**
     * @return {?}
     */
    handleArrowClick() {
        if (this.isOpen) {
            this.close();
        }
        else {
            this.open();
        }
    }
    /**
     * @return {?}
     */
    handleClearClick() {
        if (this.hasValue) {
            this.itemsList.clearSelected(true);
            this._updateNgModel();
        }
        this._clearSearch();
        this.focus();
        this.clearEvent.emit();
        this._onSelectionChanged();
    }
    /**
     * @return {?}
     */
    clearModel() {
        if (!this.clearable) {
            return;
        }
        this.itemsList.clearSelected();
        this._updateNgModel();
    }
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        this.itemsList.clearSelected();
        this._handleWriteValue(value);
        this._cd.markForCheck();
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this._onChange = fn;
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    /**
     * @param {?} state
     * @return {?}
     */
    setDisabledState(state) {
        this._disabled = state;
        this._cd.markForCheck();
    }
    /**
     * @return {?}
     */
    toggle() {
        if (!this.isOpen) {
            this.open();
        }
        else {
            this.close();
        }
    }
    /**
     * @return {?}
     */
    open() {
        if (this.disabled || this.isOpen || this.itemsList.maxItemsSelected || this._manualOpen) {
            return;
        }
        if (!this._isTypeahead && !this.addTag && this.itemsList.noItemsToSelect) {
            return;
        }
        this.isOpen = true;
        this.itemsList.markSelectedOrDefault(this.markFirst);
        this.openEvent.emit();
        if (!this.searchTerm) {
            this.focus();
        }
        this.detectChanges();
    }
    /**
     * @return {?}
     */
    close() {
        if (!this.isOpen || this._manualOpen) {
            return;
        }
        this.isOpen = false;
        if (!this._editableSearchTerm) {
            this._clearSearch();
        }
        else {
            this.itemsList.resetFilteredItems();
        }
        this.itemsList.unmarkItem();
        this._onTouched();
        this.closeEvent.emit();
        this._cd.markForCheck();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    toggleItem(item) {
        if (!item || item.disabled || this.disabled) {
            return;
        }
        if (this.multiple && item.selected) {
            this.unselect(item);
        }
        else {
            this.select(item);
        }
        if (this._editableSearchTerm) {
            this._setSearchTermFromItems();
        }
        this._onSelectionChanged();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    select(item) {
        if (!item.selected) {
            this.itemsList.select(item);
            if (this.clearSearchOnAdd && !this._editableSearchTerm) {
                this._clearSearch();
            }
            this._updateNgModel();
            if (this.multiple) {
                this.addEvent.emit(item.value);
            }
        }
        if (this.closeOnSelect || this.itemsList.noItemsToSelect) {
            this.close();
        }
    }
    /**
     * @return {?}
     */
    focus() {
        this.searchInput.nativeElement.focus();
    }
    /**
     * @return {?}
     */
    blur() {
        this.searchInput.nativeElement.blur();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    unselect(item) {
        if (!item) {
            return;
        }
        this.itemsList.unselect(item);
        this.focus();
        this._updateNgModel();
        this.removeEvent.emit(item);
    }
    /**
     * @return {?}
     */
    selectTag() {
        /** @type {?} */
        let tag;
        if (isFunction(this.addTag)) {
            tag = ((/** @type {?} */ (this.addTag)))(this.searchTerm);
        }
        else {
            tag = this._primitive ? this.searchTerm : { [this.bindLabel]: this.searchTerm };
        }
        /** @type {?} */
        const handleTag = (/**
         * @param {?} item
         * @return {?}
         */
        (item) => this._isTypeahead || !this.isOpen ? this.itemsList.mapItem(item, null) : this.itemsList.addItem(item));
        if (isPromise(tag)) {
            tag.then((/**
             * @param {?} item
             * @return {?}
             */
            item => this.select(handleTag(item)))).catch((/**
             * @return {?}
             */
            () => { }));
        }
        else if (tag) {
            this.select(handleTag(tag));
        }
    }
    /**
     * @return {?}
     */
    showClear() {
        return this.clearable && (this.hasValue || this.searchTerm) && !this.disabled;
    }
    /**
     * @return {?}
     */
    get showAddTag() {
        if (!this._validTerm) {
            return false;
        }
        /** @type {?} */
        const term = this.searchTerm.toLowerCase().trim();
        return this.addTag &&
            (!this.itemsList.filteredItems.some((/**
             * @param {?} x
             * @return {?}
             */
            x => x.label.toLowerCase() === term)) &&
                (!this.hideSelected && this.isOpen || !this.selectedItems.some((/**
                 * @param {?} x
                 * @return {?}
                 */
                x => x.label.toLowerCase() === term)))) &&
            !this.loading;
    }
    /**
     * @return {?}
     */
    showNoItemsFound() {
        /** @type {?} */
        const empty = this.itemsList.filteredItems.length === 0;
        return ((empty && !this._isTypeahead && !this.loading) ||
            (empty && this._isTypeahead && this._validTerm && !this.loading)) &&
            !this.showAddTag;
    }
    /**
     * @return {?}
     */
    showTypeToSearch() {
        /** @type {?} */
        const empty = this.itemsList.filteredItems.length === 0;
        return empty && this._isTypeahead && !this._validTerm && !this.loading;
    }
    /**
     * @return {?}
     */
    onCompositionStart() {
        this._isComposing = true;
    }
    /**
     * @param {?} term
     * @return {?}
     */
    onCompositionEnd(term) {
        this._isComposing = false;
        if (this.searchWhileComposing) {
            return;
        }
        this.filter(term);
    }
    /**
     * @param {?} term
     * @return {?}
     */
    filter(term) {
        if (this._isComposing && !this.searchWhileComposing) {
            return;
        }
        this.searchTerm = term;
        if (this._isTypeahead && (this._validTerm || this.minTermLength === 0)) {
            this.typeahead.next(term);
        }
        if (!this._isTypeahead) {
            this.itemsList.filter(this.searchTerm);
            if (this.isOpen) {
                this.itemsList.markSelectedOrDefault(this.markFirst);
            }
        }
        this.searchEvent.emit({ term, items: this.itemsList.filteredItems.map((/**
             * @param {?} x
             * @return {?}
             */
            x => x.value)) });
        this.open();
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    onInputFocus($event) {
        if (this.focused) {
            return;
        }
        if (this._editableSearchTerm) {
            this._setSearchTermFromItems();
        }
        this.element.classList.add('ng-select-focused');
        this.focusEvent.emit($event);
        this.focused = true;
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    onInputBlur($event) {
        this.element.classList.remove('ng-select-focused');
        this.blurEvent.emit($event);
        if (!this.isOpen && !this.disabled) {
            this._onTouched();
        }
        if (this._editableSearchTerm) {
            this._setSearchTermFromItems();
        }
        this.focused = false;
    }
    /**
     * @param {?} item
     * @return {?}
     */
    onItemHover(item) {
        if (item.disabled) {
            return;
        }
        this.itemsList.markItem(item);
    }
    /**
     * @return {?}
     */
    detectChanges() {
        if (!((/** @type {?} */ (this._cd))).destroyed) {
            this._cd.detectChanges();
        }
    }
    /**
     * @private
     * @return {?}
     */
    _setSearchTermFromItems() {
        /** @type {?} */
        const selected = this.selectedItems && this.selectedItems[0];
        this.searchTerm = (selected && selected.label) || null;
    }
    /**
     * @private
     * @param {?} items
     * @return {?}
     */
    _setItems(items) {
        /** @type {?} */
        const firstItem = items[0];
        this.bindLabel = this.bindLabel || this._defaultLabel;
        this._primitive = isDefined(firstItem) ? !isObject(firstItem) : this._primitive || this.bindLabel === this._defaultLabel;
        this.itemsList.setItems(items);
        if (items.length > 0 && this.hasValue) {
            this.itemsList.mapSelectedItems();
        }
        if (this.isOpen && isDefined(this.searchTerm) && !this._isTypeahead) {
            this.itemsList.filter(this.searchTerm);
        }
        if (this._isTypeahead || this.isOpen) {
            this.itemsList.markSelectedOrDefault(this.markFirst);
        }
    }
    /**
     * @private
     * @return {?}
     */
    _setItemsFromNgOptions() {
        /** @type {?} */
        const mapNgOptions = (/**
         * @param {?} options
         * @return {?}
         */
        (options) => {
            this.items = options.map((/**
             * @param {?} option
             * @return {?}
             */
            option => ({
                $ngOptionValue: option.value,
                $ngOptionLabel: option.elementRef.nativeElement.innerHTML,
                disabled: option.disabled
            })));
            this.itemsList.setItems(this.items);
            if (this.hasValue) {
                this.itemsList.mapSelectedItems();
            }
            this.detectChanges();
        });
        /** @type {?} */
        const handleOptionChange = (/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const changedOrDestroyed = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["merge"])(this.ngOptions.changes, this._destroy$);
            Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["merge"])(...this.ngOptions.map((/**
             * @param {?} option
             * @return {?}
             */
            option => option.stateChange$)))
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(changedOrDestroyed))
                .subscribe((/**
             * @param {?} option
             * @return {?}
             */
            option => {
                /** @type {?} */
                const item = this.itemsList.findItem(option.value);
                item.disabled = option.disabled;
                item.label = option.label || item.label;
                this._cd.detectChanges();
            }));
        });
        this.ngOptions.changes
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["startWith"])(this.ngOptions), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this._destroy$))
            .subscribe((/**
         * @param {?} options
         * @return {?}
         */
        options => {
            this.bindLabel = this._defaultLabel;
            mapNgOptions(options);
            handleOptionChange();
        }));
    }
    /**
     * @private
     * @param {?} value
     * @return {?}
     */
    _isValidWriteValue(value) {
        if (!isDefined(value) || (this.multiple && value === '') || Array.isArray(value) && value.length === 0) {
            return false;
        }
        /** @type {?} */
        const validateBinding = (/**
         * @param {?} item
         * @return {?}
         */
        (item) => {
            if (!isDefined(this.compareWith) && isObject(item) && this.bindValue) {
                this._console.warn(`Setting object(${JSON.stringify(item)}) as your model with bindValue is not allowed unless [compareWith] is used.`);
                return false;
            }
            return true;
        });
        if (this.multiple) {
            if (!Array.isArray(value)) {
                this._console.warn('Multiple select ngModel should be array.');
                return false;
            }
            return value.every((/**
             * @param {?} item
             * @return {?}
             */
            item => validateBinding(item)));
        }
        else {
            return validateBinding(value);
        }
    }
    /**
     * @private
     * @param {?} ngModel
     * @return {?}
     */
    _handleWriteValue(ngModel) {
        if (!this._isValidWriteValue(ngModel)) {
            return;
        }
        /** @type {?} */
        const select = (/**
         * @param {?} val
         * @return {?}
         */
        (val) => {
            /** @type {?} */
            let item = this.itemsList.findItem(val);
            if (item) {
                this.itemsList.select(item);
            }
            else {
                /** @type {?} */
                const isValObject = isObject(val);
                /** @type {?} */
                const isPrimitive = !isValObject && !this.bindValue;
                if ((isValObject || isPrimitive)) {
                    this.itemsList.select(this.itemsList.mapItem(val, null));
                }
                else if (this.bindValue) {
                    item = {
                        [this.bindLabel]: null,
                        [this.bindValue]: val
                    };
                    this.itemsList.select(this.itemsList.mapItem(item, null));
                }
            }
        });
        if (this.multiple) {
            ((/** @type {?} */ (ngModel))).forEach((/**
             * @param {?} item
             * @return {?}
             */
            item => select(item)));
        }
        else {
            select(ngModel);
        }
    }
    /**
     * @private
     * @return {?}
     */
    _handleKeyPresses() {
        if (this.searchable) {
            return;
        }
        this._keyPress$
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this._destroy$), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((/**
         * @param {?} letter
         * @return {?}
         */
        letter => this._pressedKeys.push(letter))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["debounceTime"])(200), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])((/**
         * @return {?}
         */
        () => this._pressedKeys.length > 0)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((/**
         * @return {?}
         */
        () => this._pressedKeys.join(''))))
            .subscribe((/**
         * @param {?} term
         * @return {?}
         */
        term => {
            /** @type {?} */
            const item = this.itemsList.findByLabel(term);
            if (item) {
                if (this.isOpen) {
                    this.itemsList.markItem(item);
                    this._cd.markForCheck();
                }
                else {
                    this.select(item);
                }
            }
            this._pressedKeys = [];
        }));
    }
    /**
     * @private
     * @return {?}
     */
    _setInputAttributes() {
        /** @type {?} */
        const input = this.searchInput.nativeElement;
        /** @type {?} */
        const attributes = Object.assign({ type: 'text', autocorrect: 'off', autocapitalize: 'off', autocomplete: this.labelForId ? 'off' : this.dropdownId }, this.inputAttrs);
        for (const key of Object.keys(attributes)) {
            input.setAttribute(key, attributes[key]);
        }
    }
    /**
     * @private
     * @return {?}
     */
    _updateNgModel() {
        /** @type {?} */
        const model = [];
        for (const item of this.selectedItems) {
            if (this.bindValue) {
                /** @type {?} */
                let value = null;
                if (item.children) {
                    /** @type {?} */
                    const groupKey = this.groupValue ? this.bindValue : (/** @type {?} */ (this.groupBy));
                    value = item.value[groupKey || (/** @type {?} */ (this.groupBy))];
                }
                else {
                    value = this.itemsList.resolveNested(item.value, this.bindValue);
                }
                model.push(value);
            }
            else {
                model.push(item.value);
            }
        }
        /** @type {?} */
        const selected = this.selectedItems.map((/**
         * @param {?} x
         * @return {?}
         */
        x => x.value));
        if (this.multiple) {
            this._onChange(model);
            this.changeEvent.emit(selected);
        }
        else {
            this._onChange(isDefined(model[0]) ? model[0] : null);
            this.changeEvent.emit(selected[0]);
        }
        this._cd.markForCheck();
    }
    /**
     * @private
     * @return {?}
     */
    _clearSearch() {
        if (!this.searchTerm) {
            return;
        }
        this._changeSearch(null);
        this.itemsList.resetFilteredItems();
    }
    /**
     * @private
     * @param {?} searchTerm
     * @return {?}
     */
    _changeSearch(searchTerm) {
        this.searchTerm = searchTerm;
        if (this._isTypeahead) {
            this.typeahead.next(searchTerm);
        }
    }
    /**
     * @private
     * @return {?}
     */
    _scrollToMarked() {
        if (!this.isOpen || !this.dropdownPanel) {
            return;
        }
        this.dropdownPanel.scrollTo(this.itemsList.markedItem);
    }
    /**
     * @private
     * @return {?}
     */
    _scrollToTag() {
        if (!this.isOpen || !this.dropdownPanel) {
            return;
        }
        this.dropdownPanel.scrollToTag();
    }
    /**
     * @private
     * @return {?}
     */
    _onSelectionChanged() {
        if (this.isOpen && this.multiple && this.appendTo) {
            // Make sure items are rendered.
            this._cd.detectChanges();
            this.dropdownPanel.adjustPosition();
        }
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _handleTab($event) {
        if (this.isOpen === false && !this.addTag) {
            return;
        }
        if (this.selectOnTab) {
            if (this.itemsList.markedItem) {
                this.toggleItem(this.itemsList.markedItem);
                $event.preventDefault();
            }
            else if (this.showAddTag) {
                this.selectTag();
                $event.preventDefault();
            }
            else {
                this.close();
            }
        }
        else {
            this.close();
        }
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _handleEnter($event) {
        if (this.isOpen || this._manualOpen) {
            if (this.itemsList.markedItem) {
                this.toggleItem(this.itemsList.markedItem);
            }
            else if (this.showAddTag) {
                this.selectTag();
            }
        }
        else if (this.openOnEnter) {
            this.open();
        }
        else {
            return;
        }
        $event.preventDefault();
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _handleSpace($event) {
        if (this.isOpen || this._manualOpen) {
            return;
        }
        this.open();
        $event.preventDefault();
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _handleArrowDown($event) {
        if (this._nextItemIsTag(+1)) {
            this.itemsList.unmarkItem();
            this._scrollToTag();
        }
        else {
            this.itemsList.markNextItem();
            this._scrollToMarked();
        }
        this.open();
        $event.preventDefault();
    }
    /**
     * @private
     * @param {?} $event
     * @return {?}
     */
    _handleArrowUp($event) {
        if (!this.isOpen) {
            return;
        }
        if (this._nextItemIsTag(-1)) {
            this.itemsList.unmarkItem();
            this._scrollToTag();
        }
        else {
            this.itemsList.markPreviousItem();
            this._scrollToMarked();
        }
        $event.preventDefault();
    }
    /**
     * @private
     * @param {?} nextStep
     * @return {?}
     */
    _nextItemIsTag(nextStep) {
        /** @type {?} */
        const nextIndex = this.itemsList.markedIndex + nextStep;
        return this.addTag && this.searchTerm
            && this.itemsList.markedItem
            && (nextIndex < 0 || nextIndex === this.itemsList.filteredItems.length);
    }
    /**
     * @private
     * @return {?}
     */
    _handleBackspace() {
        if (this.searchTerm || !this.clearable || !this.clearOnBackspace || !this.hasValue) {
            return;
        }
        if (this.multiple) {
            this.unselect(this.itemsList.lastSelectedItem);
        }
        else {
            this.clearModel();
        }
    }
    /**
     * @private
     * @return {?}
     */
    get _isTypeahead() {
        return this.typeahead && this.typeahead.observers.length > 0;
    }
    /**
     * @private
     * @return {?}
     */
    get _validTerm() {
        /** @type {?} */
        const term = this.searchTerm && this.searchTerm.trim();
        return term && term.length >= this.minTermLength;
    }
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    _mergeGlobalConfig(config) {
        this.placeholder = this.placeholder || config.placeholder;
        this.notFoundText = this.notFoundText || config.notFoundText;
        this.typeToSearchText = this.typeToSearchText || config.typeToSearchText;
        this.addTagText = this.addTagText || config.addTagText;
        this.loadingText = this.loadingText || config.loadingText;
        this.clearAllText = this.clearAllText || config.clearAllText;
        this.virtualScroll = isDefined(this.virtualScroll)
            ? this.virtualScroll
            : isDefined(config.disableVirtualScroll) ? !config.disableVirtualScroll : false;
        this.openOnEnter = isDefined(this.openOnEnter) ? this.openOnEnter : config.openOnEnter;
        this.appendTo = this.appendTo || config.appendTo;
        this.bindValue = this.bindValue || config.bindValue;
        this.appearance = this.appearance || config.appearance;
    }
}
NgSelectComponent.ɵfac = function NgSelectComponent_Factory(t) { return new (t || NgSelectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinjectAttribute"]('class'), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinjectAttribute"]('autofocus'), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](NgSelectConfig), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](SELECTION_MODEL_FACTORY), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](ConsoleService)); };
NgSelectComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NgSelectComponent, selectors: [["ng-select"]], contentQueries: function NgSelectComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgOptionTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgOptgroupTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgLabelTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgMultiLabelTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgHeaderTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgFooterTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgNotFoundTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgTypeToSearchTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgLoadingTextTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgTagTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgLoadingSpinnerTemplateDirective, true, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, NgOptionComponent, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.optionTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.optgroupTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.labelTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.multiLabelTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.headerTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.footerTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.notFoundTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.typeToSearchTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.loadingTextTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.tagTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.loadingSpinnerTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.ngOptions = _t);
    } }, viewQuery: function NgSelectComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](NgDropdownPanelComponent, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c5, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.dropdownPanel = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.searchInput = _t.first);
    } }, hostAttrs: ["role", "listbox"], hostVars: 20, hostBindings: function NgSelectComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keydown", function NgSelectComponent_keydown_HostBindingHandler($event) { return ctx.handleKeyDown($event); });
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-select", ctx.useDefaultClass)("ng-select-single", !ctx.multiple)("ng-select-multiple", ctx.multiple)("ng-select-taggable", ctx.addTag)("ng-select-searchable", ctx.searchable)("ng-select-clearable", ctx.clearable)("ng-select-opened", ctx.isOpen)("ng-select-disabled", ctx.disabled)("ng-select-filtered", ctx.filtered)("ng-select-typeahead", ctx.typeahead);
    } }, inputs: { markFirst: "markFirst", dropdownPosition: "dropdownPosition", loading: "loading", closeOnSelect: "closeOnSelect", hideSelected: "hideSelected", selectOnTab: "selectOnTab", bufferAmount: "bufferAmount", selectableGroup: "selectableGroup", selectableGroupAsModel: "selectableGroupAsModel", searchFn: "searchFn", trackByFn: "trackByFn", clearOnBackspace: "clearOnBackspace", labelForId: "labelForId", inputAttrs: "inputAttrs", readonly: "readonly", searchWhileComposing: "searchWhileComposing", minTermLength: "minTermLength", editableSearchTerm: "editableSearchTerm", keyDownFn: "keyDownFn", multiple: "multiple", addTag: "addTag", searchable: "searchable", clearable: "clearable", isOpen: "isOpen", items: "items", compareWith: "compareWith", clearSearchOnAdd: "clearSearchOnAdd", bindLabel: "bindLabel", placeholder: "placeholder", notFoundText: "notFoundText", typeToSearchText: "typeToSearchText", addTagText: "addTagText", loadingText: "loadingText", clearAllText: "clearAllText", virtualScroll: "virtualScroll", openOnEnter: "openOnEnter", appendTo: "appendTo", bindValue: "bindValue", appearance: "appearance", maxSelectedItems: "maxSelectedItems", groupBy: "groupBy", groupValue: "groupValue", tabIndex: "tabIndex", typeahead: "typeahead" }, outputs: { blurEvent: "blur", focusEvent: "focus", changeEvent: "change", openEvent: "open", closeEvent: "close", searchEvent: "search", clearEvent: "clear", addEvent: "add", removeEvent: "remove", scroll: "scroll", scrollToEnd: "scrollToEnd" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
                provide: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NG_VALUE_ACCESSOR"],
                useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(( /**
                 * @return {?}
                 */() => NgSelectComponent)),
                multi: true
            }, NgDropdownPanelService]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 14, vars: 18, consts: [[1, "ng-select-container", 3, "mousedown"], [1, "ng-value-container"], [1, "ng-placeholder"], [4, "ngIf"], [1, "ng-input"], ["role", "combobox", 3, "readOnly", "disabled", "value", "input", "compositionstart", "compositionend", "focus", "blur", "change"], ["searchInput", ""], ["class", "ng-clear-wrapper", 3, "title", 4, "ngIf"], [1, "ng-arrow-wrapper"], [1, "ng-arrow"], ["class", "ng-dropdown-panel", 3, "virtualScroll", "bufferAmount", "appendTo", "position", "headerTemplate", "footerTemplate", "filterValue", "items", "markedItem", "ng-select-multiple", "ngClass", "id", "update", "scroll", "scrollToEnd", "outsideClick", 4, "ngIf"], ["class", "ng-value", 3, "ng-value-disabled", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "ng-value"], ["defaultLabelTemplate", ""], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["aria-hidden", "true", 1, "ng-value-icon", "left", 3, "click"], [1, "ng-value-label", 3, "ngItemLabel", "escape"], ["defaultLoadingSpinnerTemplate", ""], [3, "ngTemplateOutlet"], [1, "ng-spinner-loader"], [1, "ng-clear-wrapper", 3, "title"], ["aria-hidden", "true", 1, "ng-clear"], [1, "ng-dropdown-panel", 3, "virtualScroll", "bufferAmount", "appendTo", "position", "headerTemplate", "footerTemplate", "filterValue", "items", "markedItem", "ngClass", "id", "update", "scroll", "scrollToEnd", "outsideClick"], ["class", "ng-option", 3, "ng-option-disabled", "ng-option-selected", "ng-optgroup", "ng-option", "ng-option-child", "ng-option-marked", "click", "mouseover", 4, "ngFor", "ngForOf", "ngForTrackBy"], ["class", "ng-option", "role", "option", 3, "ng-option-marked", "mouseover", "click", 4, "ngIf"], [1, "ng-option", 3, "click", "mouseover"], ["defaultOptionTemplate", ""], [1, "ng-option-label", 3, "ngItemLabel", "escape"], ["role", "option", 1, "ng-option", 3, "mouseover", "click"], ["defaultTagTemplate", ""], [1, "ng-tag-label"], ["defaultNotFoundTemplate", ""], [1, "ng-option", "ng-option-disabled"], ["defaultTypeToSearchTemplate", ""], ["defaultLoadingTextTemplate", ""]], template: function NgSelectComponent_Template(rf, ctx) { if (rf & 1) {
        const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mousedown", function NgSelectComponent_Template_div_mousedown_0_listener($event) { return ctx.handleMousedown($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, NgSelectComponent_ng_container_4_Template, 2, 2, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, NgSelectComponent_5_Template, 1, 5, undefined, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function NgSelectComponent_Template_input_input_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r52); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](8); return ctx.filter(_r2.value); })("compositionstart", function NgSelectComponent_Template_input_compositionstart_7_listener() { return ctx.onCompositionStart(); })("compositionend", function NgSelectComponent_Template_input_compositionend_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r52); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](8); return ctx.onCompositionEnd(_r2.value); })("focus", function NgSelectComponent_Template_input_focus_7_listener($event) { return ctx.onInputFocus($event); })("blur", function NgSelectComponent_Template_input_blur_7_listener($event) { return ctx.onInputBlur($event); })("change", function NgSelectComponent_Template_input_change_7_listener($event) { return $event.stopPropagation(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, NgSelectComponent_ng_container_9_Template, 4, 1, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, NgSelectComponent_span_10_Template, 3, 1, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, NgSelectComponent_ng_dropdown_panel_13_Template, 7, 19, "ng-dropdown-panel", 10);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ng-appearance-outline", ctx.appearance === "outline")("ng-has-value", ctx.hasValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.placeholder);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.multiLabelTemplate && ctx.selectedItems.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.multiLabelTemplate && ctx.selectedValues.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("readOnly", !ctx.searchable || ctx.itemsList.maxItemsSelected)("disabled", ctx.disabled)("value", ctx.searchTerm ? ctx.searchTerm : "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("id", ctx.labelForId)("tabindex", ctx.tabIndex)("aria-expanded", ctx.isOpen)("aria-owns", ctx.isOpen ? ctx.dropdownId : null)("aria-activedescendant", ctx.isOpen ? ctx.itemsList == null ? null : ctx.itemsList.markedItem == null ? null : ctx.itemsList.markedItem.htmlId : null);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.loading);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showClear());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isOpen);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgTemplateOutlet"], NgItemLabelDirective, NgDropdownPanelComponent, _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgClass"]], styles: [".ng-select{display:block;position:relative}.ng-select,.ng-select div,.ng-select input,.ng-select span{box-sizing:border-box}.ng-select [hidden]{display:none}.ng-select.ng-select-searchable .ng-select-container .ng-value-container .ng-input{opacity:1}.ng-select.ng-select-opened .ng-select-container{z-index:1001}.ng-select.ng-select-disabled .ng-select-container .ng-value-container .ng-placeholder,.ng-select.ng-select-disabled .ng-select-container .ng-value-container .ng-value{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:default;user-select:none}.ng-select.ng-select-disabled .ng-arrow-wrapper{cursor:default}.ng-select.ng-select-filtered .ng-placeholder{display:none}.ng-select .ng-select-container{cursor:default;display:flex;outline:none;overflow:hidden;position:relative;width:100%}.ng-select .ng-select-container .ng-value-container{display:flex;flex:1}.ng-select .ng-select-container .ng-value-container .ng-input{opacity:0}.ng-select .ng-select-container .ng-value-container .ng-input>input{background:none transparent;border:0;box-shadow:none;box-sizing:content-box;cursor:default;outline:none;width:100%}.ng-select .ng-select-container .ng-value-container .ng-input>input::-ms-clear{display:none}.ng-select .ng-select-container .ng-value-container .ng-input>input[readonly]{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;padding:0;user-select:none;width:0}.ng-select.ng-select-single.ng-select-filtered .ng-select-container .ng-value-container .ng-value{visibility:hidden}.ng-select.ng-select-single .ng-select-container .ng-value-container,.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-value{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-value .ng-value-icon{display:none}.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-input{left:0;position:absolute;width:100%}.ng-select.ng-select-multiple.ng-select-disabled>.ng-select-container .ng-value-container .ng-value .ng-value-icon{display:none}.ng-select.ng-select-multiple .ng-select-container .ng-value-container{flex-wrap:wrap}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-placeholder{position:absolute}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value{white-space:nowrap}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value.ng-value-disabled .ng-value-icon{display:none}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value .ng-value-icon{cursor:pointer}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-input{flex:1;z-index:2}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-placeholder{z-index:1}.ng-select .ng-clear-wrapper{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:pointer;position:relative;user-select:none;width:17px}.ng-select .ng-clear-wrapper .ng-clear{display:inline-block;font-size:18px;line-height:1;pointer-events:none}.ng-select .ng-spinner-loader{-webkit-animation:load8 .8s linear infinite;animation:load8 .8s linear infinite;border:2px solid rgba(66,66,66,.2);border-left-color:#424242;border-radius:50%;font-size:10px;height:17px;margin-right:5px;position:relative;text-indent:-9999em;transform:translateZ(0);width:17px}.ng-select .ng-spinner-loader:after{border-radius:50%;height:17px;width:17px}@-webkit-keyframes load8{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes load8{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.ng-select .ng-arrow-wrapper{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:pointer;position:relative;text-align:center;user-select:none}.ng-select .ng-arrow-wrapper .ng-arrow{display:inline-block;height:0;pointer-events:none;position:relative;width:0}.ng-dropdown-panel{-webkit-overflow-scrolling:touch;box-sizing:border-box;opacity:0;position:absolute;width:100%;z-index:1050}.ng-dropdown-panel .ng-dropdown-panel-items{box-sizing:border-box;display:block;height:auto;max-height:240px;overflow-y:auto}.ng-dropdown-panel .ng-dropdown-panel-items .ng-optgroup,.ng-dropdown-panel .ng-dropdown-panel-items .ng-option{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option{box-sizing:border-box;cursor:pointer;display:block}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option .highlighted{font-weight:700;text-decoration:underline}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option.disabled{cursor:default}.ng-dropdown-panel .scroll-host{-webkit-overflow-scrolling:touch;display:block;overflow:hidden;overflow-y:auto;position:relative}.ng-dropdown-panel .scrollable-content{height:100%;left:0;position:absolute;top:0;width:100%}.ng-dropdown-panel .total-padding{opacity:0;width:1px}"], encapsulation: 2, changeDetection: 0 });
/** @nocollapse */
NgSelectComponent.ctorParameters = () => [
    { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Attribute"], args: ['class',] }] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Attribute"], args: ['autofocus',] }] },
    { type: NgSelectConfig },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [SELECTION_MODEL_FACTORY,] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"] },
    { type: ConsoleService }
];
NgSelectComponent.propDecorators = {
    bindLabel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    bindValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    markFirst: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    placeholder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    notFoundText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    typeToSearchText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    addTagText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    loadingText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    clearAllText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    appearance: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    dropdownPosition: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    appendTo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    loading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    closeOnSelect: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    hideSelected: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    selectOnTab: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    openOnEnter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    maxSelectedItems: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    groupBy: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    groupValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    bufferAmount: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    virtualScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    selectableGroup: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    selectableGroupAsModel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    searchFn: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    trackByFn: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    clearOnBackspace: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    labelForId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    inputAttrs: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    tabIndex: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    readonly: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    searchWhileComposing: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    minTermLength: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    editableSearchTerm: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    keyDownFn: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    typeahead: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-typeahead',] }],
    multiple: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-multiple',] }],
    addTag: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-taggable',] }],
    searchable: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-searchable',] }],
    clearable: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-clearable',] }],
    isOpen: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-opened',] }],
    items: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    compareWith: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    clearSearchOnAdd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    blurEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['blur',] }],
    focusEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['focus',] }],
    changeEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['change',] }],
    openEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['open',] }],
    closeEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['close',] }],
    searchEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['search',] }],
    clearEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['clear',] }],
    addEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['add',] }],
    removeEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['remove',] }],
    scroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['scroll',] }],
    scrollToEnd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"], args: ['scrollToEnd',] }],
    optionTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgOptionTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    optgroupTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgOptgroupTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    labelTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgLabelTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    multiLabelTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgMultiLabelTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    headerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgHeaderTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    footerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgFooterTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    notFoundTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgNotFoundTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    typeToSearchTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgTypeToSearchTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    loadingTextTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgLoadingTextTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    tagTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgTagTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    loadingSpinnerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [NgLoadingSpinnerTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    dropdownPanel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])((/**
                 * @return {?}
                 */
                () => NgDropdownPanelComponent)),] }],
    searchInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['searchInput', { static: true },] }],
    ngOptions: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChildren"], args: [NgOptionComponent, { descendants: true },] }],
    disabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-disabled',] }],
    filtered: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ng-select-filtered',] }],
    handleKeyDown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['keydown', ['$event'],] }]
};
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgSelectComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ng-select',
                template: "<div\n    (mousedown)=\"handleMousedown($event)\"\n    [class.ng-appearance-outline]=\"appearance === 'outline'\"\n    [class.ng-has-value]=\"hasValue\"\n    class=\"ng-select-container\">\n\n    <div class=\"ng-value-container\">\n        <div class=\"ng-placeholder\">{{placeholder}}</div>\n\n        <ng-container *ngIf=\"!multiLabelTemplate && selectedItems.length > 0\">\n            <div [class.ng-value-disabled]=\"item.disabled\" class=\"ng-value\" *ngFor=\"let item of selectedItems; trackBy: trackByOption\">\n                <ng-template #defaultLabelTemplate>\n                    <span class=\"ng-value-icon left\" (click)=\"unselect(item);\" aria-hidden=\"true\">\u00D7</span>\n                    <span class=\"ng-value-label\" [ngItemLabel]=\"item.label\" [escape]=\"escapeHTML\"></span>\n                </ng-template>\n\n                <ng-template\n                    [ngTemplateOutlet]=\"labelTemplate || defaultLabelTemplate\"\n                    [ngTemplateOutletContext]=\"{ item: item.value, clear: clearItem, label: item.label }\">\n                </ng-template>\n            </div>\n        </ng-container>\n\n        <ng-template *ngIf=\"multiLabelTemplate && selectedValues.length > 0\"\n                [ngTemplateOutlet]=\"multiLabelTemplate\"\n                [ngTemplateOutletContext]=\"{ items: selectedValues, clear: clearItem }\">\n        </ng-template>\n\n        <div class=\"ng-input\">\n            <input #searchInput\n                   [attr.id]=\"labelForId\"\n                   [attr.tabindex]=\"tabIndex\"\n                   [readOnly]=\"!searchable || itemsList.maxItemsSelected\"\n                   [disabled]=\"disabled\"\n                   [value]=\"searchTerm ? searchTerm : ''\"\n                   (input)=\"filter(searchInput.value)\"\n                   (compositionstart)=\"onCompositionStart()\"\n                   (compositionend)=\"onCompositionEnd(searchInput.value)\"\n                   (focus)=\"onInputFocus($event)\"\n                   (blur)=\"onInputBlur($event)\"\n                   (change)=\"$event.stopPropagation()\"\n                   role=\"combobox\"\n                   [attr.aria-expanded]=\"isOpen\"\n                   [attr.aria-owns]=\"isOpen ? dropdownId : null\"\n                   [attr.aria-activedescendant]=\"isOpen ? itemsList?.markedItem?.htmlId : null\">\n        </div>\n    </div>\n\n    <ng-container *ngIf=\"loading\">\n        <ng-template #defaultLoadingSpinnerTemplate>\n            <div class=\"ng-spinner-loader\"></div>\n        </ng-template>\n\n        <ng-template\n            [ngTemplateOutlet]=\"loadingSpinnerTemplate || defaultLoadingSpinnerTemplate\">\n        </ng-template>\n    </ng-container>\n\n    <span *ngIf=\"showClear()\" class=\"ng-clear-wrapper\" title=\"{{clearAllText}}\">\n        <span class=\"ng-clear\" aria-hidden=\"true\">\u00D7</span>\n    </span>\n\n    <span class=\"ng-arrow-wrapper\">\n        <span class=\"ng-arrow\"></span>\n    </span>\n</div>\n\n<ng-dropdown-panel *ngIf=\"isOpen\"\n                   class=\"ng-dropdown-panel\"\n                   [virtualScroll]=\"virtualScroll\"\n                   [bufferAmount]=\"bufferAmount\"\n                   [appendTo]=\"appendTo\"\n                   [position]=\"dropdownPosition\"\n                   [headerTemplate]=\"headerTemplate\"\n                   [footerTemplate]=\"footerTemplate\"\n                   [filterValue]=\"searchTerm\"\n                   [items]=\"itemsList.filteredItems\"\n                   [markedItem]=\"itemsList.markedItem\"\n                   (update)=\"viewPortItems = $event\"\n                   (scroll)=\"scroll.emit($event)\"\n                   (scrollToEnd)=\"scrollToEnd.emit($event)\"\n                   (outsideClick)=\"close()\"\n                   [class.ng-select-multiple]=\"multiple\"\n                   [ngClass]=\"appendTo ? classes : null\"\n                   [id]=\"dropdownId\">\n\n    <ng-container>\n        <div class=\"ng-option\" [attr.role]=\"item.children ? 'group' : 'option'\" (click)=\"toggleItem(item)\" (mouseover)=\"onItemHover(item)\"\n                *ngFor=\"let item of viewPortItems; trackBy: trackByOption\"\n                [class.ng-option-disabled]=\"item.disabled\"\n                [class.ng-option-selected]=\"item.selected\"\n                [class.ng-optgroup]=\"item.children\"\n                [class.ng-option]=\"!item.children\"\n                [class.ng-option-child]=\"!!item.parent\"\n                [class.ng-option-marked]=\"item === itemsList.markedItem\"\n                [attr.aria-selected]=\"item.selected\"\n                [attr.id]=\"item?.htmlId\">\n\n            <ng-template #defaultOptionTemplate>\n                <span class=\"ng-option-label\" [ngItemLabel]=\"item.label\" [escape]=\"escapeHTML\"></span>\n            </ng-template>\n\n            <ng-template\n                [ngTemplateOutlet]=\"item.children ? (optgroupTemplate || defaultOptionTemplate) : (optionTemplate || defaultOptionTemplate)\"\n                [ngTemplateOutletContext]=\"{ item: item.value, item$:item, index: item.index, searchTerm: searchTerm }\">\n            </ng-template>\n        </div>\n\n        <div class=\"ng-option\" [class.ng-option-marked]=\"!itemsList.markedItem\" (mouseover)=\"itemsList.unmarkItem()\" role=\"option\" (click)=\"selectTag()\" *ngIf=\"showAddTag\">\n            <ng-template #defaultTagTemplate>\n                <span><span class=\"ng-tag-label\">{{addTagText}}</span>\"{{searchTerm}}\"</span>\n            </ng-template>\n\n            <ng-template\n                [ngTemplateOutlet]=\"tagTemplate || defaultTagTemplate\"\n                [ngTemplateOutletContext]=\"{ searchTerm: searchTerm }\">\n            </ng-template>\n        </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"showNoItemsFound()\">\n        <ng-template #defaultNotFoundTemplate>\n            <div class=\"ng-option ng-option-disabled\">{{notFoundText}}</div>\n        </ng-template>\n\n        <ng-template\n            [ngTemplateOutlet]=\"notFoundTemplate || defaultNotFoundTemplate\"\n            [ngTemplateOutletContext]=\"{ searchTerm: searchTerm }\">\n        </ng-template>\n    </ng-container>\n\n    <ng-container *ngIf=\"showTypeToSearch()\">\n        <ng-template #defaultTypeToSearchTemplate>\n            <div class=\"ng-option ng-option-disabled\">{{typeToSearchText}}</div>\n        </ng-template>\n\n        <ng-template\n            [ngTemplateOutlet]=\"typeToSearchTemplate || defaultTypeToSearchTemplate\">\n        </ng-template>\n    </ng-container>\n\n    <ng-container *ngIf=\"loading && itemsList.filteredItems.length === 0\">\n        <ng-template #defaultLoadingTextTemplate>\n            <div class=\"ng-option ng-option-disabled\">{{loadingText}}</div>\n        </ng-template>\n\n        <ng-template\n            [ngTemplateOutlet]=\"loadingTextTemplate || defaultLoadingTextTemplate\"\n            [ngTemplateOutletContext]=\"{ searchTerm: searchTerm }\">\n        </ng-template>\n    </ng-container>\n\n</ng-dropdown-panel>\n",
                providers: [{
                        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NG_VALUE_ACCESSOR"],
                        useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(( /**
                         * @return {?}
                         */() => NgSelectComponent)),
                        multi: true
                    }, NgDropdownPanelService],
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
                host: {
                    'role': 'listbox',
                    '[class.ng-select]': 'useDefaultClass',
                    '[class.ng-select-single]': '!multiple'
                },
                styles: [".ng-select{display:block;position:relative}.ng-select,.ng-select div,.ng-select input,.ng-select span{box-sizing:border-box}.ng-select [hidden]{display:none}.ng-select.ng-select-searchable .ng-select-container .ng-value-container .ng-input{opacity:1}.ng-select.ng-select-opened .ng-select-container{z-index:1001}.ng-select.ng-select-disabled .ng-select-container .ng-value-container .ng-placeholder,.ng-select.ng-select-disabled .ng-select-container .ng-value-container .ng-value{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:default;user-select:none}.ng-select.ng-select-disabled .ng-arrow-wrapper{cursor:default}.ng-select.ng-select-filtered .ng-placeholder{display:none}.ng-select .ng-select-container{cursor:default;display:flex;outline:none;overflow:hidden;position:relative;width:100%}.ng-select .ng-select-container .ng-value-container{display:flex;flex:1}.ng-select .ng-select-container .ng-value-container .ng-input{opacity:0}.ng-select .ng-select-container .ng-value-container .ng-input>input{background:none transparent;border:0;box-shadow:none;box-sizing:content-box;cursor:default;outline:none;width:100%}.ng-select .ng-select-container .ng-value-container .ng-input>input::-ms-clear{display:none}.ng-select .ng-select-container .ng-value-container .ng-input>input[readonly]{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;padding:0;user-select:none;width:0}.ng-select.ng-select-single.ng-select-filtered .ng-select-container .ng-value-container .ng-value{visibility:hidden}.ng-select.ng-select-single .ng-select-container .ng-value-container,.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-value{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-value .ng-value-icon{display:none}.ng-select.ng-select-single .ng-select-container .ng-value-container .ng-input{left:0;position:absolute;width:100%}.ng-select.ng-select-multiple.ng-select-disabled>.ng-select-container .ng-value-container .ng-value .ng-value-icon{display:none}.ng-select.ng-select-multiple .ng-select-container .ng-value-container{flex-wrap:wrap}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-placeholder{position:absolute}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value{white-space:nowrap}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value.ng-value-disabled .ng-value-icon{display:none}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-value .ng-value-icon{cursor:pointer}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-input{flex:1;z-index:2}.ng-select.ng-select-multiple .ng-select-container .ng-value-container .ng-placeholder{z-index:1}.ng-select .ng-clear-wrapper{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:pointer;position:relative;user-select:none;width:17px}.ng-select .ng-clear-wrapper .ng-clear{display:inline-block;font-size:18px;line-height:1;pointer-events:none}.ng-select .ng-spinner-loader{-webkit-animation:load8 .8s linear infinite;animation:load8 .8s linear infinite;border:2px solid rgba(66,66,66,.2);border-left-color:#424242;border-radius:50%;font-size:10px;height:17px;margin-right:5px;position:relative;text-indent:-9999em;transform:translateZ(0);width:17px}.ng-select .ng-spinner-loader:after{border-radius:50%;height:17px;width:17px}@-webkit-keyframes load8{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes load8{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.ng-select .ng-arrow-wrapper{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;cursor:pointer;position:relative;text-align:center;user-select:none}.ng-select .ng-arrow-wrapper .ng-arrow{display:inline-block;height:0;pointer-events:none;position:relative;width:0}.ng-dropdown-panel{-webkit-overflow-scrolling:touch;box-sizing:border-box;opacity:0;position:absolute;width:100%;z-index:1050}.ng-dropdown-panel .ng-dropdown-panel-items{box-sizing:border-box;display:block;height:auto;max-height:240px;overflow-y:auto}.ng-dropdown-panel .ng-dropdown-panel-items .ng-optgroup,.ng-dropdown-panel .ng-dropdown-panel-items .ng-option{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option{box-sizing:border-box;cursor:pointer;display:block}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option .highlighted{font-weight:700;text-decoration:underline}.ng-dropdown-panel .ng-dropdown-panel-items .ng-option.disabled{cursor:default}.ng-dropdown-panel .scroll-host{-webkit-overflow-scrolling:touch;display:block;overflow:hidden;overflow-y:auto;position:relative}.ng-dropdown-panel .scrollable-content{height:100%;left:0;position:absolute;top:0;width:100%}.ng-dropdown-panel .total-padding{opacity:0;width:1px}"]
            }]
    }], function () { return [{ type: String, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Attribute"],
                args: ['class']
            }] }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Attribute"],
                args: ['autofocus']
            }] }, { type: NgSelectConfig }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [SELECTION_MODEL_FACTORY]
            }] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"] }, { type: ConsoleService }]; }, { markFirst: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], dropdownPosition: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], loading: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeOnSelect: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], hideSelected: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], selectOnTab: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], bufferAmount: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], selectableGroup: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], selectableGroupAsModel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], searchFn: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], trackByFn: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clearOnBackspace: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], labelForId: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], inputAttrs: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], readonly: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], searchWhileComposing: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], minTermLength: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editableSearchTerm: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], keyDownFn: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], multiple: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-multiple']
        }], addTag: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-taggable']
        }], searchable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-searchable']
        }], clearable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-clearable']
        }], isOpen: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-opened']
        }], blurEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['blur']
        }], focusEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['focus']
        }], changeEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['change']
        }], openEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['open']
        }], closeEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['close']
        }], searchEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['search']
        }], clearEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['clear']
        }], addEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['add']
        }], removeEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['remove']
        }], scroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['scroll']
        }], scrollToEnd: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"],
            args: ['scrollToEnd']
        }], items: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], compareWith: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clearSearchOnAdd: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], disabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-disabled']
        }], filtered: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-filtered']
        }], 
    /**
     * @param {?} $event
     * @return {?}
     */
    handleKeyDown: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['keydown', ['$event']]
        }], bindLabel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], placeholder: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], notFoundText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], typeToSearchText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], addTagText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], loadingText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clearAllText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], virtualScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], openOnEnter: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], appendTo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], bindValue: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], appearance: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], maxSelectedItems: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], groupBy: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], groupValue: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], tabIndex: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], typeahead: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ng-select-typeahead']
        }], optionTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgOptionTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], optgroupTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgOptgroupTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], labelTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgLabelTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], multiLabelTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgMultiLabelTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], headerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgHeaderTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], footerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgFooterTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], notFoundTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgNotFoundTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], typeToSearchTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgTypeToSearchTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], loadingTextTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgLoadingTextTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], tagTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgTagTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], loadingSpinnerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [NgLoadingSpinnerTemplateDirective, { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], dropdownPanel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(( /**
                             * @return {?}
                             */() => NgDropdownPanelComponent))]
        }], searchInput: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['searchInput', { static: true }]
        }], ngOptions: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChildren"],
            args: [NgOptionComponent, { descendants: true }]
        }] }); })();
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/selection-model.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @return {?}
 */
function DefaultSelectionModelFactory() {
    return new DefaultSelectionModel();
}
/**
 * @record
 */
function SelectionModel() { }
if (false) {}
class DefaultSelectionModel {
    constructor() {
        this._selected = [];
    }
    /**
     * @return {?}
     */
    get value() {
        return this._selected;
    }
    /**
     * @param {?} item
     * @param {?} multiple
     * @param {?} groupAsModel
     * @return {?}
     */
    select(item, multiple, groupAsModel) {
        item.selected = true;
        if (!item.children || (!multiple && groupAsModel)) {
            this._selected.push(item);
        }
        if (multiple) {
            if (item.parent) {
                /** @type {?} */
                const childrenCount = item.parent.children.length;
                /** @type {?} */
                const selectedCount = item.parent.children.filter((/**
                 * @param {?} x
                 * @return {?}
                 */
                x => x.selected)).length;
                item.parent.selected = childrenCount === selectedCount;
            }
            else if (item.children) {
                this._setChildrenSelectedState(item.children, true);
                this._removeChildren(item);
                if (groupAsModel && this._activeChildren(item)) {
                    this._selected = [...this._selected.filter((/**
                         * @param {?} x
                         * @return {?}
                         */
                        x => x.parent !== item)), item];
                }
                else {
                    this._selected = [...this._selected, ...item.children.filter((/**
                         * @param {?} x
                         * @return {?}
                         */
                        x => !x.disabled))];
                }
            }
        }
    }
    /**
     * @param {?} item
     * @param {?} multiple
     * @return {?}
     */
    unselect(item, multiple) {
        this._selected = this._selected.filter((/**
         * @param {?} x
         * @return {?}
         */
        x => x !== item));
        item.selected = false;
        if (multiple) {
            if (item.parent && item.parent.selected) {
                /** @type {?} */
                const children = item.parent.children;
                this._removeParent(item.parent);
                this._removeChildren(item.parent);
                this._selected.push(...children.filter((/**
                 * @param {?} x
                 * @return {?}
                 */
                x => x !== item && !x.disabled)));
                item.parent.selected = false;
            }
            else if (item.children) {
                this._setChildrenSelectedState(item.children, false);
                this._removeChildren(item);
            }
        }
    }
    /**
     * @param {?} keepDisabled
     * @return {?}
     */
    clear(keepDisabled) {
        this._selected = keepDisabled ? this._selected.filter((/**
         * @param {?} x
         * @return {?}
         */
        x => x.disabled)) : [];
    }
    /**
     * @private
     * @param {?} children
     * @param {?} selected
     * @return {?}
     */
    _setChildrenSelectedState(children, selected) {
        for (const child of children) {
            if (child.disabled) {
                continue;
            }
            child.selected = selected;
        }
        ;
    }
    /**
     * @private
     * @param {?} parent
     * @return {?}
     */
    _removeChildren(parent) {
        this._selected = [
            ...this._selected.filter((/**
             * @param {?} x
             * @return {?}
             */
            x => x.parent !== parent)),
            ...parent.children.filter((/**
             * @param {?} x
             * @return {?}
             */
            x => x.parent === parent && x.disabled && x.selected))
        ];
    }
    /**
     * @private
     * @param {?} parent
     * @return {?}
     */
    _removeParent(parent) {
        this._selected = this._selected.filter((/**
         * @param {?} x
         * @return {?}
         */
        x => x !== parent));
    }
    /**
     * @private
     * @param {?} item
     * @return {?}
     */
    _activeChildren(item) {
        return item.children.every((/**
         * @param {?} x
         * @return {?}
         */
        x => !x.disabled || x.selected));
    }
}
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ng-select.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
const ɵ0 = DefaultSelectionModelFactory;
class NgSelectModule {
}
NgSelectModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: NgSelectModule });
NgSelectModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function NgSelectModule_Factory(t) { return new (t || NgSelectModule)(); }, providers: [
        { provide: SELECTION_MODEL_FACTORY, useValue: ɵ0 }
    ], imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](NgSelectModule, { declarations: function () { return [NgDropdownPanelComponent, NgOptionComponent, NgSelectComponent, NgOptgroupTemplateDirective, NgOptionTemplateDirective, NgLabelTemplateDirective, NgMultiLabelTemplateDirective, NgHeaderTemplateDirective, NgFooterTemplateDirective, NgNotFoundTemplateDirective, NgTypeToSearchTemplateDirective, NgLoadingTextTemplateDirective, NgTagTemplateDirective, NgLoadingSpinnerTemplateDirective, NgItemLabelDirective]; }, imports: function () { return [_angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"]]; }, exports: function () { return [NgSelectComponent, NgOptionComponent, NgOptgroupTemplateDirective, NgOptionTemplateDirective, NgLabelTemplateDirective, NgMultiLabelTemplateDirective, NgHeaderTemplateDirective, NgFooterTemplateDirective, NgNotFoundTemplateDirective, NgTypeToSearchTemplateDirective, NgLoadingTextTemplateDirective, NgTagTemplateDirective, NgLoadingSpinnerTemplateDirective]; } }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgSelectModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [
                    NgDropdownPanelComponent,
                    NgOptionComponent,
                    NgSelectComponent,
                    NgOptgroupTemplateDirective,
                    NgOptionTemplateDirective,
                    NgLabelTemplateDirective,
                    NgMultiLabelTemplateDirective,
                    NgHeaderTemplateDirective,
                    NgFooterTemplateDirective,
                    NgNotFoundTemplateDirective,
                    NgTypeToSearchTemplateDirective,
                    NgLoadingTextTemplateDirective,
                    NgTagTemplateDirective,
                    NgLoadingSpinnerTemplateDirective,
                    NgItemLabelDirective
                ],
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"]
                ],
                exports: [
                    NgSelectComponent,
                    NgOptionComponent,
                    NgOptgroupTemplateDirective,
                    NgOptionTemplateDirective,
                    NgLabelTemplateDirective,
                    NgMultiLabelTemplateDirective,
                    NgHeaderTemplateDirective,
                    NgFooterTemplateDirective,
                    NgNotFoundTemplateDirective,
                    NgTypeToSearchTemplateDirective,
                    NgLoadingTextTemplateDirective,
                    NgTagTemplateDirective,
                    NgLoadingSpinnerTemplateDirective
                ],
                providers: [
                    { provide: SELECTION_MODEL_FACTORY, useValue: ɵ0 }
                ]
            }]
    }], null, null); })();

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: ng-select-ng-select.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ng-select-ng-select.js.map

/***/ }),

/***/ "./src/app/services/global/cities.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/global/cities.service.ts ***!
  \***************************************************/
/*! exports provided: CitiesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CitiesService", function() { return CitiesService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/api-server.service */ "./src/app/utils/api-server.service.ts");




class CitiesService {
    constructor(api) {
        this.api = api;
        this.data = [
            {
                "id": 2,
                "city_code": "5002",
                "name_city": "Abejorral (Antioquia)"
            },
            {
                "id": 781,
                "city_code": "54003",
                "name_city": "Ábrego (Norte de Santander)"
            },
            {
                "id": 3,
                "city_code": "5004",
                "name_city": "Abriaquí (Antioquia)"
            },
            {
                "id": 688,
                "city_code": "50006",
                "name_city": "Acacías (Meta)"
            },
            {
                "id": 576,
                "city_code": "27006",
                "name_city": "Acandí (Chocó)"
            },
            {
                "id": 606,
                "city_code": "41006",
                "name_city": "Acevedo (Huila)"
            },
            {
                "id": 151,
                "city_code": "13006",
                "name_city": "Achí (Bolívar)"
            },
            {
                "id": 607,
                "city_code": "41013",
                "name_city": "Agrado (Huila)"
            },
            {
                "id": 459,
                "city_code": "25001",
                "name_city": "Agua De Dios (Cundinamarca)"
            },
            {
                "id": 405,
                "city_code": "20011",
                "name_city": "Aguachica (Cesar)"
            },
            {
                "id": 847,
                "city_code": "68013",
                "name_city": "Aguada (Santander)"
            },
            {
                "id": 320,
                "city_code": "17013",
                "name_city": "Aguadas (Caldas)"
            },
            {
                "id": 1056,
                "city_code": "85010",
                "name_city": "Aguazul (Casanare)"
            },
            {
                "id": 406,
                "city_code": "20013",
                "name_city": "Agustín Codazzi (Cesar)"
            },
            {
                "id": 608,
                "city_code": "41016",
                "name_city": "Aipe (Huila)"
            },
            {
                "id": 460,
                "city_code": "25019",
                "name_city": "Albán (Cundinamarca)"
            },
            {
                "id": 717,
                "city_code": "52019",
                "name_city": "Albán (Nariño)"
            },
            {
                "id": 347,
                "city_code": "18029",
                "name_city": "Albania (Caquetá)"
            },
            {
                "id": 643,
                "city_code": "44035",
                "name_city": "Albania (La Guajira)"
            },
            {
                "id": 848,
                "city_code": "68020",
                "name_city": "Albania (Santander)"
            },
            {
                "id": 1007,
                "city_code": "76020",
                "name_city": "Alcalá (Valle del Cauca)"
            },
            {
                "id": 718,
                "city_code": "52022",
                "name_city": "Aldana (Nariño)"
            },
            {
                "id": 4,
                "city_code": "5021",
                "name_city": "Alejandría (Antioquia)"
            },
            {
                "id": 658,
                "city_code": "47030",
                "name_city": "Algarrobo (Magdalena)"
            },
            {
                "id": 609,
                "city_code": "41020",
                "name_city": "Algeciras (Huila)"
            },
            {
                "id": 363,
                "city_code": "19022",
                "name_city": "Almaguer (Cauca)"
            },
            {
                "id": 197,
                "city_code": "15022",
                "name_city": "Almeida (Boyacá)"
            },
            {
                "id": 960,
                "city_code": "73024",
                "name_city": "Alpujarra (Tolima)"
            },
            {
                "id": 610,
                "city_code": "41026",
                "name_city": "Altamira (Huila)"
            },
            {
                "id": 577,
                "city_code": "27025",
                "name_city": "Alto Baudó (Chocó)"
            },
            {
                "id": 152,
                "city_code": "13030",
                "name_city": "Altos Del Rosario (Bolívar)"
            },
            {
                "id": 961,
                "city_code": "73026",
                "name_city": "Alvarado (Tolima)"
            },
            {
                "id": 5,
                "city_code": "5030",
                "name_city": "Amagá (Antioquia)"
            },
            {
                "id": 6,
                "city_code": "5031",
                "name_city": "Amalfi (Antioquia)"
            },
            {
                "id": 962,
                "city_code": "73030",
                "name_city": "Ambalema (Tolima)"
            },
            {
                "id": 461,
                "city_code": "25035",
                "name_city": "Anapoima (Cundinamarca)"
            },
            {
                "id": 719,
                "city_code": "52036",
                "name_city": "Ancuyá (Nariño)"
            },
            {
                "id": 1008,
                "city_code": "76036",
                "name_city": "Andalucía (Valle del Cauca)"
            },
            {
                "id": 7,
                "city_code": "5034",
                "name_city": "Andes (Antioquia)"
            },
            {
                "id": 8,
                "city_code": "5036",
                "name_city": "Angelópolis (Antioquia)"
            },
            {
                "id": 9,
                "city_code": "5038",
                "name_city": "Angostura (Antioquia)"
            },
            {
                "id": 462,
                "city_code": "25040",
                "name_city": "Anolaima (Cundinamarca)"
            },
            {
                "id": 10,
                "city_code": "5040",
                "name_city": "Anorí (Antioquia)"
            },
            {
                "id": 321,
                "city_code": "17042",
                "name_city": "Anserma (Caldas)"
            },
            {
                "id": 1009,
                "city_code": "76041",
                "name_city": "Ansermanuevo (Valle del Cauca)"
            },
            {
                "id": 12,
                "city_code": "5044",
                "name_city": "Anzá (Antioquia)"
            },
            {
                "id": 963,
                "city_code": "73043",
                "name_city": "Anzoátegui (Tolima)"
            },
            {
                "id": 13,
                "city_code": "5045",
                "name_city": "Apartadó (Antioquia)"
            },
            {
                "id": 833,
                "city_code": "66045",
                "name_city": "Apía (Risaralda)"
            },
            {
                "id": 533,
                "city_code": "25599",
                "name_city": "Apulo (Cundinamarca)"
            },
            {
                "id": 198,
                "city_code": "15047",
                "name_city": "Aquitania (Boyacá)"
            },
            {
                "id": 659,
                "city_code": "47053",
                "name_city": "Aracataca (Magdalena)"
            },
            {
                "id": 322,
                "city_code": "17050",
                "name_city": "Aranzazu (Caldas)"
            },
            {
                "id": 849,
                "city_code": "68051",
                "name_city": "Aratoca (Santander)"
            },
            {
                "id": 1048,
                "city_code": "81001",
                "name_city": "Arauca (Arauca)"
            },
            {
                "id": 1049,
                "city_code": "81065",
                "name_city": "Arauquita (Arauca)"
            },
            {
                "id": 463,
                "city_code": "25053",
                "name_city": "Arbeláez (Cundinamarca)"
            },
            {
                "id": 720,
                "city_code": "52051",
                "name_city": "Arboleda (Nariño)"
            },
            {
                "id": 782,
                "city_code": "54051",
                "name_city": "Arboledas (Norte de Santander)"
            },
            {
                "id": 14,
                "city_code": "5051",
                "name_city": "Arboletes (Antioquia)"
            },
            {
                "id": 199,
                "city_code": "15051",
                "name_city": "Arcabuco (Boyacá)"
            },
            {
                "id": 153,
                "city_code": "13042",
                "name_city": "Arenal (Bolívar)"
            },
            {
                "id": 15,
                "city_code": "5055",
                "name_city": "Argelia (Antioquia)"
            },
            {
                "id": 364,
                "city_code": "19050",
                "name_city": "Argelia (Cauca)"
            },
            {
                "id": 1010,
                "city_code": "76054",
                "name_city": "Argelia (Valle del Cauca)"
            },
            {
                "id": 660,
                "city_code": "47058",
                "name_city": "Ariguaní (Magdalena)"
            },
            {
                "id": 154,
                "city_code": "13052",
                "name_city": "Arjona (Bolívar)"
            },
            {
                "id": 16,
                "city_code": "5059",
                "name_city": "Armenia (Antioquia)"
            },
            {
                "id": 820,
                "city_code": "63001",
                "name_city": "Armenia (Quindío)"
            },
            {
                "id": 964,
                "city_code": "73055",
                "name_city": "Armero (Tolima)"
            },
            {
                "id": 155,
                "city_code": "13062",
                "name_city": "Arroyohondo (Bolívar)"
            },
            {
                "id": 407,
                "city_code": "20032",
                "name_city": "Astrea (Cesar)"
            },
            {
                "id": 965,
                "city_code": "73067",
                "name_city": "Ataco (Tolima)"
            },
            {
                "id": 578,
                "city_code": "27050",
                "name_city": "Atrato (Chocó)"
            },
            {
                "id": 430,
                "city_code": "23068",
                "name_city": "Ayapel (Córdoba)"
            },
            {
                "id": 579,
                "city_code": "27073",
                "name_city": "Bagadó (Chocó)"
            },
            {
                "id": 580,
                "city_code": "27075",
                "name_city": "Bahía Solano (Chocó)"
            },
            {
                "id": 581,
                "city_code": "27077",
                "name_city": "Bajo Baudó (Chocó)"
            },
            {
                "id": 365,
                "city_code": "19075",
                "name_city": "Balboa (Cauca)"
            },
            {
                "id": 834,
                "city_code": "66075",
                "name_city": "Balboa (Risaralda)"
            },
            {
                "id": 127,
                "city_code": "8078",
                "name_city": "Baranoa (Atlántico)"
            },
            {
                "id": 611,
                "city_code": "41078",
                "name_city": "Baraya (Huila)"
            },
            {
                "id": 721,
                "city_code": "52079",
                "name_city": "Barbacoas (Nariño)"
            },
            {
                "id": 17,
                "city_code": "5079",
                "name_city": "Barbosa (Antioquia)"
            },
            {
                "id": 850,
                "city_code": "68077",
                "name_city": "Barbosa (Santander)"
            },
            {
                "id": 851,
                "city_code": "68079",
                "name_city": "Barichara (Santander)"
            },
            {
                "id": 689,
                "city_code": "50110",
                "name_city": "Barranca De Upía (Meta)"
            },
            {
                "id": 852,
                "city_code": "68081",
                "name_city": "Barrancabermeja (Santander)"
            },
            {
                "id": 644,
                "city_code": "44078",
                "name_city": "Barrancas (La Guajira)"
            },
            {
                "id": 156,
                "city_code": "13074",
                "name_city": "Barranco De Loba (Bolívar)"
            },
            {
                "id": 1101,
                "city_code": "94343",
                "name_city": "Barranco Minas (Guainía)"
            },
            {
                "id": 126,
                "city_code": "8001",
                "name_city": "Barranquilla (Atlántico)"
            },
            {
                "id": 408,
                "city_code": "20045",
                "name_city": "Becerril (Cesar)"
            },
            {
                "id": 323,
                "city_code": "17088",
                "name_city": "Belalcázar (Caldas)"
            },
            {
                "id": 200,
                "city_code": "15087",
                "name_city": "Belén (Boyacá)"
            },
            {
                "id": 722,
                "city_code": "52083",
                "name_city": "Belén (Nariño)"
            },
            {
                "id": 348,
                "city_code": "18094",
                "name_city": "Belén De Los Andaquíes (Caquetá)"
            },
            {
                "id": 835,
                "city_code": "66088",
                "name_city": "Belén De Umbría (Risaralda)"
            },
            {
                "id": 19,
                "city_code": "5088",
                "name_city": "Bello (Antioquia)"
            },
            {
                "id": 18,
                "city_code": "5086",
                "name_city": "Belmira (Antioquia)"
            },
            {
                "id": 464,
                "city_code": "25086",
                "name_city": "Beltrán (Cundinamarca)"
            },
            {
                "id": 201,
                "city_code": "15090",
                "name_city": "Berbeo (Boyacá)"
            },
            {
                "id": 20,
                "city_code": "5091",
                "name_city": "Betania (Antioquia)"
            },
            {
                "id": 202,
                "city_code": "15092",
                "name_city": "Betéitiva (Boyacá)"
            },
            {
                "id": 21,
                "city_code": "5093",
                "name_city": "Betulia (Antioquia)"
            },
            {
                "id": 853,
                "city_code": "68092",
                "name_city": "Betulia (Santander)"
            },
            {
                "id": 465,
                "city_code": "25095",
                "name_city": "Bituima (Cundinamarca)"
            },
            {
                "id": 203,
                "city_code": "15097",
                "name_city": "Boavita (Boyacá)"
            },
            {
                "id": 783,
                "city_code": "54099",
                "name_city": "Bochalema (Norte de Santander)"
            },
            {
                "id": 149,
                "city_code": "11001",
                "name_city": "Bogotá, D.c. (Bogotá)"
            },
            {
                "id": 466,
                "city_code": "25099",
                "name_city": "Bojacá (Cundinamarca)"
            },
            {
                "id": 582,
                "city_code": "27099",
                "name_city": "Bojayá (Chocó)"
            },
            {
                "id": 366,
                "city_code": "19100",
                "name_city": "Bolívar (Cauca)"
            },
            {
                "id": 854,
                "city_code": "68101",
                "name_city": "Bolívar (Santander)"
            },
            {
                "id": 1011,
                "city_code": "76100",
                "name_city": "Bolívar (Valle del Cauca)"
            },
            {
                "id": 409,
                "city_code": "20060",
                "name_city": "Bosconia (Cesar)"
            },
            {
                "id": 204,
                "city_code": "15104",
                "name_city": "Boyacá (Boyacá)"
            },
            {
                "id": 23,
                "city_code": "5107",
                "name_city": "Briceño (Antioquia)"
            },
            {
                "id": 205,
                "city_code": "15106",
                "name_city": "Briceño (Boyacá)"
            },
            {
                "id": 846,
                "city_code": "68001",
                "name_city": "Bucaramanga (Santander)"
            },
            {
                "id": 784,
                "city_code": "54109",
                "name_city": "Bucarasica (Norte de Santander)"
            },
            {
                "id": 1012,
                "city_code": "76109",
                "name_city": "Buenaventura (Valle del Cauca)"
            },
            {
                "id": 206,
                "city_code": "15109",
                "name_city": "Buenavista (Boyacá)"
            },
            {
                "id": 431,
                "city_code": "23079",
                "name_city": "Buenavista (Córdoba)"
            },
            {
                "id": 821,
                "city_code": "63111",
                "name_city": "Buenavista (Quindío)"
            },
            {
                "id": 934,
                "city_code": "70110",
                "name_city": "Buenavista (Sucre)"
            },
            {
                "id": 367,
                "city_code": "19110",
                "name_city": "Buenos Aires (Cauca)"
            },
            {
                "id": 723,
                "city_code": "52110",
                "name_city": "Buesaco (Nariño)"
            },
            {
                "id": 1014,
                "city_code": "76113",
                "name_city": "Bugalagrande (Valle del Cauca)"
            },
            {
                "id": 24,
                "city_code": "5113",
                "name_city": "Buriticá (Antioquia)"
            },
            {
                "id": 207,
                "city_code": "15114",
                "name_city": "Busbanzá (Boyacá)"
            },
            {
                "id": 467,
                "city_code": "25120",
                "name_city": "Cabrera (Cundinamarca)"
            },
            {
                "id": 855,
                "city_code": "68121",
                "name_city": "Cabrera (Santander)"
            },
            {
                "id": 690,
                "city_code": "50124",
                "name_city": "Cabuyaro (Meta)"
            },
            {
                "id": 1106,
                "city_code": "94886",
                "name_city": "Cacahual (Guainía)"
            },
            {
                "id": 25,
                "city_code": "5120",
                "name_city": "Cáceres (Antioquia)"
            },
            {
                "id": 468,
                "city_code": "25123",
                "name_city": "Cachipay (Cundinamarca)"
            },
            {
                "id": 786,
                "city_code": "54128",
                "name_city": "Cáchira (Norte de Santander)"
            },
            {
                "id": 785,
                "city_code": "54125",
                "name_city": "Cácota (Norte de Santander)"
            },
            {
                "id": 26,
                "city_code": "5125",
                "name_city": "Caicedo (Antioquia)"
            },
            {
                "id": 1015,
                "city_code": "76122",
                "name_city": "Caicedonia (Valle del Cauca)"
            },
            {
                "id": 935,
                "city_code": "70124",
                "name_city": "Caimito (Sucre)"
            },
            {
                "id": 966,
                "city_code": "73124",
                "name_city": "Cajamarca (Tolima)"
            },
            {
                "id": 368,
                "city_code": "19130",
                "name_city": "Cajibío (Cauca)"
            },
            {
                "id": 469,
                "city_code": "25126",
                "name_city": "Cajicá (Cundinamarca)"
            },
            {
                "id": 157,
                "city_code": "13140",
                "name_city": "Calamar (Bolívar)"
            },
            {
                "id": 1110,
                "city_code": "95015",
                "name_city": "Calamar (Guaviare)"
            },
            {
                "id": 822,
                "city_code": "63130",
                "name_city": "Calarcá (Quindío)"
            },
            {
                "id": 27,
                "city_code": "5129",
                "name_city": "Caldas (Antioquia)"
            },
            {
                "id": 208,
                "city_code": "15131",
                "name_city": "Caldas (Boyacá)"
            },
            {
                "id": 369,
                "city_code": "19137",
                "name_city": "Caldono (Cauca)"
            },
            {
                "id": 1006,
                "city_code": "76001",
                "name_city": "Cali (Valle del Cauca)"
            },
            {
                "id": 856,
                "city_code": "68132",
                "name_city": "California (Santander)"
            },
            {
                "id": 1016,
                "city_code": "76126",
                "name_city": "Calima (Valle del Cauca)"
            },
            {
                "id": 370,
                "city_code": "19142",
                "name_city": "Caloto (Cauca)"
            },
            {
                "id": 28,
                "city_code": "5134",
                "name_city": "Campamento (Antioquia)"
            },
            {
                "id": 128,
                "city_code": "8137",
                "name_city": "Campo De La Cruz (Atlántico)"
            },
            {
                "id": 612,
                "city_code": "41132",
                "name_city": "Campoalegre (Huila)"
            },
            {
                "id": 209,
                "city_code": "15135",
                "name_city": "Campohermoso (Boyacá)"
            },
            {
                "id": 432,
                "city_code": "23090",
                "name_city": "Canalete (Córdoba)"
            },
            {
                "id": 29,
                "city_code": "5138",
                "name_city": "Cañasgordas (Antioquia)"
            },
            {
                "id": 129,
                "city_code": "8141",
                "name_city": "Candelaria (Atlántico)"
            },
            {
                "id": 1017,
                "city_code": "76130",
                "name_city": "Candelaria (Valle del Cauca)"
            },
            {
                "id": 158,
                "city_code": "13160",
                "name_city": "Cantagallo (Bolívar)"
            },
            {
                "id": 470,
                "city_code": "25148",
                "name_city": "Caparrapí (Cundinamarca)"
            },
            {
                "id": 857,
                "city_code": "68147",
                "name_city": "Capitanejo (Santander)"
            },
            {
                "id": 471,
                "city_code": "25151",
                "name_city": "Cáqueza (Cundinamarca)"
            },
            {
                "id": 30,
                "city_code": "5142",
                "name_city": "Caracolí (Antioquia)"
            },
            {
                "id": 31,
                "city_code": "5145",
                "name_city": "Caramanta (Antioquia)"
            },
            {
                "id": 858,
                "city_code": "68152",
                "name_city": "Carcasí (Santander)"
            },
            {
                "id": 32,
                "city_code": "5147",
                "name_city": "Carepa (Antioquia)"
            },
            {
                "id": 967,
                "city_code": "73148",
                "name_city": "Carmen De Apicalá (Tolima)"
            },
            {
                "id": 472,
                "city_code": "25154",
                "name_city": "Carmen De Carupa (Cundinamarca)"
            },
            {
                "id": 584,
                "city_code": "27150",
                "name_city": "Carmen Del Darién (Chocó)"
            },
            {
                "id": 34,
                "city_code": "5150",
                "name_city": "Carolina (Antioquia)"
            },
            {
                "id": 150,
                "city_code": "13001",
                "name_city": "Cartagena De Indias (Bolívar)"
            },
            {
                "id": 349,
                "city_code": "18150",
                "name_city": "Cartagena Del Chairá (Caquetá)"
            },
            {
                "id": 1018,
                "city_code": "76147",
                "name_city": "Cartago (Valle del Cauca)"
            },
            {
                "id": 1114,
                "city_code": "97161",
                "name_city": "Carurú (Vaupés)"
            },
            {
                "id": 968,
                "city_code": "73152",
                "name_city": "Casabianca (Tolima)"
            },
            {
                "id": 691,
                "city_code": "50150",
                "name_city": "Castilla La Nueva (Meta)"
            },
            {
                "id": 35,
                "city_code": "5154",
                "name_city": "Caucasia (Antioquia)"
            },
            {
                "id": 859,
                "city_code": "68160",
                "name_city": "Cepitá (Santander)"
            },
            {
                "id": 433,
                "city_code": "23162",
                "name_city": "Cereté (Córdoba)"
            },
            {
                "id": 210,
                "city_code": "15162",
                "name_city": "Cerinza (Boyacá)"
            },
            {
                "id": 860,
                "city_code": "68162",
                "name_city": "Cerrito (Santander)"
            },
            {
                "id": 661,
                "city_code": "47161",
                "name_city": "Cerro De San Antonio (Magdalena)"
            },
            {
                "id": 585,
                "city_code": "27160",
                "name_city": "Cértegui (Chocó)"
            },
            {
                "id": 731,
                "city_code": "52240",
                "name_city": "Chachagüí (Nariño)"
            },
            {
                "id": 473,
                "city_code": "25168",
                "name_city": "Chaguaní (Cundinamarca)"
            },
            {
                "id": 939,
                "city_code": "70230",
                "name_city": "Chalán (Sucre)"
            },
            {
                "id": 1057,
                "city_code": "85015",
                "name_city": "Chámeza (Casanare)"
            },
            {
                "id": 969,
                "city_code": "73168",
                "name_city": "Chaparral (Tolima)"
            },
            {
                "id": 861,
                "city_code": "68167",
                "name_city": "Charalá (Santander)"
            },
            {
                "id": 862,
                "city_code": "68169",
                "name_city": "Charta (Santander)"
            },
            {
                "id": 474,
                "city_code": "25175",
                "name_city": "Chía (Cundinamarca)"
            },
            {
                "id": 36,
                "city_code": "5172",
                "name_city": "Chigorodó (Antioquia)"
            },
            {
                "id": 434,
                "city_code": "23168",
                "name_city": "Chimá (Córdoba)"
            },
            {
                "id": 863,
                "city_code": "68176",
                "name_city": "Chima (Santander)"
            },
            {
                "id": 410,
                "city_code": "20175",
                "name_city": "Chimichagua (Cesar)"
            },
            {
                "id": 787,
                "city_code": "54172",
                "name_city": "Chinácota (Norte de Santander)"
            },
            {
                "id": 211,
                "city_code": "15172",
                "name_city": "Chinavita (Boyacá)"
            },
            {
                "id": 324,
                "city_code": "17174",
                "name_city": "Chinchiná (Caldas)"
            },
            {
                "id": 435,
                "city_code": "23182",
                "name_city": "Chinú (Córdoba)"
            },
            {
                "id": 475,
                "city_code": "25178",
                "name_city": "Chipaque (Cundinamarca)"
            },
            {
                "id": 864,
                "city_code": "68179",
                "name_city": "Chipatá (Santander)"
            },
            {
                "id": 212,
                "city_code": "15176",
                "name_city": "Chiquinquirá (Boyacá)"
            },
            {
                "id": 225,
                "city_code": "15232",
                "name_city": "Chíquiza (Boyacá)"
            },
            {
                "id": 411,
                "city_code": "20178",
                "name_city": "Chiriguaná (Cesar)"
            },
            {
                "id": 213,
                "city_code": "15180",
                "name_city": "Chiscas (Boyacá)"
            },
            {
                "id": 214,
                "city_code": "15183",
                "name_city": "Chita (Boyacá)"
            },
            {
                "id": 788,
                "city_code": "54174",
                "name_city": "Chitagá (Norte de Santander)"
            },
            {
                "id": 215,
                "city_code": "15185",
                "name_city": "Chitaraque (Boyacá)"
            },
            {
                "id": 216,
                "city_code": "15187",
                "name_city": "Chivatá (Boyacá)"
            },
            {
                "id": 662,
                "city_code": "47170",
                "name_city": "Chivolo (Magdalena)"
            },
            {
                "id": 226,
                "city_code": "15236",
                "name_city": "Chivor (Boyacá)"
            },
            {
                "id": 476,
                "city_code": "25181",
                "name_city": "Choachí (Cundinamarca)"
            },
            {
                "id": 477,
                "city_code": "25183",
                "name_city": "Chocontá (Cundinamarca)"
            },
            {
                "id": 159,
                "city_code": "13188",
                "name_city": "Cicuco (Bolívar)"
            },
            {
                "id": 663,
                "city_code": "47189",
                "name_city": "Ciénaga (Magdalena)"
            },
            {
                "id": 436,
                "city_code": "23189",
                "name_city": "Ciénaga De Oro (Córdoba)"
            },
            {
                "id": 217,
                "city_code": "15189",
                "name_city": "Ciénega (Boyacá)"
            },
            {
                "id": 865,
                "city_code": "68190",
                "name_city": "Cimitarra (Santander)"
            },
            {
                "id": 823,
                "city_code": "63190",
                "name_city": "Circasia (Quindío)"
            },
            {
                "id": 37,
                "city_code": "5190",
                "name_city": "Cisneros (Antioquia)"
            },
            {
                "id": 22,
                "city_code": "5101",
                "name_city": "Ciudad Bolívar (Antioquia)"
            },
            {
                "id": 161,
                "city_code": "13222",
                "name_city": "Clemencia (Bolívar)"
            },
            {
                "id": 38,
                "city_code": "5197",
                "name_city": "Cocorná (Antioquia)"
            },
            {
                "id": 970,
                "city_code": "73200",
                "name_city": "Coello (Tolima)"
            },
            {
                "id": 478,
                "city_code": "25200",
                "name_city": "Cogua (Cundinamarca)"
            },
            {
                "id": 613,
                "city_code": "41206",
                "name_city": "Colombia (Huila)"
            },
            {
                "id": 724,
                "city_code": "52203",
                "name_city": "Colón (Nariño)"
            },
            {
                "id": 1075,
                "city_code": "86219",
                "name_city": "Colón (Putumayo)"
            },
            {
                "id": 936,
                "city_code": "70204",
                "name_city": "Colosó (Sucre)"
            },
            {
                "id": 218,
                "city_code": "15204",
                "name_city": "Cómbita (Boyacá)"
            },
            {
                "id": 39,
                "city_code": "5206",
                "name_city": "Concepción (Antioquia)"
            },
            {
                "id": 866,
                "city_code": "68207",
                "name_city": "Concepción (Santander)"
            },
            {
                "id": 40,
                "city_code": "5209",
                "name_city": "Concordia (Antioquia)"
            },
            {
                "id": 664,
                "city_code": "47205",
                "name_city": "Concordia (Magdalena)"
            },
            {
                "id": 586,
                "city_code": "27205",
                "name_city": "Condoto (Chocó)"
            },
            {
                "id": 867,
                "city_code": "68209",
                "name_city": "Confines (Santander)"
            },
            {
                "id": 725,
                "city_code": "52207",
                "name_city": "Consacá (Nariño)"
            },
            {
                "id": 726,
                "city_code": "52210",
                "name_city": "Contadero (Nariño)"
            },
            {
                "id": 868,
                "city_code": "68211",
                "name_city": "Contratación (Santander)"
            },
            {
                "id": 789,
                "city_code": "54206",
                "name_city": "Convención (Norte de Santander)"
            },
            {
                "id": 41,
                "city_code": "5212",
                "name_city": "Copacabana (Antioquia)"
            },
            {
                "id": 219,
                "city_code": "15212",
                "name_city": "Coper (Boyacá)"
            },
            {
                "id": 160,
                "city_code": "13212",
                "name_city": "Córdoba (Bolívar)"
            },
            {
                "id": 727,
                "city_code": "52215",
                "name_city": "Córdoba (Nariño)"
            },
            {
                "id": 824,
                "city_code": "63212",
                "name_city": "Córdoba (Quindío)"
            },
            {
                "id": 371,
                "city_code": "19212",
                "name_city": "Corinto (Cauca)"
            },
            {
                "id": 869,
                "city_code": "68217",
                "name_city": "Coromoro (Santander)"
            },
            {
                "id": 937,
                "city_code": "70215",
                "name_city": "Corozal (Sucre)"
            },
            {
                "id": 220,
                "city_code": "15215",
                "name_city": "Corrales (Boyacá)"
            },
            {
                "id": 479,
                "city_code": "25214",
                "name_city": "Cota (Cundinamarca)"
            },
            {
                "id": 437,
                "city_code": "23300",
                "name_city": "Cotorra (Córdoba)"
            },
            {
                "id": 221,
                "city_code": "15218",
                "name_city": "Covarachía (Boyacá)"
            },
            {
                "id": 938,
                "city_code": "70221",
                "name_city": "Coveñas (Sucre)"
            },
            {
                "id": 971,
                "city_code": "73217",
                "name_city": "Coyaima (Tolima)"
            },
            {
                "id": 1050,
                "city_code": "81220",
                "name_city": "Cravo Norte (Arauca)"
            },
            {
                "id": 728,
                "city_code": "52224",
                "name_city": "Cuaspúd (Nariño)"
            },
            {
                "id": 222,
                "city_code": "15223",
                "name_city": "Cubará (Boyacá)"
            },
            {
                "id": 692,
                "city_code": "50223",
                "name_city": "Cubarral (Meta)"
            },
            {
                "id": 223,
                "city_code": "15224",
                "name_city": "Cucaita (Boyacá)"
            },
            {
                "id": 480,
                "city_code": "25224",
                "name_city": "Cucunubá (Cundinamarca)"
            },
            {
                "id": 790,
                "city_code": "54223",
                "name_city": "Cucutilla (Norte de Santander)"
            },
            {
                "id": 224,
                "city_code": "15226",
                "name_city": "Cuítiva (Boyacá)"
            },
            {
                "id": 693,
                "city_code": "50226",
                "name_city": "Cumaral (Meta)"
            },
            {
                "id": 1122,
                "city_code": "99773",
                "name_city": "Cumaribo (Vichada)"
            },
            {
                "id": 729,
                "city_code": "52227",
                "name_city": "Cumbal (Nariño)"
            },
            {
                "id": 730,
                "city_code": "52233",
                "name_city": "Cumbitara (Nariño)"
            },
            {
                "id": 972,
                "city_code": "73226",
                "name_city": "Cunday (Tolima)"
            },
            {
                "id": 350,
                "city_code": "18205",
                "name_city": "Curillo (Caquetá)"
            },
            {
                "id": 870,
                "city_code": "68229",
                "name_city": "Curití (Santander)"
            },
            {
                "id": 412,
                "city_code": "20228",
                "name_city": "Curumaní (Cesar)"
            },
            {
                "id": 42,
                "city_code": "5234",
                "name_city": "Dabeiba (Antioquia)"
            },
            {
                "id": 1019,
                "city_code": "76233",
                "name_city": "Dagua (Valle del Cauca)"
            },
            {
                "id": 645,
                "city_code": "44090",
                "name_city": "Dibulla (La Guajira)"
            },
            {
                "id": 646,
                "city_code": "44098",
                "name_city": "Distracción (La Guajira)"
            },
            {
                "id": 973,
                "city_code": "73236",
                "name_city": "Dolores (Tolima)"
            },
            {
                "id": 43,
                "city_code": "5237",
                "name_city": "Donmatías (Antioquia)"
            },
            {
                "id": 836,
                "city_code": "66170",
                "name_city": "Dosquebradas (Risaralda)"
            },
            {
                "id": 227,
                "city_code": "15238",
                "name_city": "Duitama (Boyacá)"
            },
            {
                "id": 791,
                "city_code": "54239",
                "name_city": "Durania (Norte de Santander)"
            },
            {
                "id": 44,
                "city_code": "5240",
                "name_city": "Ebéjico (Antioquia)"
            },
            {
                "id": 1020,
                "city_code": "76243",
                "name_city": "El Águila (Valle del Cauca)"
            },
            {
                "id": 45,
                "city_code": "5250",
                "name_city": "El Bagre (Antioquia)"
            },
            {
                "id": 665,
                "city_code": "47245",
                "name_city": "El Banco (Magdalena)"
            },
            {
                "id": 1021,
                "city_code": "76246",
                "name_city": "El Cairo (Valle del Cauca)"
            },
            {
                "id": 694,
                "city_code": "50245",
                "name_city": "El Calvario (Meta)"
            },
            {
                "id": 583,
                "city_code": "27135",
                "name_city": "El Cantón Del San Pablo (Chocó)"
            },
            {
                "id": 792,
                "city_code": "54245",
                "name_city": "El Carmen (Norte de Santander)"
            },
            {
                "id": 587,
                "city_code": "27245",
                "name_city": "El Carmen De Atrato (Chocó)"
            },
            {
                "id": 162,
                "city_code": "13244",
                "name_city": "El Carmen De Bolívar (Bolívar)"
            },
            {
                "id": 871,
                "city_code": "68235",
                "name_city": "El Carmen De Chucurí (Santander)"
            },
            {
                "id": 33,
                "city_code": "5148",
                "name_city": "El Carmen De Viboral (Antioquia)"
            },
            {
                "id": 695,
                "city_code": "50251",
                "name_city": "El Castillo (Meta)"
            },
            {
                "id": 1022,
                "city_code": "76248",
                "name_city": "El Cerrito (Valle del Cauca)"
            },
            {
                "id": 732,
                "city_code": "52250",
                "name_city": "El Charco (Nariño)"
            },
            {
                "id": 228,
                "city_code": "15244",
                "name_city": "El Cocuy (Boyacá)"
            },
            {
                "id": 481,
                "city_code": "25245",
                "name_city": "El Colegio (Cundinamarca)"
            },
            {
                "id": 413,
                "city_code": "20238",
                "name_city": "El Copey (Cesar)"
            },
            {
                "id": 351,
                "city_code": "18247",
                "name_city": "El Doncello (Caquetá)"
            },
            {
                "id": 696,
                "city_code": "50270",
                "name_city": "El Dorado (Meta)"
            },
            {
                "id": 1023,
                "city_code": "76250",
                "name_city": "El Dovio (Valle del Cauca)"
            },
            {
                "id": 1090,
                "city_code": "91263",
                "name_city": "El Encanto (Amazonas)"
            },
            {
                "id": 229,
                "city_code": "15248",
                "name_city": "El Espino (Boyacá)"
            },
            {
                "id": 872,
                "city_code": "68245",
                "name_city": "El Guacamayo (Santander)"
            },
            {
                "id": 163,
                "city_code": "13248",
                "name_city": "El Guamo (Bolívar)"
            },
            {
                "id": 588,
                "city_code": "27250",
                "name_city": "El Litoral Del San Juan (Chocó)"
            },
            {
                "id": 647,
                "city_code": "44110",
                "name_city": "El Molino (La Guajira)"
            },
            {
                "id": 414,
                "city_code": "20250",
                "name_city": "El Paso (Cesar)"
            },
            {
                "id": 352,
                "city_code": "18256",
                "name_city": "El Paujíl (Caquetá)"
            },
            {
                "id": 733,
                "city_code": "52254",
                "name_city": "El Peñol (Nariño)"
            },
            {
                "id": 164,
                "city_code": "13268",
                "name_city": "El Peñón (Bolívar)"
            },
            {
                "id": 482,
                "city_code": "25258",
                "name_city": "El Peñón (Cundinamarca)"
            },
            {
                "id": 873,
                "city_code": "68250",
                "name_city": "El Peñón (Santander)"
            },
            {
                "id": 666,
                "city_code": "47258",
                "name_city": "El Piñón (Magdalena)"
            },
            {
                "id": 874,
                "city_code": "68255",
                "name_city": "El Playón (Santander)"
            },
            {
                "id": 667,
                "city_code": "47268",
                "name_city": "El Retén (Magdalena)"
            },
            {
                "id": 1111,
                "city_code": "95025",
                "name_city": "El Retorno (Guaviare)"
            },
            {
                "id": 940,
                "city_code": "70233",
                "name_city": "El Roble (Sucre)"
            },
            {
                "id": 483,
                "city_code": "25260",
                "name_city": "El Rosal (Cundinamarca)"
            },
            {
                "id": 734,
                "city_code": "52256",
                "name_city": "El Rosario (Nariño)"
            },
            {
                "id": 104,
                "city_code": "5697",
                "name_city": "El Santuario (Antioquia)"
            },
            {
                "id": 735,
                "city_code": "52258",
                "name_city": "El Tablón De Gómez (Nariño)"
            },
            {
                "id": 372,
                "city_code": "19256",
                "name_city": "El Tambo (Cauca)"
            },
            {
                "id": 736,
                "city_code": "52260",
                "name_city": "El Tambo (Nariño)"
            },
            {
                "id": 793,
                "city_code": "54250",
                "name_city": "El Tarra (Norte de Santander)"
            },
            {
                "id": 794,
                "city_code": "54261",
                "name_city": "El Zulia (Norte de Santander)"
            },
            {
                "id": 614,
                "city_code": "41244",
                "name_city": "Elías (Huila)"
            },
            {
                "id": 875,
                "city_code": "68264",
                "name_city": "Encino (Santander)"
            },
            {
                "id": 876,
                "city_code": "68266",
                "name_city": "Enciso (Santander)"
            },
            {
                "id": 46,
                "city_code": "5264",
                "name_city": "Entrerríos (Antioquia)"
            },
            {
                "id": 47,
                "city_code": "5266",
                "name_city": "Envigado (Antioquia)"
            },
            {
                "id": 974,
                "city_code": "73268",
                "name_city": "Espinal (Tolima)"
            },
            {
                "id": 484,
                "city_code": "25269",
                "name_city": "Facatativá (Cundinamarca)"
            },
            {
                "id": 975,
                "city_code": "73270",
                "name_city": "Falan (Tolima)"
            },
            {
                "id": 325,
                "city_code": "17272",
                "name_city": "Filadelfia (Caldas)"
            },
            {
                "id": 825,
                "city_code": "63272",
                "name_city": "Filandia (Quindío)"
            },
            {
                "id": 230,
                "city_code": "15272",
                "name_city": "Firavitoba (Boyacá)"
            },
            {
                "id": 976,
                "city_code": "73275",
                "name_city": "Flandes (Tolima)"
            },
            {
                "id": 346,
                "city_code": "18001",
                "name_city": "Florencia (Caquetá)"
            },
            {
                "id": 373,
                "city_code": "19290",
                "name_city": "Florencia (Cauca)"
            },
            {
                "id": 231,
                "city_code": "15276",
                "name_city": "Floresta (Boyacá)"
            },
            {
                "id": 877,
                "city_code": "68271",
                "name_city": "Florián (Santander)"
            },
            {
                "id": 1024,
                "city_code": "76275",
                "name_city": "Florida (Valle del Cauca)"
            },
            {
                "id": 878,
                "city_code": "68276",
                "name_city": "Floridablanca (Santander)"
            },
            {
                "id": 485,
                "city_code": "25279",
                "name_city": "Fómeque (Cundinamarca)"
            },
            {
                "id": 648,
                "city_code": "44279",
                "name_city": "Fonseca (La Guajira)"
            },
            {
                "id": 1051,
                "city_code": "81300",
                "name_city": "Fortul (Arauca)"
            },
            {
                "id": 486,
                "city_code": "25281",
                "name_city": "Fosca (Cundinamarca)"
            },
            {
                "id": 758,
                "city_code": "52520",
                "name_city": "Francisco Pizarro (Nariño)"
            },
            {
                "id": 48,
                "city_code": "5282",
                "name_city": "Fredonia (Antioquia)"
            },
            {
                "id": 977,
                "city_code": "73283",
                "name_city": "Fresno (Tolima)"
            },
            {
                "id": 49,
                "city_code": "5284",
                "name_city": "Frontino (Antioquia)"
            },
            {
                "id": 697,
                "city_code": "50287",
                "name_city": "Fuente De Oro (Meta)"
            },
            {
                "id": 668,
                "city_code": "47288",
                "name_city": "Fundación (Magdalena)"
            },
            {
                "id": 737,
                "city_code": "52287",
                "name_city": "Funes (Nariño)"
            },
            {
                "id": 487,
                "city_code": "25286",
                "name_city": "Funza (Cundinamarca)"
            },
            {
                "id": 488,
                "city_code": "25288",
                "name_city": "Fúquene (Cundinamarca)"
            },
            {
                "id": 489,
                "city_code": "25290",
                "name_city": "Fusagasugá (Cundinamarca)"
            },
            {
                "id": 490,
                "city_code": "25293",
                "name_city": "Gachalá (Cundinamarca)"
            },
            {
                "id": 491,
                "city_code": "25295",
                "name_city": "Gachancipá (Cundinamarca)"
            },
            {
                "id": 232,
                "city_code": "15293",
                "name_city": "Gachantivá (Boyacá)"
            },
            {
                "id": 492,
                "city_code": "25297",
                "name_city": "Gachetá (Cundinamarca)"
            },
            {
                "id": 879,
                "city_code": "68296",
                "name_city": "Galán (Santander)"
            },
            {
                "id": 130,
                "city_code": "8296",
                "name_city": "Galapa (Atlántico)"
            },
            {
                "id": 941,
                "city_code": "70235",
                "name_city": "Galeras (Sucre)"
            },
            {
                "id": 493,
                "city_code": "25299",
                "name_city": "Gama (Cundinamarca)"
            },
            {
                "id": 415,
                "city_code": "20295",
                "name_city": "Gamarra (Cesar)"
            },
            {
                "id": 880,
                "city_code": "68298",
                "name_city": "Gámbita (Santander)"
            },
            {
                "id": 233,
                "city_code": "15296",
                "name_city": "Gámeza (Boyacá)"
            },
            {
                "id": 234,
                "city_code": "15299",
                "name_city": "Garagoa (Boyacá)"
            },
            {
                "id": 615,
                "city_code": "41298",
                "name_city": "Garzón (Huila)"
            },
            {
                "id": 826,
                "city_code": "63302",
                "name_city": "Génova (Quindío)"
            },
            {
                "id": 616,
                "city_code": "41306",
                "name_city": "Gigante (Huila)"
            },
            {
                "id": 1025,
                "city_code": "76306",
                "name_city": "Ginebra (Valle del Cauca)"
            },
            {
                "id": 50,
                "city_code": "5306",
                "name_city": "Giraldo (Antioquia)"
            },
            {
                "id": 494,
                "city_code": "25307",
                "name_city": "Girardot (Cundinamarca)"
            },
            {
                "id": 51,
                "city_code": "5308",
                "name_city": "Girardota (Antioquia)"
            },
            {
                "id": 881,
                "city_code": "68307",
                "name_city": "Girón (Santander)"
            },
            {
                "id": 52,
                "city_code": "5310",
                "name_city": "Gómez Plata (Antioquia)"
            },
            {
                "id": 416,
                "city_code": "20310",
                "name_city": "González (Cesar)"
            },
            {
                "id": 795,
                "city_code": "54313",
                "name_city": "Gramalote (Norte de Santander)"
            },
            {
                "id": 53,
                "city_code": "5313",
                "name_city": "Granada (Antioquia)"
            },
            {
                "id": 495,
                "city_code": "25312",
                "name_city": "Granada (Cundinamarca)"
            },
            {
                "id": 698,
                "city_code": "50313",
                "name_city": "Granada (Meta)"
            },
            {
                "id": 882,
                "city_code": "68318",
                "name_city": "Guaca (Santander)"
            },
            {
                "id": 235,
                "city_code": "15317",
                "name_city": "Guacamayas (Boyacá)"
            },
            {
                "id": 1026,
                "city_code": "76318",
                "name_city": "Guacarí (Valle del Cauca)"
            },
            {
                "id": 374,
                "city_code": "19300",
                "name_city": "Guachené (Cauca)"
            },
            {
                "id": 496,
                "city_code": "25317",
                "name_city": "Guachetá (Cundinamarca)"
            },
            {
                "id": 738,
                "city_code": "52317",
                "name_city": "Guachucal (Nariño)"
            },
            {
                "id": 1013,
                "city_code": "76111",
                "name_city": "Guadalajara De Buga (Valle del Cauca)"
            },
            {
                "id": 54,
                "city_code": "5315",
                "name_city": "Guadalupe (Antioquia)"
            },
            {
                "id": 617,
                "city_code": "41319",
                "name_city": "Guadalupe (Huila)"
            },
            {
                "id": 883,
                "city_code": "68320",
                "name_city": "Guadalupe (Santander)"
            },
            {
                "id": 497,
                "city_code": "25320",
                "name_city": "Guaduas (Cundinamarca)"
            },
            {
                "id": 739,
                "city_code": "52320",
                "name_city": "Guaitarilla (Nariño)"
            },
            {
                "id": 740,
                "city_code": "52323",
                "name_city": "Gualmatán (Nariño)"
            },
            {
                "id": 669,
                "city_code": "47318",
                "name_city": "Guamal (Magdalena)"
            },
            {
                "id": 699,
                "city_code": "50318",
                "name_city": "Guamal (Meta)"
            },
            {
                "id": 978,
                "city_code": "73319",
                "name_city": "Guamo (Tolima)"
            },
            {
                "id": 375,
                "city_code": "19318",
                "name_city": "Guapí (Cauca)"
            },
            {
                "id": 884,
                "city_code": "68322",
                "name_city": "Guapotá (Santander)"
            },
            {
                "id": 942,
                "city_code": "70265",
                "name_city": "Guaranda (Sucre)"
            },
            {
                "id": 55,
                "city_code": "5318",
                "name_city": "Guarne (Antioquia)"
            },
            {
                "id": 498,
                "city_code": "25322",
                "name_city": "Guasca (Cundinamarca)"
            },
            {
                "id": 56,
                "city_code": "5321",
                "name_city": "Guatapé (Antioquia)"
            },
            {
                "id": 499,
                "city_code": "25324",
                "name_city": "Guataquí (Cundinamarca)"
            },
            {
                "id": 500,
                "city_code": "25326",
                "name_city": "Guatavita (Cundinamarca)"
            },
            {
                "id": 236,
                "city_code": "15322",
                "name_city": "Guateque (Boyacá)"
            },
            {
                "id": 837,
                "city_code": "66318",
                "name_city": "Guática (Risaralda)"
            },
            {
                "id": 885,
                "city_code": "68324",
                "name_city": "Guavatá (Santander)"
            },
            {
                "id": 501,
                "city_code": "25328",
                "name_city": "Guayabal De Síquima (Cundinamarca)"
            },
            {
                "id": 502,
                "city_code": "25335",
                "name_city": "Guayabetal (Cundinamarca)"
            },
            {
                "id": 237,
                "city_code": "15325",
                "name_city": "Guayatá (Boyacá)"
            },
            {
                "id": 886,
                "city_code": "68327",
                "name_city": "Güepsa (Santander)"
            },
            {
                "id": 238,
                "city_code": "15332",
                "name_city": "Güicán De La Sierra (Boyacá)"
            },
            {
                "id": 503,
                "city_code": "25339",
                "name_city": "Gutiérrez (Cundinamarca)"
            },
            {
                "id": 796,
                "city_code": "54344",
                "name_city": "Hacarí (Norte de Santander)"
            },
            {
                "id": 165,
                "city_code": "13300",
                "name_city": "Hatillo De Loba (Bolívar)"
            },
            {
                "id": 887,
                "city_code": "68344",
                "name_city": "Hato (Santander)"
            },
            {
                "id": 1058,
                "city_code": "85125",
                "name_city": "Hato Corozal (Casanare)"
            },
            {
                "id": 649,
                "city_code": "44378",
                "name_city": "Hatonuevo (La Guajira)"
            },
            {
                "id": 57,
                "city_code": "5347",
                "name_city": "Heliconia (Antioquia)"
            },
            {
                "id": 797,
                "city_code": "54347",
                "name_city": "Herrán (Norte de Santander)"
            },
            {
                "id": 979,
                "city_code": "73347",
                "name_city": "Herveo (Tolima)"
            },
            {
                "id": 58,
                "city_code": "5353",
                "name_city": "Hispania (Antioquia)"
            },
            {
                "id": 618,
                "city_code": "41349",
                "name_city": "Hobo (Huila)"
            },
            {
                "id": 980,
                "city_code": "73349",
                "name_city": "Honda (Tolima)"
            },
            {
                "id": 959,
                "city_code": "73001",
                "name_city": "Ibagué (Tolima)"
            },
            {
                "id": 981,
                "city_code": "73352",
                "name_city": "Icononzo (Tolima)"
            },
            {
                "id": 741,
                "city_code": "52352",
                "name_city": "Iles (Nariño)"
            },
            {
                "id": 742,
                "city_code": "52354",
                "name_city": "Imués (Nariño)"
            },
            {
                "id": 1100,
                "city_code": "94001",
                "name_city": "Inírida (Guainía)"
            },
            {
                "id": 376,
                "city_code": "19355",
                "name_city": "Inzá (Cauca)"
            },
            {
                "id": 743,
                "city_code": "52356",
                "name_city": "Ipiales (Nariño)"
            },
            {
                "id": 619,
                "city_code": "41357",
                "name_city": "Íquira (Huila)"
            },
            {
                "id": 620,
                "city_code": "41359",
                "name_city": "Isnos (Huila)"
            },
            {
                "id": 589,
                "city_code": "27361",
                "name_city": "Istmina (Chocó)"
            },
            {
                "id": 59,
                "city_code": "5360",
                "name_city": "Itagüí (Antioquia)"
            },
            {
                "id": 60,
                "city_code": "5361",
                "name_city": "Ituango (Antioquia)"
            },
            {
                "id": 239,
                "city_code": "15362",
                "name_city": "Iza (Boyacá)"
            },
            {
                "id": 377,
                "city_code": "19364",
                "name_city": "Jambaló (Cauca)"
            },
            {
                "id": 1027,
                "city_code": "76364",
                "name_city": "Jamundí (Valle del Cauca)"
            },
            {
                "id": 61,
                "city_code": "5364",
                "name_city": "Jardín (Antioquia)"
            },
            {
                "id": 240,
                "city_code": "15367",
                "name_city": "Jenesano (Boyacá)"
            },
            {
                "id": 62,
                "city_code": "5368",
                "name_city": "Jericó (Antioquia)"
            },
            {
                "id": 241,
                "city_code": "15368",
                "name_city": "Jericó (Boyacá)"
            },
            {
                "id": 504,
                "city_code": "25368",
                "name_city": "Jerusalén (Cundinamarca)"
            },
            {
                "id": 888,
                "city_code": "68368",
                "name_city": "Jesús María (Santander)"
            },
            {
                "id": 889,
                "city_code": "68370",
                "name_city": "Jordán (Santander)"
            },
            {
                "id": 131,
                "city_code": "8372",
                "name_city": "Juan De Acosta (Atlántico)"
            },
            {
                "id": 505,
                "city_code": "25372",
                "name_city": "Junín (Cundinamarca)"
            },
            {
                "id": 590,
                "city_code": "27372",
                "name_city": "Juradó (Chocó)"
            },
            {
                "id": 438,
                "city_code": "23350",
                "name_city": "La Apartada (Córdoba)"
            },
            {
                "id": 621,
                "city_code": "41378",
                "name_city": "La Argentina (Huila)"
            },
            {
                "id": 890,
                "city_code": "68377",
                "name_city": "La Belleza (Santander)"
            },
            {
                "id": 506,
                "city_code": "25377",
                "name_city": "La Calera (Cundinamarca)"
            },
            {
                "id": 243,
                "city_code": "15380",
                "name_city": "La Capilla (Boyacá)"
            },
            {
                "id": 63,
                "city_code": "5376",
                "name_city": "La Ceja (Antioquia)"
            },
            {
                "id": 838,
                "city_code": "66383",
                "name_city": "La Celia (Risaralda)"
            },
            {
                "id": 1091,
                "city_code": "91405",
                "name_city": "La Chorrera (Amazonas)"
            },
            {
                "id": 744,
                "city_code": "52378",
                "name_city": "La Cruz (Nariño)"
            },
            {
                "id": 1028,
                "city_code": "76377",
                "name_city": "La Cumbre (Valle del Cauca)"
            },
            {
                "id": 326,
                "city_code": "17380",
                "name_city": "La Dorada (Caldas)"
            },
            {
                "id": 799,
                "city_code": "54385",
                "name_city": "La Esperanza (Norte de Santander)"
            },
            {
                "id": 64,
                "city_code": "5380",
                "name_city": "La Estrella (Antioquia)"
            },
            {
                "id": 745,
                "city_code": "52381",
                "name_city": "La Florida (Nariño)"
            },
            {
                "id": 417,
                "city_code": "20383",
                "name_city": "La Gloria (Cesar)"
            },
            {
                "id": 1105,
                "city_code": "94885",
                "name_city": "La Guadalupe (Guainía)"
            },
            {
                "id": 418,
                "city_code": "20400",
                "name_city": "La Jagua De Ibirico (Cesar)"
            },
            {
                "id": 650,
                "city_code": "44420",
                "name_city": "La Jagua Del Pilar (La Guajira)"
            },
            {
                "id": 746,
                "city_code": "52385",
                "name_city": "La Llanada (Nariño)"
            },
            {
                "id": 702,
                "city_code": "50350",
                "name_city": "La Macarena (Meta)"
            },
            {
                "id": 327,
                "city_code": "17388",
                "name_city": "La Merced (Caldas)"
            },
            {
                "id": 507,
                "city_code": "25386",
                "name_city": "La Mesa (Cundinamarca)"
            },
            {
                "id": 353,
                "city_code": "18410",
                "name_city": "La Montañita (Caquetá)"
            },
            {
                "id": 508,
                "city_code": "25394",
                "name_city": "La Palma (Cundinamarca)"
            },
            {
                "id": 424,
                "city_code": "20621",
                "name_city": "La Paz (Cesar)"
            },
            {
                "id": 892,
                "city_code": "68397",
                "name_city": "La Paz (Santander)"
            },
            {
                "id": 1092,
                "city_code": "91407",
                "name_city": "La Pedrera (Amazonas)"
            },
            {
                "id": 509,
                "city_code": "25398",
                "name_city": "La Peña (Cundinamarca)"
            },
            {
                "id": 65,
                "city_code": "5390",
                "name_city": "La Pintada (Antioquia)"
            },
            {
                "id": 622,
                "city_code": "41396",
                "name_city": "La Plata (Huila)"
            },
            {
                "id": 800,
                "city_code": "54398",
                "name_city": "La Playa (Norte de Santander)"
            },
            {
                "id": 1120,
                "city_code": "99524",
                "name_city": "La Primavera (Vichada)"
            },
            {
                "id": 1059,
                "city_code": "85136",
                "name_city": "La Salina (Casanare)"
            },
            {
                "id": 378,
                "city_code": "19392",
                "name_city": "La Sierra (Cauca)"
            },
            {
                "id": 827,
                "city_code": "63401",
                "name_city": "La Tebaida (Quindío)"
            },
            {
                "id": 747,
                "city_code": "52390",
                "name_city": "La Tola (Nariño)"
            },
            {
                "id": 66,
                "city_code": "5400",
                "name_city": "La Unión (Antioquia)"
            },
            {
                "id": 748,
                "city_code": "52399",
                "name_city": "La Unión (Nariño)"
            },
            {
                "id": 943,
                "city_code": "70400",
                "name_city": "La Unión (Sucre)"
            },
            {
                "id": 1029,
                "city_code": "76400",
                "name_city": "La Unión (Valle del Cauca)"
            },
            {
                "id": 245,
                "city_code": "15403",
                "name_city": "La Uvita (Boyacá)"
            },
            {
                "id": 379,
                "city_code": "19397",
                "name_city": "La Vega (Cauca)"
            },
            {
                "id": 510,
                "city_code": "25402",
                "name_city": "La Vega (Cundinamarca)"
            },
            {
                "id": 1093,
                "city_code": "91430",
                "name_city": "La Victoria (Amazonas)"
            },
            {
                "id": 244,
                "city_code": "15401",
                "name_city": "La Victoria (Boyacá)"
            },
            {
                "id": 1030,
                "city_code": "76403",
                "name_city": "La Victoria (Valle del Cauca)"
            },
            {
                "id": 839,
                "city_code": "66400",
                "name_city": "La Virginia (Risaralda)"
            },
            {
                "id": 798,
                "city_code": "54377",
                "name_city": "Labateca (Norte de Santander)"
            },
            {
                "id": 242,
                "city_code": "15377",
                "name_city": "Labranzagrande (Boyacá)"
            },
            {
                "id": 891,
                "city_code": "68385",
                "name_city": "Landázuri (Santander)"
            },
            {
                "id": 893,
                "city_code": "68406",
                "name_city": "Lebrija (Santander)"
            },
            {
                "id": 749,
                "city_code": "52405",
                "name_city": "Leiva (Nariño)"
            },
            {
                "id": 704,
                "city_code": "50400",
                "name_city": "Lejanías (Meta)"
            },
            {
                "id": 511,
                "city_code": "25407",
                "name_city": "Lenguazaque (Cundinamarca)"
            },
            {
                "id": 982,
                "city_code": "73408",
                "name_city": "Lérida (Tolima)"
            },
            {
                "id": 1089,
                "city_code": "91001",
                "name_city": "Leticia (Amazonas)"
            },
            {
                "id": 983,
                "city_code": "73411",
                "name_city": "Líbano (Tolima)"
            },
            {
                "id": 67,
                "city_code": "5411",
                "name_city": "Liborina (Antioquia)"
            },
            {
                "id": 750,
                "city_code": "52411",
                "name_city": "Linares (Nariño)"
            },
            {
                "id": 591,
                "city_code": "27413",
                "name_city": "Lloró (Chocó)"
            },
            {
                "id": 380,
                "city_code": "19418",
                "name_city": "López De Micay (Cauca)"
            },
            {
                "id": 439,
                "city_code": "23417",
                "name_city": "Lorica (Córdoba)"
            },
            {
                "id": 751,
                "city_code": "52418",
                "name_city": "Los Andes (Nariño)"
            },
            {
                "id": 440,
                "city_code": "23419",
                "name_city": "Los Córdobas (Córdoba)"
            },
            {
                "id": 944,
                "city_code": "70418",
                "name_city": "Los Palmitos (Sucre)"
            },
            {
                "id": 801,
                "city_code": "54405",
                "name_city": "Los Patios (Norte de Santander)"
            },
            {
                "id": 894,
                "city_code": "68418",
                "name_city": "Los Santos (Santander)"
            },
            {
                "id": 802,
                "city_code": "54418",
                "name_city": "Lourdes (Norte de Santander)"
            },
            {
                "id": 132,
                "city_code": "8421",
                "name_city": "Luruaco (Atlántico)"
            },
            {
                "id": 247,
                "city_code": "15425",
                "name_city": "Macanal (Boyacá)"
            },
            {
                "id": 895,
                "city_code": "68425",
                "name_city": "Macaravita (Santander)"
            },
            {
                "id": 68,
                "city_code": "5425",
                "name_city": "Maceo (Antioquia)"
            },
            {
                "id": 512,
                "city_code": "25426",
                "name_city": "Machetá (Cundinamarca)"
            },
            {
                "id": 513,
                "city_code": "25430",
                "name_city": "Madrid (Cundinamarca)"
            },
            {
                "id": 166,
                "city_code": "13430",
                "name_city": "Magangué (Bolívar)"
            },
            {
                "id": 752,
                "city_code": "52427",
                "name_city": "Magüí (Nariño)"
            },
            {
                "id": 167,
                "city_code": "13433",
                "name_city": "Mahates (Bolívar)"
            },
            {
                "id": 651,
                "city_code": "44430",
                "name_city": "Maicao (La Guajira)"
            },
            {
                "id": 945,
                "city_code": "70429",
                "name_city": "Majagual (Sucre)"
            },
            {
                "id": 896,
                "city_code": "68432",
                "name_city": "Málaga (Santander)"
            },
            {
                "id": 133,
                "city_code": "8433",
                "name_city": "Malambo (Atlántico)"
            },
            {
                "id": 753,
                "city_code": "52435",
                "name_city": "Mallama (Nariño)"
            },
            {
                "id": 134,
                "city_code": "8436",
                "name_city": "Manatí (Atlántico)"
            },
            {
                "id": 652,
                "city_code": "44560",
                "name_city": "Manaure (La Guajira)"
            },
            {
                "id": 419,
                "city_code": "20443",
                "name_city": "Manaure Balcón Del Cesar (Cesar)"
            },
            {
                "id": 1060,
                "city_code": "85139",
                "name_city": "Maní (Casanare)"
            },
            {
                "id": 319,
                "city_code": "17001",
                "name_city": "Manizales (Caldas)"
            },
            {
                "id": 514,
                "city_code": "25436",
                "name_city": "Manta (Cundinamarca)"
            },
            {
                "id": 328,
                "city_code": "17433",
                "name_city": "Manzanares (Caldas)"
            },
            {
                "id": 700,
                "city_code": "50325",
                "name_city": "Mapiripán (Meta)"
            },
            {
                "id": 1102,
                "city_code": "94663",
                "name_city": "Mapiripana (Guainía)"
            },
            {
                "id": 168,
                "city_code": "13440",
                "name_city": "Margarita (Bolívar)"
            },
            {
                "id": 169,
                "city_code": "13442",
                "name_city": "María La Baja (Bolívar)"
            },
            {
                "id": 69,
                "city_code": "5440",
                "name_city": "Marinilla (Antioquia)"
            },
            {
                "id": 248,
                "city_code": "15442",
                "name_city": "Maripí (Boyacá)"
            },
            {
                "id": 329,
                "city_code": "17442",
                "name_city": "Marmato (Caldas)"
            },
            {
                "id": 330,
                "city_code": "17444",
                "name_city": "Marquetalia (Caldas)"
            },
            {
                "id": 840,
                "city_code": "66440",
                "name_city": "Marsella (Risaralda)"
            },
            {
                "id": 331,
                "city_code": "17446",
                "name_city": "Marulanda (Caldas)"
            },
            {
                "id": 897,
                "city_code": "68444",
                "name_city": "Matanza (Santander)"
            },
            {
                "id": 1,
                "city_code": "5001",
                "name_city": "Medellín (Antioquia)"
            },
            {
                "id": 515,
                "city_code": "25438",
                "name_city": "Medina (Cundinamarca)"
            },
            {
                "id": 592,
                "city_code": "27425",
                "name_city": "Medio Atrato (Chocó)"
            },
            {
                "id": 593,
                "city_code": "27430",
                "name_city": "Medio Baudó (Chocó)"
            },
            {
                "id": 594,
                "city_code": "27450",
                "name_city": "Medio San Juan (Chocó)"
            },
            {
                "id": 985,
                "city_code": "73449",
                "name_city": "Melgar (Tolima)"
            },
            {
                "id": 381,
                "city_code": "19450",
                "name_city": "Mercaderes (Cauca)"
            },
            {
                "id": 701,
                "city_code": "50330",
                "name_city": "Mesetas (Meta)"
            },
            {
                "id": 354,
                "city_code": "18460",
                "name_city": "Milán (Caquetá)"
            },
            {
                "id": 249,
                "city_code": "15455",
                "name_city": "Miraflores (Boyacá)"
            },
            {
                "id": 1112,
                "city_code": "95200",
                "name_city": "Miraflores (Guaviare)"
            },
            {
                "id": 382,
                "city_code": "19455",
                "name_city": "Miranda (Cauca)"
            },
            {
                "id": 1094,
                "city_code": "91460",
                "name_city": "Mirití - Paraná (Amazonas)"
            },
            {
                "id": 841,
                "city_code": "66456",
                "name_city": "Mistrató (Risaralda)"
            },
            {
                "id": 1113,
                "city_code": "97001",
                "name_city": "Mitú (Vaupés)"
            },
            {
                "id": 1074,
                "city_code": "86001",
                "name_city": "Mocoa (Putumayo)"
            },
            {
                "id": 898,
                "city_code": "68464",
                "name_city": "Mogotes (Santander)"
            },
            {
                "id": 899,
                "city_code": "68468",
                "name_city": "Molagavita (Santander)"
            },
            {
                "id": 441,
                "city_code": "23464",
                "name_city": "Momil (Córdoba)"
            },
            {
                "id": 171,
                "city_code": "13468",
                "name_city": "Mompós (Bolívar)"
            },
            {
                "id": 250,
                "city_code": "15464",
                "name_city": "Mongua (Boyacá)"
            },
            {
                "id": 251,
                "city_code": "15466",
                "name_city": "Monguí (Boyacá)"
            },
            {
                "id": 252,
                "city_code": "15469",
                "name_city": "Moniquirá (Boyacá)"
            },
            {
                "id": 443,
                "city_code": "23500",
                "name_city": "Moñitos (Córdoba)"
            },
            {
                "id": 70,
                "city_code": "5467",
                "name_city": "Montebello (Antioquia)"
            },
            {
                "id": 170,
                "city_code": "13458",
                "name_city": "Montecristo (Bolívar)"
            },
            {
                "id": 442,
                "city_code": "23466",
                "name_city": "Montelíbano (Córdoba)"
            },
            {
                "id": 828,
                "city_code": "63470",
                "name_city": "Montenegro (Quindío)"
            },
            {
                "id": 429,
                "city_code": "23001",
                "name_city": "Montería (Córdoba)"
            },
            {
                "id": 1061,
                "city_code": "85162",
                "name_city": "Monterrey (Casanare)"
            },
            {
                "id": 172,
                "city_code": "13473",
                "name_city": "Morales (Bolívar)"
            },
            {
                "id": 383,
                "city_code": "19473",
                "name_city": "Morales (Cauca)"
            },
            {
                "id": 355,
                "city_code": "18479",
                "name_city": "Morelia (Caquetá)"
            },
            {
                "id": 1108,
                "city_code": "94888",
                "name_city": "Morichal (Guainía)"
            },
            {
                "id": 946,
                "city_code": "70473",
                "name_city": "Morroa (Sucre)"
            },
            {
                "id": 516,
                "city_code": "25473",
                "name_city": "Mosquera (Cundinamarca)"
            },
            {
                "id": 754,
                "city_code": "52473",
                "name_city": "Mosquera (Nariño)"
            },
            {
                "id": 253,
                "city_code": "15476",
                "name_city": "Motavita (Boyacá)"
            },
            {
                "id": 986,
                "city_code": "73461",
                "name_city": "Murillo (Tolima)"
            },
            {
                "id": 71,
                "city_code": "5475",
                "name_city": "Murindó (Antioquia)"
            },
            {
                "id": 72,
                "city_code": "5480",
                "name_city": "Mutatá (Antioquia)"
            },
            {
                "id": 803,
                "city_code": "54480",
                "name_city": "Mutiscua (Norte de Santander)"
            },
            {
                "id": 254,
                "city_code": "15480",
                "name_city": "Muzo (Boyacá)"
            },
            {
                "id": 73,
                "city_code": "5483",
                "name_city": "Nariño (Antioquia)"
            },
            {
                "id": 517,
                "city_code": "25483",
                "name_city": "Nariño (Cundinamarca)"
            },
            {
                "id": 755,
                "city_code": "52480",
                "name_city": "Nariño (Nariño)"
            },
            {
                "id": 623,
                "city_code": "41483",
                "name_city": "Nátaga (Huila)"
            },
            {
                "id": 987,
                "city_code": "73483",
                "name_city": "Natagaima (Tolima)"
            },
            {
                "id": 75,
                "city_code": "5495",
                "name_city": "Nechí (Antioquia)"
            },
            {
                "id": 74,
                "city_code": "5490",
                "name_city": "Necoclí (Antioquia)"
            },
            {
                "id": 332,
                "city_code": "17486",
                "name_city": "Neira (Caldas)"
            },
            {
                "id": 605,
                "city_code": "41001",
                "name_city": "Neiva (Huila)"
            },
            {
                "id": 518,
                "city_code": "25486",
                "name_city": "Nemocón (Cundinamarca)"
            },
            {
                "id": 519,
                "city_code": "25488",
                "name_city": "Nilo (Cundinamarca)"
            },
            {
                "id": 520,
                "city_code": "25489",
                "name_city": "Nimaima (Cundinamarca)"
            },
            {
                "id": 255,
                "city_code": "15491",
                "name_city": "Nobsa (Boyacá)"
            },
            {
                "id": 521,
                "city_code": "25491",
                "name_city": "Nocaima (Cundinamarca)"
            },
            {
                "id": 333,
                "city_code": "17495",
                "name_city": "Norcasia (Caldas)"
            },
            {
                "id": 173,
                "city_code": "13490",
                "name_city": "Norosí (Bolívar)"
            },
            {
                "id": 595,
                "city_code": "27491",
                "name_city": "Nóvita (Chocó)"
            },
            {
                "id": 670,
                "city_code": "47460",
                "name_city": "Nueva Granada (Magdalena)"
            },
            {
                "id": 256,
                "city_code": "15494",
                "name_city": "Nuevo Colón (Boyacá)"
            },
            {
                "id": 1062,
                "city_code": "85225",
                "name_city": "Nunchía (Casanare)"
            },
            {
                "id": 596,
                "city_code": "27495",
                "name_city": "Nuquí (Chocó)"
            },
            {
                "id": 1031,
                "city_code": "76497",
                "name_city": "Obando (Valle del Cauca)"
            },
            {
                "id": 900,
                "city_code": "68498",
                "name_city": "Ocamonte (Santander)"
            },
            {
                "id": 804,
                "city_code": "54498",
                "name_city": "Ocaña (Norte de Santander)"
            },
            {
                "id": 901,
                "city_code": "68500",
                "name_city": "Oiba (Santander)"
            },
            {
                "id": 257,
                "city_code": "15500",
                "name_city": "Oicatá (Boyacá)"
            },
            {
                "id": 76,
                "city_code": "5501",
                "name_city": "Olaya (Antioquia)"
            },
            {
                "id": 756,
                "city_code": "52490",
                "name_city": "Olaya Herrera (Nariño)"
            },
            {
                "id": 902,
                "city_code": "68502",
                "name_city": "Onzaga (Santander)"
            },
            {
                "id": 624,
                "city_code": "41503",
                "name_city": "Oporapa (Huila)"
            },
            {
                "id": 1076,
                "city_code": "86320",
                "name_city": "Orito (Putumayo)"
            },
            {
                "id": 1063,
                "city_code": "85230",
                "name_city": "Orocué (Casanare)"
            },
            {
                "id": 988,
                "city_code": "73504",
                "name_city": "Ortega (Tolima)"
            },
            {
                "id": 757,
                "city_code": "52506",
                "name_city": "Ospina (Nariño)"
            },
            {
                "id": 258,
                "city_code": "15507",
                "name_city": "Otanche (Boyacá)"
            },
            {
                "id": 947,
                "city_code": "70508",
                "name_city": "Ovejas (Sucre)"
            },
            {
                "id": 259,
                "city_code": "15511",
                "name_city": "Pachavita (Boyacá)"
            },
            {
                "id": 523,
                "city_code": "25513",
                "name_city": "Pacho (Cundinamarca)"
            },
            {
                "id": 1115,
                "city_code": "97511",
                "name_city": "Pacoa (Vaupés)"
            },
            {
                "id": 334,
                "city_code": "17513",
                "name_city": "Pácora (Caldas)"
            },
            {
                "id": 384,
                "city_code": "19513",
                "name_city": "Padilla (Cauca)"
            },
            {
                "id": 260,
                "city_code": "15514",
                "name_city": "Páez (Boyacá)"
            },
            {
                "id": 385,
                "city_code": "19517",
                "name_city": "Páez (Cauca)"
            },
            {
                "id": 625,
                "city_code": "41518",
                "name_city": "Paicol (Huila)"
            },
            {
                "id": 420,
                "city_code": "20517",
                "name_city": "Pailitas (Cesar)"
            },
            {
                "id": 524,
                "city_code": "25518",
                "name_city": "Paime (Cundinamarca)"
            },
            {
                "id": 261,
                "city_code": "15516",
                "name_city": "Paipa (Boyacá)"
            },
            {
                "id": 262,
                "city_code": "15518",
                "name_city": "Pajarito (Boyacá)"
            },
            {
                "id": 626,
                "city_code": "41524",
                "name_city": "Palermo (Huila)"
            },
            {
                "id": 335,
                "city_code": "17524",
                "name_city": "Palestina (Caldas)"
            },
            {
                "id": 627,
                "city_code": "41530",
                "name_city": "Palestina (Huila)"
            },
            {
                "id": 903,
                "city_code": "68522",
                "name_city": "Palmar (Santander)"
            },
            {
                "id": 135,
                "city_code": "8520",
                "name_city": "Palmar De Varela (Atlántico)"
            },
            {
                "id": 904,
                "city_code": "68524",
                "name_city": "Palmas Del Socorro (Santander)"
            },
            {
                "id": 1032,
                "city_code": "76520",
                "name_city": "Palmira (Valle del Cauca)"
            },
            {
                "id": 948,
                "city_code": "70523",
                "name_city": "Palmito (Sucre)"
            },
            {
                "id": 989,
                "city_code": "73520",
                "name_city": "Palocabildo (Tolima)"
            },
            {
                "id": 805,
                "city_code": "54518",
                "name_city": "Pamplona (Norte de Santander)"
            },
            {
                "id": 806,
                "city_code": "54520",
                "name_city": "Pamplonita (Norte de Santander)"
            },
            {
                "id": 1107,
                "city_code": "94887",
                "name_city": "Pana Pana (Guainía)"
            },
            {
                "id": 525,
                "city_code": "25524",
                "name_city": "Pandi (Cundinamarca)"
            },
            {
                "id": 263,
                "city_code": "15522",
                "name_city": "Panqueba (Boyacá)"
            },
            {
                "id": 1117,
                "city_code": "97777",
                "name_city": "Papunahua (Vaupés)"
            },
            {
                "id": 905,
                "city_code": "68533",
                "name_city": "Páramo (Santander)"
            },
            {
                "id": 526,
                "city_code": "25530",
                "name_city": "Paratebueno (Cundinamarca)"
            },
            {
                "id": 527,
                "city_code": "25535",
                "name_city": "Pasca (Cundinamarca)"
            },
            {
                "id": 716,
                "city_code": "52001",
                "name_city": "Pasto (Nariño)"
            },
            {
                "id": 386,
                "city_code": "19532",
                "name_city": "Patía (Cauca)"
            },
            {
                "id": 264,
                "city_code": "15531",
                "name_city": "Pauna (Boyacá)"
            },
            {
                "id": 265,
                "city_code": "15533",
                "name_city": "Paya (Boyacá)"
            },
            {
                "id": 1064,
                "city_code": "85250",
                "name_city": "Paz De Ariporo (Casanare)"
            },
            {
                "id": 266,
                "city_code": "15537",
                "name_city": "Paz De Río (Boyacá)"
            },
            {
                "id": 671,
                "city_code": "47541",
                "name_city": "Pedraza (Magdalena)"
            },
            {
                "id": 421,
                "city_code": "20550",
                "name_city": "Pelaya (Cesar)"
            },
            {
                "id": 77,
                "city_code": "5541",
                "name_city": "Peñol (Antioquia)"
            },
            {
                "id": 336,
                "city_code": "17541",
                "name_city": "Pensilvania (Caldas)"
            },
            {
                "id": 78,
                "city_code": "5543",
                "name_city": "Peque (Antioquia)"
            },
            {
                "id": 832,
                "city_code": "66001",
                "name_city": "Pereira (Risaralda)"
            },
            {
                "id": 267,
                "city_code": "15542",
                "name_city": "Pesca (Boyacá)"
            },
            {
                "id": 387,
                "city_code": "19533",
                "name_city": "Piamonte (Cauca)"
            },
            {
                "id": 906,
                "city_code": "68547",
                "name_city": "Piedecuesta (Santander)"
            },
            {
                "id": 990,
                "city_code": "73547",
                "name_city": "Piedras (Tolima)"
            },
            {
                "id": 388,
                "city_code": "19548",
                "name_city": "Piendamó - Tunía (Cauca)"
            },
            {
                "id": 829,
                "city_code": "63548",
                "name_city": "Pijao (Quindío)"
            },
            {
                "id": 672,
                "city_code": "47545",
                "name_city": "Pijiño Del Carmen (Magdalena)"
            },
            {
                "id": 907,
                "city_code": "68549",
                "name_city": "Pinchote (Santander)"
            },
            {
                "id": 174,
                "city_code": "13549",
                "name_city": "Pinillos (Bolívar)"
            },
            {
                "id": 136,
                "city_code": "8549",
                "name_city": "Piojó (Atlántico)"
            },
            {
                "id": 268,
                "city_code": "15550",
                "name_city": "Pisba (Boyacá)"
            },
            {
                "id": 628,
                "city_code": "41548",
                "name_city": "Pital (Huila)"
            },
            {
                "id": 629,
                "city_code": "41551",
                "name_city": "Pitalito (Huila)"
            },
            {
                "id": 673,
                "city_code": "47551",
                "name_city": "Pivijay (Magdalena)"
            },
            {
                "id": 991,
                "city_code": "73555",
                "name_city": "Planadas (Tolima)"
            },
            {
                "id": 444,
                "city_code": "23555",
                "name_city": "Planeta Rica (Córdoba)"
            },
            {
                "id": 674,
                "city_code": "47555",
                "name_city": "Plato (Magdalena)"
            },
            {
                "id": 759,
                "city_code": "52540",
                "name_city": "Policarpa (Nariño)"
            },
            {
                "id": 137,
                "city_code": "8558",
                "name_city": "Polonuevo (Atlántico)"
            },
            {
                "id": 138,
                "city_code": "8560",
                "name_city": "Ponedera (Atlántico)"
            },
            {
                "id": 362,
                "city_code": "19001",
                "name_city": "Popayán (Cauca)"
            },
            {
                "id": 1065,
                "city_code": "85263",
                "name_city": "Pore (Casanare)"
            },
            {
                "id": 760,
                "city_code": "52560",
                "name_city": "Potosí (Nariño)"
            },
            {
                "id": 1033,
                "city_code": "76563",
                "name_city": "Pradera (Valle del Cauca)"
            },
            {
                "id": 992,
                "city_code": "73563",
                "name_city": "Prado (Tolima)"
            },
            {
                "id": 761,
                "city_code": "52565",
                "name_city": "Providencia (Nariño)"
            },
            {
                "id": 1088,
                "city_code": "88564",
                "name_city": "Providencia (San Andrés y Providencia)"
            },
            {
                "id": 422,
                "city_code": "20570",
                "name_city": "Pueblo Bello (Cesar)"
            },
            {
                "id": 445,
                "city_code": "23570",
                "name_city": "Pueblo Nuevo (Córdoba)"
            },
            {
                "id": 842,
                "city_code": "66572",
                "name_city": "Pueblo Rico (Risaralda)"
            },
            {
                "id": 79,
                "city_code": "5576",
                "name_city": "Pueblorrico (Antioquia)"
            },
            {
                "id": 675,
                "city_code": "47570",
                "name_city": "Puebloviejo (Magdalena)"
            },
            {
                "id": 908,
                "city_code": "68572",
                "name_city": "Puente Nacional (Santander)"
            },
            {
                "id": 762,
                "city_code": "52573",
                "name_city": "Puerres (Nariño)"
            },
            {
                "id": 1095,
                "city_code": "91530",
                "name_city": "Puerto Alegría (Amazonas)"
            },
            {
                "id": 1096,
                "city_code": "91536",
                "name_city": "Puerto Arica (Amazonas)"
            },
            {
                "id": 1077,
                "city_code": "86568",
                "name_city": "Puerto Asís (Putumayo)"
            },
            {
                "id": 80,
                "city_code": "5579",
                "name_city": "Puerto Berrío (Antioquia)"
            },
            {
                "id": 269,
                "city_code": "15572",
                "name_city": "Puerto Boyacá (Boyacá)"
            },
            {
                "id": 1078,
                "city_code": "86569",
                "name_city": "Puerto Caicedo (Putumayo)"
            },
            {
                "id": 1119,
                "city_code": "99001",
                "name_city": "Puerto Carreño (Vichada)"
            },
            {
                "id": 139,
                "city_code": "8573",
                "name_city": "Puerto Colombia (Atlántico)"
            },
            {
                "id": 1104,
                "city_code": "94884",
                "name_city": "Puerto Colombia (Guainía)"
            },
            {
                "id": 705,
                "city_code": "50450",
                "name_city": "Puerto Concordia (Meta)"
            },
            {
                "id": 446,
                "city_code": "23574",
                "name_city": "Puerto Escondido (Córdoba)"
            },
            {
                "id": 706,
                "city_code": "50568",
                "name_city": "Puerto Gaitán (Meta)"
            },
            {
                "id": 1079,
                "city_code": "86571",
                "name_city": "Puerto Guzmán (Putumayo)"
            },
            {
                "id": 1080,
                "city_code": "86573",
                "name_city": "Puerto Leguízamo (Putumayo)"
            },
            {
                "id": 447,
                "city_code": "23580",
                "name_city": "Puerto Libertador (Córdoba)"
            },
            {
                "id": 708,
                "city_code": "50577",
                "name_city": "Puerto Lleras (Meta)"
            },
            {
                "id": 707,
                "city_code": "50573",
                "name_city": "Puerto López (Meta)"
            },
            {
                "id": 81,
                "city_code": "5585",
                "name_city": "Puerto Nare (Antioquia)"
            },
            {
                "id": 1097,
                "city_code": "91540",
                "name_city": "Puerto Nariño (Amazonas)"
            },
            {
                "id": 909,
                "city_code": "68573",
                "name_city": "Puerto Parra (Santander)"
            },
            {
                "id": 356,
                "city_code": "18592",
                "name_city": "Puerto Rico (Caquetá)"
            },
            {
                "id": 709,
                "city_code": "50590",
                "name_city": "Puerto Rico (Meta)"
            },
            {
                "id": 1052,
                "city_code": "81591",
                "name_city": "Puerto Rondón (Arauca)"
            },
            {
                "id": 528,
                "city_code": "25572",
                "name_city": "Puerto Salgar (Cundinamarca)"
            },
            {
                "id": 1098,
                "city_code": "91669",
                "name_city": "Puerto Santander (Amazonas)"
            },
            {
                "id": 807,
                "city_code": "54553",
                "name_city": "Puerto Santander (Norte de Santander)"
            },
            {
                "id": 389,
                "city_code": "19573",
                "name_city": "Puerto Tejada (Cauca)"
            },
            {
                "id": 82,
                "city_code": "5591",
                "name_city": "Puerto Triunfo (Antioquia)"
            },
            {
                "id": 910,
                "city_code": "68575",
                "name_city": "Puerto Wilches (Santander)"
            },
            {
                "id": 529,
                "city_code": "25580",
                "name_city": "Pulí (Cundinamarca)"
            },
            {
                "id": 763,
                "city_code": "52585",
                "name_city": "Pupiales (Nariño)"
            },
            {
                "id": 390,
                "city_code": "19585",
                "name_city": "Puracé (Cauca)"
            },
            {
                "id": 993,
                "city_code": "73585",
                "name_city": "Purificación (Tolima)"
            },
            {
                "id": 448,
                "city_code": "23586",
                "name_city": "Purísima De La Concepción (Córdoba)"
            },
            {
                "id": 530,
                "city_code": "25592",
                "name_city": "Quebradanegra (Cundinamarca)"
            },
            {
                "id": 531,
                "city_code": "25594",
                "name_city": "Quetame (Cundinamarca)"
            },
            {
                "id": 575,
                "city_code": "27001",
                "name_city": "Quibdó (Chocó)"
            },
            {
                "id": 830,
                "city_code": "63594",
                "name_city": "Quimbaya (Quindío)"
            },
            {
                "id": 843,
                "city_code": "66594",
                "name_city": "Quinchía (Risaralda)"
            },
            {
                "id": 270,
                "city_code": "15580",
                "name_city": "Quípama (Boyacá)"
            },
            {
                "id": 532,
                "city_code": "25596",
                "name_city": "Quipile (Cundinamarca)"
            },
            {
                "id": 808,
                "city_code": "54599",
                "name_city": "Ragonvalia (Norte de Santander)"
            },
            {
                "id": 271,
                "city_code": "15599",
                "name_city": "Ramiriquí (Boyacá)"
            },
            {
                "id": 272,
                "city_code": "15600",
                "name_city": "Ráquira (Boyacá)"
            },
            {
                "id": 1066,
                "city_code": "85279",
                "name_city": "Recetor (Casanare)"
            },
            {
                "id": 175,
                "city_code": "13580",
                "name_city": "Regidor (Bolívar)"
            },
            {
                "id": 83,
                "city_code": "5604",
                "name_city": "Remedios (Antioquia)"
            },
            {
                "id": 676,
                "city_code": "47605",
                "name_city": "Remolino (Magdalena)"
            },
            {
                "id": 140,
                "city_code": "8606",
                "name_city": "Repelón (Atlántico)"
            },
            {
                "id": 710,
                "city_code": "50606",
                "name_city": "Restrepo (Meta)"
            },
            {
                "id": 1034,
                "city_code": "76606",
                "name_city": "Restrepo (Valle del Cauca)"
            },
            {
                "id": 84,
                "city_code": "5607",
                "name_city": "Retiro (Antioquia)"
            },
            {
                "id": 534,
                "city_code": "25612",
                "name_city": "Ricaurte (Cundinamarca)"
            },
            {
                "id": 764,
                "city_code": "52612",
                "name_city": "Ricaurte (Nariño)"
            },
            {
                "id": 423,
                "city_code": "20614",
                "name_city": "Río De Oro (Cesar)"
            },
            {
                "id": 597,
                "city_code": "27580",
                "name_city": "Río Iró (Chocó)"
            },
            {
                "id": 598,
                "city_code": "27600",
                "name_city": "Río Quito (Chocó)"
            },
            {
                "id": 176,
                "city_code": "13600",
                "name_city": "Río Viejo (Bolívar)"
            },
            {
                "id": 994,
                "city_code": "73616",
                "name_city": "Rioblanco (Tolima)"
            },
            {
                "id": 1035,
                "city_code": "76616",
                "name_city": "Riofrío (Valle del Cauca)"
            },
            {
                "id": 642,
                "city_code": "44001",
                "name_city": "Riohacha (La Guajira)"
            },
            {
                "id": 85,
                "city_code": "5615",
                "name_city": "Rionegro (Antioquia)"
            },
            {
                "id": 911,
                "city_code": "68615",
                "name_city": "Rionegro (Santander)"
            },
            {
                "id": 337,
                "city_code": "17614",
                "name_city": "Riosucio (Caldas)"
            },
            {
                "id": 599,
                "city_code": "27615",
                "name_city": "Riosucio (Chocó)"
            },
            {
                "id": 338,
                "city_code": "17616",
                "name_city": "Risaralda (Caldas)"
            },
            {
                "id": 630,
                "city_code": "41615",
                "name_city": "Rivera (Huila)"
            },
            {
                "id": 765,
                "city_code": "52621",
                "name_city": "Roberto Payán (Nariño)"
            },
            {
                "id": 1036,
                "city_code": "76622",
                "name_city": "Roldanillo (Valle del Cauca)"
            },
            {
                "id": 995,
                "city_code": "73622",
                "name_city": "Roncesvalles (Tolima)"
            },
            {
                "id": 273,
                "city_code": "15621",
                "name_city": "Rondón (Boyacá)"
            },
            {
                "id": 391,
                "city_code": "19622",
                "name_city": "Rosas (Cauca)"
            },
            {
                "id": 996,
                "city_code": "73624",
                "name_city": "Rovira (Tolima)"
            },
            {
                "id": 912,
                "city_code": "68655",
                "name_city": "Sabana De Torres (Santander)"
            },
            {
                "id": 141,
                "city_code": "8634",
                "name_city": "Sabanagrande (Atlántico)"
            },
            {
                "id": 86,
                "city_code": "5628",
                "name_city": "Sabanalarga (Antioquia)"
            },
            {
                "id": 142,
                "city_code": "8638",
                "name_city": "Sabanalarga (Atlántico)"
            },
            {
                "id": 1067,
                "city_code": "85300",
                "name_city": "Sabanalarga (Casanare)"
            },
            {
                "id": 677,
                "city_code": "47660",
                "name_city": "Sabanas De San Ángel (Magdalena)"
            },
            {
                "id": 87,
                "city_code": "5631",
                "name_city": "Sabaneta (Antioquia)"
            },
            {
                "id": 274,
                "city_code": "15632",
                "name_city": "Saboyá (Boyacá)"
            },
            {
                "id": 1068,
                "city_code": "85315",
                "name_city": "Sácama (Casanare)"
            },
            {
                "id": 275,
                "city_code": "15638",
                "name_city": "Sáchica (Boyacá)"
            },
            {
                "id": 449,
                "city_code": "23660",
                "name_city": "Sahagún (Córdoba)"
            },
            {
                "id": 631,
                "city_code": "41660",
                "name_city": "Saladoblanco (Huila)"
            },
            {
                "id": 339,
                "city_code": "17653",
                "name_city": "Salamina (Caldas)"
            },
            {
                "id": 678,
                "city_code": "47675",
                "name_city": "Salamina (Magdalena)"
            },
            {
                "id": 809,
                "city_code": "54660",
                "name_city": "Salazar (Norte de Santander)"
            },
            {
                "id": 997,
                "city_code": "73671",
                "name_city": "Saldaña (Tolima)"
            },
            {
                "id": 831,
                "city_code": "63690",
                "name_city": "Salento (Quindío)"
            },
            {
                "id": 88,
                "city_code": "5642",
                "name_city": "Salgar (Antioquia)"
            },
            {
                "id": 276,
                "city_code": "15646",
                "name_city": "Samacá (Boyacá)"
            },
            {
                "id": 340,
                "city_code": "17662",
                "name_city": "Samaná (Caldas)"
            },
            {
                "id": 766,
                "city_code": "52678",
                "name_city": "Samaniego (Nariño)"
            },
            {
                "id": 949,
                "city_code": "70670",
                "name_city": "Sampués (Sucre)"
            },
            {
                "id": 632,
                "city_code": "41668",
                "name_city": "San Agustín (Huila)"
            },
            {
                "id": 425,
                "city_code": "20710",
                "name_city": "San Alberto (Cesar)"
            },
            {
                "id": 1087,
                "city_code": "88001",
                "name_city": "San Andrés (San Andrés y Providencia)"
            },
            {
                "id": 913,
                "city_code": "68669",
                "name_city": "San Andrés (Santander)"
            },
            {
                "id": 89,
                "city_code": "5647",
                "name_city": "San Andrés De Cuerquía (Antioquia)"
            },
            {
                "id": 450,
                "city_code": "23670",
                "name_city": "San Andrés De Sotavento (Córdoba)"
            },
            {
                "id": 777,
                "city_code": "52835",
                "name_city": "San Andrés De Tumaco (Nariño)"
            },
            {
                "id": 451,
                "city_code": "23672",
                "name_city": "San Antero (Córdoba)"
            },
            {
                "id": 998,
                "city_code": "73675",
                "name_city": "San Antonio (Tolima)"
            },
            {
                "id": 535,
                "city_code": "25645",
                "name_city": "San Antonio Del Tequendama (Cundinamarca)"
            },
            {
                "id": 914,
                "city_code": "68673",
                "name_city": "San Benito (Santander)"
            },
            {
                "id": 950,
                "city_code": "70678",
                "name_city": "San Benito Abad (Sucre)"
            },
            {
                "id": 536,
                "city_code": "25649",
                "name_city": "San Bernardo (Cundinamarca)"
            },
            {
                "id": 768,
                "city_code": "52685",
                "name_city": "San Bernardo (Nariño)"
            },
            {
                "id": 452,
                "city_code": "23675",
                "name_city": "San Bernardo Del Viento (Córdoba)"
            },
            {
                "id": 810,
                "city_code": "54670",
                "name_city": "San Calixto (Norte de Santander)"
            },
            {
                "id": 90,
                "city_code": "5649",
                "name_city": "San Carlos (Antioquia)"
            },
            {
                "id": 453,
                "city_code": "23678",
                "name_city": "San Carlos (Córdoba)"
            },
            {
                "id": 711,
                "city_code": "50680",
                "name_city": "San Carlos De Guaroa (Meta)"
            },
            {
                "id": 537,
                "city_code": "25653",
                "name_city": "San Cayetano (Cundinamarca)"
            },
            {
                "id": 811,
                "city_code": "54673",
                "name_city": "San Cayetano (Norte de Santander)"
            },
            {
                "id": 177,
                "city_code": "13620",
                "name_city": "San Cristóbal (Bolívar)"
            },
            {
                "id": 426,
                "city_code": "20750",
                "name_city": "San Diego (Cesar)"
            },
            {
                "id": 277,
                "city_code": "15660",
                "name_city": "San Eduardo (Boyacá)"
            },
            {
                "id": 178,
                "city_code": "13647",
                "name_city": "San Estanislao (Bolívar)"
            },
            {
                "id": 1103,
                "city_code": "94883",
                "name_city": "San Felipe (Guainía)"
            },
            {
                "id": 179,
                "city_code": "13650",
                "name_city": "San Fernando (Bolívar)"
            },
            {
                "id": 91,
                "city_code": "5652",
                "name_city": "San Francisco (Antioquia)"
            },
            {
                "id": 538,
                "city_code": "25658",
                "name_city": "San Francisco (Cundinamarca)"
            },
            {
                "id": 1082,
                "city_code": "86755",
                "name_city": "San Francisco (Putumayo)"
            },
            {
                "id": 915,
                "city_code": "68679",
                "name_city": "San Gil (Santander)"
            },
            {
                "id": 180,
                "city_code": "13654",
                "name_city": "San Jacinto (Bolívar)"
            },
            {
                "id": 181,
                "city_code": "13655",
                "name_city": "San Jacinto Del Cauca (Bolívar)"
            },
            {
                "id": 92,
                "city_code": "5656",
                "name_city": "San Jerónimo (Antioquia)"
            },
            {
                "id": 916,
                "city_code": "68682",
                "name_city": "San Joaquín (Santander)"
            },
            {
                "id": 341,
                "city_code": "17665",
                "name_city": "San José (Caldas)"
            },
            {
                "id": 780,
                "city_code": "54001",
                "name_city": "San José De Cúcuta (Norte de Santander)"
            },
            {
                "id": 93,
                "city_code": "5658",
                "name_city": "San José De La Montaña (Antioquia)"
            },
            {
                "id": 917,
                "city_code": "68684",
                "name_city": "San José De Miranda (Santander)"
            },
            {
                "id": 278,
                "city_code": "15664",
                "name_city": "San José De Pare (Boyacá)"
            },
            {
                "id": 454,
                "city_code": "23682",
                "name_city": "San José De Uré (Córdoba)"
            },
            {
                "id": 357,
                "city_code": "18610",
                "name_city": "San José Del Fragua (Caquetá)"
            },
            {
                "id": 1109,
                "city_code": "95001",
                "name_city": "San José Del Guaviare (Guaviare)"
            },
            {
                "id": 600,
                "city_code": "27660",
                "name_city": "San José Del Palmar (Chocó)"
            },
            {
                "id": 712,
                "city_code": "50683",
                "name_city": "San Juan De Arama (Meta)"
            },
            {
                "id": 951,
                "city_code": "70702",
                "name_city": "San Juan De Betulia (Sucre)"
            },
            {
                "id": 539,
                "city_code": "25662",
                "name_city": "San Juan De Rioseco (Cundinamarca)"
            },
            {
                "id": 94,
                "city_code": "5659",
                "name_city": "San Juan De Urabá (Antioquia)"
            },
            {
                "id": 653,
                "city_code": "44650",
                "name_city": "San Juan Del Cesar (La Guajira)"
            },
            {
                "id": 182,
                "city_code": "13657",
                "name_city": "San Juan Nepomuceno (Bolívar)"
            },
            {
                "id": 713,
                "city_code": "50686",
                "name_city": "San Juanito (Meta)"
            },
            {
                "id": 769,
                "city_code": "52687",
                "name_city": "San Lorenzo (Nariño)"
            },
            {
                "id": 95,
                "city_code": "5660",
                "name_city": "San Luis (Antioquia)"
            },
            {
                "id": 999,
                "city_code": "73678",
                "name_city": "San Luis (Tolima)"
            },
            {
                "id": 279,
                "city_code": "15667",
                "name_city": "San Luis De Gaceno (Boyacá)"
            },
            {
                "id": 1069,
                "city_code": "85325",
                "name_city": "San Luis De Palenque (Casanare)"
            },
            {
                "id": 955,
                "city_code": "70742",
                "name_city": "San Luis De Sincé (Sucre)"
            },
            {
                "id": 952,
                "city_code": "70708",
                "name_city": "San Marcos (Sucre)"
            },
            {
                "id": 427,
                "city_code": "20770",
                "name_city": "San Martín (Cesar)"
            },
            {
                "id": 714,
                "city_code": "50689",
                "name_city": "San Martín (Meta)"
            },
            {
                "id": 183,
                "city_code": "13667",
                "name_city": "San Martín De Loba (Bolívar)"
            },
            {
                "id": 280,
                "city_code": "15673",
                "name_city": "San Mateo (Boyacá)"
            },
            {
                "id": 1083,
                "city_code": "86757",
                "name_city": "San Miguel (Putumayo)"
            },
            {
                "id": 918,
                "city_code": "68686",
                "name_city": "San Miguel (Santander)"
            },
            {
                "id": 281,
                "city_code": "15676",
                "name_city": "San Miguel De Sema (Boyacá)"
            },
            {
                "id": 953,
                "city_code": "70713",
                "name_city": "San Onofre (Sucre)"
            },
            {
                "id": 184,
                "city_code": "13670",
                "name_city": "San Pablo (Bolívar)"
            },
            {
                "id": 770,
                "city_code": "52693",
                "name_city": "San Pablo (Nariño)"
            },
            {
                "id": 282,
                "city_code": "15681",
                "name_city": "San Pablo De Borbur (Boyacá)"
            },
            {
                "id": 954,
                "city_code": "70717",
                "name_city": "San Pedro (Sucre)"
            },
            {
                "id": 1037,
                "city_code": "76670",
                "name_city": "San Pedro (Valle del Cauca)"
            },
            {
                "id": 771,
                "city_code": "52694",
                "name_city": "San Pedro De Cartago (Nariño)"
            },
            {
                "id": 96,
                "city_code": "5664",
                "name_city": "San Pedro De Los Milagros (Antioquia)"
            },
            {
                "id": 97,
                "city_code": "5665",
                "name_city": "San Pedro De Urabá (Antioquia)"
            },
            {
                "id": 455,
                "city_code": "23686",
                "name_city": "San Pelayo (Córdoba)"
            },
            {
                "id": 98,
                "city_code": "5667",
                "name_city": "San Rafael (Antioquia)"
            },
            {
                "id": 99,
                "city_code": "5670",
                "name_city": "San Roque (Antioquia)"
            },
            {
                "id": 392,
                "city_code": "19693",
                "name_city": "San Sebastián (Cauca)"
            },
            {
                "id": 679,
                "city_code": "47692",
                "name_city": "San Sebastián De Buenavista (Magdalena)"
            },
            {
                "id": 984,
                "city_code": "73443",
                "name_city": "San Sebastián De Mariquita (Tolima)"
            },
            {
                "id": 919,
                "city_code": "68689",
                "name_city": "San Vicente De Chucurí (Santander)"
            },
            {
                "id": 358,
                "city_code": "18753",
                "name_city": "San Vicente Del Caguán (Caquetá)"
            },
            {
                "id": 100,
                "city_code": "5674",
                "name_city": "San Vicente Ferrer (Antioquia)"
            },
            {
                "id": 680,
                "city_code": "47703",
                "name_city": "San Zenón (Magdalena)"
            },
            {
                "id": 767,
                "city_code": "52683",
                "name_city": "Sandoná (Nariño)"
            },
            {
                "id": 681,
                "city_code": "47707",
                "name_city": "Santa Ana (Magdalena)"
            },
            {
                "id": 101,
                "city_code": "5679",
                "name_city": "Santa Bárbara (Antioquia)"
            },
            {
                "id": 772,
                "city_code": "52696",
                "name_city": "Santa Bárbara (Nariño)"
            },
            {
                "id": 920,
                "city_code": "68705",
                "name_city": "Santa Bárbara (Santander)"
            },
            {
                "id": 682,
                "city_code": "47720",
                "name_city": "Santa Bárbara De Pinto (Magdalena)"
            },
            {
                "id": 185,
                "city_code": "13673",
                "name_city": "Santa Catalina (Bolívar)"
            },
            {
                "id": 11,
                "city_code": "5042",
                "name_city": "Santa Fé De Antioquia (Antioquia)"
            },
            {
                "id": 921,
                "city_code": "68720",
                "name_city": "Santa Helena Del Opón (Santander)"
            },
            {
                "id": 1000,
                "city_code": "73686",
                "name_city": "Santa Isabel (Tolima)"
            },
            {
                "id": 143,
                "city_code": "8675",
                "name_city": "Santa Lucía (Atlántico)"
            },
            {
                "id": 284,
                "city_code": "15690",
                "name_city": "Santa María (Boyacá)"
            },
            {
                "id": 633,
                "city_code": "41676",
                "name_city": "Santa María (Huila)"
            },
            {
                "id": 657,
                "city_code": "47001",
                "name_city": "Santa Marta (Magdalena)"
            },
            {
                "id": 186,
                "city_code": "13683",
                "name_city": "Santa Rosa (Bolívar)"
            },
            {
                "id": 394,
                "city_code": "19701",
                "name_city": "Santa Rosa (Cauca)"
            },
            {
                "id": 844,
                "city_code": "66682",
                "name_city": "Santa Rosa De Cabal (Risaralda)"
            },
            {
                "id": 102,
                "city_code": "5686",
                "name_city": "Santa Rosa De Osos (Antioquia)"
            },
            {
                "id": 285,
                "city_code": "15693",
                "name_city": "Santa Rosa De Viterbo (Boyacá)"
            },
            {
                "id": 187,
                "city_code": "13688",
                "name_city": "Santa Rosa Del Sur (Bolívar)"
            },
            {
                "id": 1121,
                "city_code": "99624",
                "name_city": "Santa Rosalía (Vichada)"
            },
            {
                "id": 286,
                "city_code": "15696",
                "name_city": "Santa Sofía (Boyacá)"
            },
            {
                "id": 773,
                "city_code": "52699",
                "name_city": "Santacruz (Nariño)"
            },
            {
                "id": 283,
                "city_code": "15686",
                "name_city": "Santana (Boyacá)"
            },
            {
                "id": 393,
                "city_code": "19698",
                "name_city": "Santander De Quilichao (Cauca)"
            },
            {
                "id": 812,
                "city_code": "54680",
                "name_city": "Santiago (Norte de Santander)"
            },
            {
                "id": 1084,
                "city_code": "86760",
                "name_city": "Santiago (Putumayo)"
            },
            {
                "id": 957,
                "city_code": "70820",
                "name_city": "Santiago De Tolú (Sucre)"
            },
            {
                "id": 103,
                "city_code": "5690",
                "name_city": "Santo Domingo (Antioquia)"
            },
            {
                "id": 144,
                "city_code": "8685",
                "name_city": "Santo Tomás (Atlántico)"
            },
            {
                "id": 845,
                "city_code": "66687",
                "name_city": "Santuario (Risaralda)"
            },
            {
                "id": 774,
                "city_code": "52720",
                "name_city": "Sapuyes (Nariño)"
            },
            {
                "id": 1053,
                "city_code": "81736",
                "name_city": "Saravena (Arauca)"
            },
            {
                "id": 813,
                "city_code": "54720",
                "name_city": "Sardinata (Norte de Santander)"
            },
            {
                "id": 540,
                "city_code": "25718",
                "name_city": "Sasaima (Cundinamarca)"
            },
            {
                "id": 287,
                "city_code": "15720",
                "name_city": "Sativanorte (Boyacá)"
            },
            {
                "id": 288,
                "city_code": "15723",
                "name_city": "Sativasur (Boyacá)"
            },
            {
                "id": 105,
                "city_code": "5736",
                "name_city": "Segovia (Antioquia)"
            },
            {
                "id": 541,
                "city_code": "25736",
                "name_city": "Sesquilé (Cundinamarca)"
            },
            {
                "id": 1038,
                "city_code": "76736",
                "name_city": "Sevilla (Valle del Cauca)"
            },
            {
                "id": 289,
                "city_code": "15740",
                "name_city": "Siachoque (Boyacá)"
            },
            {
                "id": 542,
                "city_code": "25740",
                "name_city": "Sibaté (Cundinamarca)"
            },
            {
                "id": 1081,
                "city_code": "86749",
                "name_city": "Sibundoy (Putumayo)"
            },
            {
                "id": 814,
                "city_code": "54743",
                "name_city": "Silos (Norte de Santander)"
            },
            {
                "id": 543,
                "city_code": "25743",
                "name_city": "Silvania (Cundinamarca)"
            },
            {
                "id": 395,
                "city_code": "19743",
                "name_city": "Silvia (Cauca)"
            },
            {
                "id": 922,
                "city_code": "68745",
                "name_city": "Simacota (Santander)"
            },
            {
                "id": 544,
                "city_code": "25745",
                "name_city": "Simijaca (Cundinamarca)"
            },
            {
                "id": 188,
                "city_code": "13744",
                "name_city": "Simití (Bolívar)"
            },
            {
                "id": 933,
                "city_code": "70001",
                "name_city": "Sincelejo (Sucre)"
            },
            {
                "id": 601,
                "city_code": "27745",
                "name_city": "Sipí (Chocó)"
            },
            {
                "id": 683,
                "city_code": "47745",
                "name_city": "Sitionuevo (Magdalena)"
            },
            {
                "id": 545,
                "city_code": "25754",
                "name_city": "Soacha (Cundinamarca)"
            },
            {
                "id": 290,
                "city_code": "15753",
                "name_city": "Soatá (Boyacá)"
            },
            {
                "id": 292,
                "city_code": "15757",
                "name_city": "Socha (Boyacá)"
            },
            {
                "id": 923,
                "city_code": "68755",
                "name_city": "Socorro (Santander)"
            },
            {
                "id": 291,
                "city_code": "15755",
                "name_city": "Socotá (Boyacá)"
            },
            {
                "id": 293,
                "city_code": "15759",
                "name_city": "Sogamoso (Boyacá)"
            },
            {
                "id": 359,
                "city_code": "18756",
                "name_city": "Solano (Caquetá)"
            },
            {
                "id": 145,
                "city_code": "8758",
                "name_city": "Soledad (Atlántico)"
            },
            {
                "id": 360,
                "city_code": "18785",
                "name_city": "Solita (Caquetá)"
            },
            {
                "id": 294,
                "city_code": "15761",
                "name_city": "Somondoco (Boyacá)"
            },
            {
                "id": 106,
                "city_code": "5756",
                "name_city": "Sonsón (Antioquia)"
            },
            {
                "id": 107,
                "city_code": "5761",
                "name_city": "Sopetrán (Antioquia)"
            },
            {
                "id": 189,
                "city_code": "13760",
                "name_city": "Soplaviento (Bolívar)"
            },
            {
                "id": 546,
                "city_code": "25758",
                "name_city": "Sopó (Cundinamarca)"
            },
            {
                "id": 295,
                "city_code": "15762",
                "name_city": "Sora (Boyacá)"
            },
            {
                "id": 297,
                "city_code": "15764",
                "name_city": "Soracá (Boyacá)"
            },
            {
                "id": 296,
                "city_code": "15763",
                "name_city": "Sotaquirá (Boyacá)"
            },
            {
                "id": 396,
                "city_code": "19760",
                "name_city": "Sotara (Cauca)"
            },
            {
                "id": 924,
                "city_code": "68770",
                "name_city": "Suaita (Santander)"
            },
            {
                "id": 146,
                "city_code": "8770",
                "name_city": "Suan (Atlántico)"
            },
            {
                "id": 397,
                "city_code": "19780",
                "name_city": "Suárez (Cauca)"
            },
            {
                "id": 1001,
                "city_code": "73770",
                "name_city": "Suárez (Tolima)"
            },
            {
                "id": 634,
                "city_code": "41770",
                "name_city": "Suaza (Huila)"
            },
            {
                "id": 547,
                "city_code": "25769",
                "name_city": "Subachoque (Cundinamarca)"
            },
            {
                "id": 398,
                "city_code": "19785",
                "name_city": "Sucre (Cauca)"
            },
            {
                "id": 925,
                "city_code": "68773",
                "name_city": "Sucre (Santander)"
            },
            {
                "id": 956,
                "city_code": "70771",
                "name_city": "Sucre (Sucre)"
            },
            {
                "id": 548,
                "city_code": "25772",
                "name_city": "Suesca (Cundinamarca)"
            },
            {
                "id": 549,
                "city_code": "25777",
                "name_city": "Supatá (Cundinamarca)"
            },
            {
                "id": 342,
                "city_code": "17777",
                "name_city": "Supía (Caldas)"
            },
            {
                "id": 926,
                "city_code": "68780",
                "name_city": "Suratá (Santander)"
            },
            {
                "id": 550,
                "city_code": "25779",
                "name_city": "Susa (Cundinamarca)"
            },
            {
                "id": 298,
                "city_code": "15774",
                "name_city": "Susacón (Boyacá)"
            },
            {
                "id": 299,
                "city_code": "15776",
                "name_city": "Sutamarchán (Boyacá)"
            },
            {
                "id": 551,
                "city_code": "25781",
                "name_city": "Sutatausa (Cundinamarca)"
            },
            {
                "id": 300,
                "city_code": "15778",
                "name_city": "Sutatenza (Boyacá)"
            },
            {
                "id": 552,
                "city_code": "25785",
                "name_city": "Tabio (Cundinamarca)"
            },
            {
                "id": 602,
                "city_code": "27787",
                "name_city": "Tadó (Chocó)"
            },
            {
                "id": 190,
                "city_code": "13780",
                "name_city": "Talaigua Nuevo (Bolívar)"
            },
            {
                "id": 428,
                "city_code": "20787",
                "name_city": "Tamalameque (Cesar)"
            },
            {
                "id": 1070,
                "city_code": "85400",
                "name_city": "Támara (Casanare)"
            },
            {
                "id": 1054,
                "city_code": "81794",
                "name_city": "Tame (Arauca)"
            },
            {
                "id": 108,
                "city_code": "5789",
                "name_city": "Támesis (Antioquia)"
            },
            {
                "id": 775,
                "city_code": "52786",
                "name_city": "Taminango (Nariño)"
            },
            {
                "id": 776,
                "city_code": "52788",
                "name_city": "Tangua (Nariño)"
            },
            {
                "id": 1116,
                "city_code": "97666",
                "name_city": "Taraira (Vaupés)"
            },
            {
                "id": 1099,
                "city_code": "91798",
                "name_city": "Tarapacá (Amazonas)"
            },
            {
                "id": 109,
                "city_code": "5790",
                "name_city": "Tarazá (Antioquia)"
            },
            {
                "id": 635,
                "city_code": "41791",
                "name_city": "Tarqui (Huila)"
            },
            {
                "id": 110,
                "city_code": "5792",
                "name_city": "Tarso (Antioquia)"
            },
            {
                "id": 301,
                "city_code": "15790",
                "name_city": "Tasco (Boyacá)"
            },
            {
                "id": 1071,
                "city_code": "85410",
                "name_city": "Tauramena (Casanare)"
            },
            {
                "id": 553,
                "city_code": "25793",
                "name_city": "Tausa (Cundinamarca)"
            },
            {
                "id": 637,
                "city_code": "41799",
                "name_city": "Tello (Huila)"
            },
            {
                "id": 554,
                "city_code": "25797",
                "name_city": "Tena (Cundinamarca)"
            },
            {
                "id": 684,
                "city_code": "47798",
                "name_city": "Tenerife (Magdalena)"
            },
            {
                "id": 555,
                "city_code": "25799",
                "name_city": "Tenjo (Cundinamarca)"
            },
            {
                "id": 302,
                "city_code": "15798",
                "name_city": "Tenza (Boyacá)"
            },
            {
                "id": 815,
                "city_code": "54800",
                "name_city": "Teorama (Norte de Santander)"
            },
            {
                "id": 638,
                "city_code": "41801",
                "name_city": "Teruel (Huila)"
            },
            {
                "id": 636,
                "city_code": "41797",
                "name_city": "Tesalia (Huila)"
            },
            {
                "id": 556,
                "city_code": "25805",
                "name_city": "Tibacuy (Cundinamarca)"
            },
            {
                "id": 303,
                "city_code": "15804",
                "name_city": "Tibaná (Boyacá)"
            },
            {
                "id": 304,
                "city_code": "15806",
                "name_city": "Tibasosa (Boyacá)"
            },
            {
                "id": 557,
                "city_code": "25807",
                "name_city": "Tibirita (Cundinamarca)"
            },
            {
                "id": 816,
                "city_code": "54810",
                "name_city": "Tibú (Norte de Santander)"
            },
            {
                "id": 456,
                "city_code": "23807",
                "name_city": "Tierralta (Córdoba)"
            },
            {
                "id": 639,
                "city_code": "41807",
                "name_city": "Timaná (Huila)"
            },
            {
                "id": 399,
                "city_code": "19807",
                "name_city": "Timbío (Cauca)"
            },
            {
                "id": 400,
                "city_code": "19809",
                "name_city": "Timbiquí (Cauca)"
            },
            {
                "id": 305,
                "city_code": "15808",
                "name_city": "Tinjacá (Boyacá)"
            },
            {
                "id": 306,
                "city_code": "15810",
                "name_city": "Tipacoque (Boyacá)"
            },
            {
                "id": 191,
                "city_code": "13810",
                "name_city": "Tiquisio (Bolívar)"
            },
            {
                "id": 111,
                "city_code": "5809",
                "name_city": "Titiribí (Antioquia)"
            },
            {
                "id": 307,
                "city_code": "15814",
                "name_city": "Toca (Boyacá)"
            },
            {
                "id": 558,
                "city_code": "25815",
                "name_city": "Tocaima (Cundinamarca)"
            },
            {
                "id": 559,
                "city_code": "25817",
                "name_city": "Tocancipá (Cundinamarca)"
            },
            {
                "id": 308,
                "city_code": "15816",
                "name_city": "Togüí (Boyacá)"
            },
            {
                "id": 112,
                "city_code": "5819",
                "name_city": "Toledo (Antioquia)"
            },
            {
                "id": 817,
                "city_code": "54820",
                "name_city": "Toledo (Norte de Santander)"
            },
            {
                "id": 958,
                "city_code": "70823",
                "name_city": "Tolú Viejo (Sucre)"
            },
            {
                "id": 927,
                "city_code": "68820",
                "name_city": "Tona (Santander)"
            },
            {
                "id": 309,
                "city_code": "15820",
                "name_city": "Tópaga (Boyacá)"
            },
            {
                "id": 560,
                "city_code": "25823",
                "name_city": "Topaipí (Cundinamarca)"
            },
            {
                "id": 401,
                "city_code": "19821",
                "name_city": "Toribío (Cauca)"
            },
            {
                "id": 1039,
                "city_code": "76823",
                "name_city": "Toro (Valle del Cauca)"
            },
            {
                "id": 310,
                "city_code": "15822",
                "name_city": "Tota (Boyacá)"
            },
            {
                "id": 402,
                "city_code": "19824",
                "name_city": "Totoró (Cauca)"
            },
            {
                "id": 1072,
                "city_code": "85430",
                "name_city": "Trinidad (Casanare)"
            },
            {
                "id": 1040,
                "city_code": "76828",
                "name_city": "Trujillo (Valle del Cauca)"
            },
            {
                "id": 147,
                "city_code": "8832",
                "name_city": "Tubará (Atlántico)"
            },
            {
                "id": 457,
                "city_code": "23815",
                "name_city": "Tuchín (Córdoba)"
            },
            {
                "id": 1041,
                "city_code": "76834",
                "name_city": "Tuluá (Valle del Cauca)"
            },
            {
                "id": 196,
                "city_code": "15001",
                "name_city": "Tunja (Boyacá)"
            },
            {
                "id": 311,
                "city_code": "15832",
                "name_city": "Tununguá (Boyacá)"
            },
            {
                "id": 778,
                "city_code": "52838",
                "name_city": "Túquerres (Nariño)"
            },
            {
                "id": 192,
                "city_code": "13836",
                "name_city": "Turbaco (Bolívar)"
            },
            {
                "id": 193,
                "city_code": "13838",
                "name_city": "Turbaná (Bolívar)"
            },
            {
                "id": 113,
                "city_code": "5837",
                "name_city": "Turbo (Antioquia)"
            },
            {
                "id": 312,
                "city_code": "15835",
                "name_city": "Turmequé (Boyacá)"
            },
            {
                "id": 313,
                "city_code": "15837",
                "name_city": "Tuta (Boyacá)"
            },
            {
                "id": 314,
                "city_code": "15839",
                "name_city": "Tutazá (Boyacá)"
            },
            {
                "id": 561,
                "city_code": "25839",
                "name_city": "Ubalá (Cundinamarca)"
            },
            {
                "id": 562,
                "city_code": "25841",
                "name_city": "Ubaque (Cundinamarca)"
            },
            {
                "id": 1042,
                "city_code": "76845",
                "name_city": "Ulloa (Valle del Cauca)"
            },
            {
                "id": 315,
                "city_code": "15842",
                "name_city": "Úmbita (Boyacá)"
            },
            {
                "id": 564,
                "city_code": "25845",
                "name_city": "Une (Cundinamarca)"
            },
            {
                "id": 603,
                "city_code": "27800",
                "name_city": "Unguía (Chocó)"
            },
            {
                "id": 604,
                "city_code": "27810",
                "name_city": "Unión Panamericana (Chocó)"
            },
            {
                "id": 114,
                "city_code": "5842",
                "name_city": "Uramita (Antioquia)"
            },
            {
                "id": 703,
                "city_code": "50370",
                "name_city": "Uribe (Meta)"
            },
            {
                "id": 654,
                "city_code": "44847",
                "name_city": "Uribia (La Guajira)"
            },
            {
                "id": 115,
                "city_code": "5847",
                "name_city": "Urrao (Antioquia)"
            },
            {
                "id": 655,
                "city_code": "44855",
                "name_city": "Urumita (La Guajira)"
            },
            {
                "id": 148,
                "city_code": "8849",
                "name_city": "Usiacurí (Atlántico)"
            },
            {
                "id": 565,
                "city_code": "25851",
                "name_city": "Útica (Cundinamarca)"
            },
            {
                "id": 116,
                "city_code": "5854",
                "name_city": "Valdivia (Antioquia)"
            },
            {
                "id": 458,
                "city_code": "23855",
                "name_city": "Valencia (Córdoba)"
            },
            {
                "id": 928,
                "city_code": "68855",
                "name_city": "Valle De San José (Santander)"
            },
            {
                "id": 1002,
                "city_code": "73854",
                "name_city": "Valle De San Juan (Tolima)"
            },
            {
                "id": 1085,
                "city_code": "86865",
                "name_city": "Valle Del Guamuez (Putumayo)"
            },
            {
                "id": 404,
                "city_code": "20001",
                "name_city": "Valledupar (Cesar)"
            },
            {
                "id": 117,
                "city_code": "5856",
                "name_city": "Valparaíso (Antioquia)"
            },
            {
                "id": 361,
                "city_code": "18860",
                "name_city": "Valparaíso (Caquetá)"
            },
            {
                "id": 118,
                "city_code": "5858",
                "name_city": "Vegachí (Antioquia)"
            },
            {
                "id": 929,
                "city_code": "68861",
                "name_city": "Vélez (Santander)"
            },
            {
                "id": 1003,
                "city_code": "73861",
                "name_city": "Venadillo (Tolima)"
            },
            {
                "id": 119,
                "city_code": "5861",
                "name_city": "Venecia (Antioquia)"
            },
            {
                "id": 522,
                "city_code": "25506",
                "name_city": "Venecia (Cundinamarca)"
            },
            {
                "id": 316,
                "city_code": "15861",
                "name_city": "Ventaquemada (Boyacá)"
            },
            {
                "id": 566,
                "city_code": "25862",
                "name_city": "Vergara (Cundinamarca)"
            },
            {
                "id": 1043,
                "city_code": "76863",
                "name_city": "Versalles (Valle del Cauca)"
            },
            {
                "id": 930,
                "city_code": "68867",
                "name_city": "Vetas (Santander)"
            },
            {
                "id": 567,
                "city_code": "25867",
                "name_city": "Vianí (Cundinamarca)"
            },
            {
                "id": 343,
                "city_code": "17867",
                "name_city": "Victoria (Caldas)"
            },
            {
                "id": 120,
                "city_code": "5873",
                "name_city": "Vigía Del Fuerte (Antioquia)"
            },
            {
                "id": 1044,
                "city_code": "76869",
                "name_city": "Vijes (Valle del Cauca)"
            },
            {
                "id": 818,
                "city_code": "54871",
                "name_city": "Villa Caro (Norte de Santander)"
            },
            {
                "id": 246,
                "city_code": "15407",
                "name_city": "Villa De Leyva (Boyacá)"
            },
            {
                "id": 563,
                "city_code": "25843",
                "name_city": "Villa De San Diego De Ubaté (Cundinamarca)"
            },
            {
                "id": 819,
                "city_code": "54874",
                "name_city": "Villa Del Rosario (Norte de Santander)"
            },
            {
                "id": 403,
                "city_code": "19845",
                "name_city": "Villa Rica (Cauca)"
            },
            {
                "id": 1086,
                "city_code": "86885",
                "name_city": "Villagarzón (Putumayo)"
            },
            {
                "id": 568,
                "city_code": "25871",
                "name_city": "Villagómez (Cundinamarca)"
            },
            {
                "id": 1004,
                "city_code": "73870",
                "name_city": "Villahermosa (Tolima)"
            },
            {
                "id": 344,
                "city_code": "17873",
                "name_city": "Villamaría (Caldas)"
            },
            {
                "id": 194,
                "city_code": "13873",
                "name_city": "Villanueva (Bolívar)"
            },
            {
                "id": 1073,
                "city_code": "85440",
                "name_city": "Villanueva (Casanare)"
            },
            {
                "id": 656,
                "city_code": "44874",
                "name_city": "Villanueva (La Guajira)"
            },
            {
                "id": 931,
                "city_code": "68872",
                "name_city": "Villanueva (Santander)"
            },
            {
                "id": 569,
                "city_code": "25873",
                "name_city": "Villapinzón (Cundinamarca)"
            },
            {
                "id": 1005,
                "city_code": "73873",
                "name_city": "Villarrica (Tolima)"
            },
            {
                "id": 687,
                "city_code": "50001",
                "name_city": "Villavicencio (Meta)"
            },
            {
                "id": 640,
                "city_code": "41872",
                "name_city": "Villavieja (Huila)"
            },
            {
                "id": 570,
                "city_code": "25875",
                "name_city": "Villeta (Cundinamarca)"
            },
            {
                "id": 571,
                "city_code": "25878",
                "name_city": "Viotá (Cundinamarca)"
            },
            {
                "id": 317,
                "city_code": "15879",
                "name_city": "Viracachá (Boyacá)"
            },
            {
                "id": 715,
                "city_code": "50711",
                "name_city": "Vistahermosa (Meta)"
            },
            {
                "id": 345,
                "city_code": "17877",
                "name_city": "Viterbo (Caldas)"
            },
            {
                "id": 572,
                "city_code": "25885",
                "name_city": "Yacopí (Cundinamarca)"
            },
            {
                "id": 779,
                "city_code": "52885",
                "name_city": "Yacuanquer (Nariño)"
            },
            {
                "id": 641,
                "city_code": "41885",
                "name_city": "Yaguará (Huila)"
            },
            {
                "id": 121,
                "city_code": "5885",
                "name_city": "Yalí (Antioquia)"
            },
            {
                "id": 122,
                "city_code": "5887",
                "name_city": "Yarumal (Antioquia)"
            },
            {
                "id": 1118,
                "city_code": "97889",
                "name_city": "Yavaraté (Vaupés)"
            },
            {
                "id": 123,
                "city_code": "5890",
                "name_city": "Yolombó (Antioquia)"
            },
            {
                "id": 124,
                "city_code": "5893",
                "name_city": "Yondó (Antioquia)"
            },
            {
                "id": 1055,
                "city_code": "85001",
                "name_city": "Yopal (Casanare)"
            },
            {
                "id": 1045,
                "city_code": "76890",
                "name_city": "Yotoco (Valle del Cauca)"
            },
            {
                "id": 1046,
                "city_code": "76892",
                "name_city": "Yumbo (Valle del Cauca)"
            },
            {
                "id": 195,
                "city_code": "13894",
                "name_city": "Zambrano (Bolívar)"
            },
            {
                "id": 932,
                "city_code": "68895",
                "name_city": "Zapatoca (Santander)"
            },
            {
                "id": 685,
                "city_code": "47960",
                "name_city": "Zapayán (Magdalena)"
            },
            {
                "id": 125,
                "city_code": "5895",
                "name_city": "Zaragoza (Antioquia)"
            },
            {
                "id": 1047,
                "city_code": "76895",
                "name_city": "Zarzal (Valle del Cauca)"
            },
            {
                "id": 318,
                "city_code": "15897",
                "name_city": "Zetaquira (Boyacá)"
            },
            {
                "id": 573,
                "city_code": "25898",
                "name_city": "Zipacón (Cundinamarca)"
            },
            {
                "id": 574,
                "city_code": "25899",
                "name_city": "Zipaquirá (Cundinamarca)"
            },
            {
                "id": 686,
                "city_code": "47980",
                "name_city": "Zona Bananera (Magdalena)"
            }
        ];
        this.dataCities = [];
    }
    getData() {
        const ts = this;
        return ts.api.get('/cities')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((resp) => {
            return resp.records;
        }));
    }
}
CitiesService.ɵfac = function CitiesService_Factory(t) { return new (t || CitiesService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"])); };
CitiesService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: CitiesService, factory: CitiesService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CitiesService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/services/global/countries.service.ts":
/*!******************************************************!*\
  !*** ./src/app/services/global/countries.service.ts ***!
  \******************************************************/
/*! exports provided: CountriesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountriesService", function() { return CountriesService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/api-server.service */ "./src/app/utils/api-server.service.ts");




class CountriesService {
    constructor(api) {
        this.api = api;
        this.data = [];
    }
    getData() {
        const ts = this;
        return ts.api.get('/countries')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((resp) => {
            return resp.records;
        }));
    }
}
CountriesService.ɵfac = function CountriesService_Factory(t) { return new (t || CountriesService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"])); };
CountriesService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: CountriesService, factory: CountriesService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CountriesService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/services/global/currency-sys.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/services/global/currency-sys.service.ts ***!
  \*********************************************************/
/*! exports provided: CurrencySysService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrencySysService", function() { return CurrencySysService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/api-server.service */ "./src/app/utils/api-server.service.ts");




class CurrencySysService {
    constructor(api) {
        this.api = api;
        this.data = [];
    }
    getData() {
        const ts = this;
        return ts.api.get('/currencysys')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((resp) => {
            return resp.records;
        }));
    }
}
CurrencySysService.ɵfac = function CurrencySysService_Factory(t) { return new (t || CurrencySysService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"])); };
CurrencySysService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: CurrencySysService, factory: CurrencySysService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CurrencySysService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/services/global/identity-documents.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/services/global/identity-documents.service.ts ***!
  \***************************************************************/
/*! exports provided: IdentityDocumentsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdentityDocumentsService", function() { return IdentityDocumentsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/api-server.service */ "./src/app/utils/api-server.service.ts");




class IdentityDocumentsService {
    constructor(api) {
        this.api = api;
        this.data = [];
    }
    getData(params) {
        const ts = this;
        return ts.api.get('/identitydocuments', params)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((resp) => {
            return resp.records;
        }));
    }
}
IdentityDocumentsService.ɵfac = function IdentityDocumentsService_Factory(t) { return new (t || IdentityDocumentsService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"])); };
IdentityDocumentsService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: IdentityDocumentsService, factory: IdentityDocumentsService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IdentityDocumentsService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _utils_api_server_service__WEBPACK_IMPORTED_MODULE_2__["ApiServerService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/services/global/index.ts":
/*!******************************************!*\
  !*** ./src/app/services/global/index.ts ***!
  \******************************************/
/*! exports provided: IdentityDocumentsService, CountriesService, CurrencySysService, CitiesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _identity_documents_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./identity-documents.service */ "./src/app/services/global/identity-documents.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IdentityDocumentsService", function() { return _identity_documents_service__WEBPACK_IMPORTED_MODULE_0__["IdentityDocumentsService"]; });

/* harmony import */ var _countries_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./countries.service */ "./src/app/services/global/countries.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CountriesService", function() { return _countries_service__WEBPACK_IMPORTED_MODULE_1__["CountriesService"]; });

/* harmony import */ var _currency_sys_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./currency-sys.service */ "./src/app/services/global/currency-sys.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CurrencySysService", function() { return _currency_sys_service__WEBPACK_IMPORTED_MODULE_2__["CurrencySysService"]; });

/* harmony import */ var _cities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cities.service */ "./src/app/services/global/cities.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CitiesService", function() { return _cities_service__WEBPACK_IMPORTED_MODULE_3__["CitiesService"]; });







/***/ })

}]);
//# sourceMappingURL=default~accounting-accounting-module~companies-companies-module~general-general-module.js.map